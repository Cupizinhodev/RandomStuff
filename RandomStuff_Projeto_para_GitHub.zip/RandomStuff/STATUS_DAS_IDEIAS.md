# STATUS DAS IDEIAS

Legenda: IMPLEMENTADO (funciona e foi testado), PARCIAL, PLANEJADO, BLOQUEADO, NÃO TESTADO (escrito, nunca executado).
**Nenhuma ideia está como IMPLEMENTADO: nada foi compilado nem aberto no jogo.** Tudo abaixo marcado PARCIAL/NÃO TESTADO está apenas escrito.

| Nº | Ideia | Status | Observação |
|---|---|---|---|
| 01 | Slimes/Magma Cubes sem dano de queda | PARCIAL | NÃO TESTADO. Dano de queda é cancelado (evento ALLOW_DAMAGE). O quique ao pousar NÃO foi feito. |
| 02 | Slimes flutuam na água / Magma Cubes na lava | NÃO TESTADO | Empuxo aproximado: empurra o mob para cima quando submerso >40%. Pode ficar diferente do desejado. |
| 03 | Empurrão e inimizade natural | PLANEJADO | Exige goals de IA. |
| 04 | Correntes escaláveis | NÃO TESTADO | Tag `climbable` com `chain` e `iron_chain` opcionais; ids reais do 26.3 não confirmados. Correntes de cobre não cobertas. |
| 05 | Seis músicas como discos | PLANEJADO | Método de obtenção e arquivos de áudio indefinidos. |
| 06 | Aldeões seguem esmeraldas | NÃO TESTADO | Raio 10 blocos. O cérebro do aldeão pode competir com a navegação. |
| 07 | Queda Suave protege plantações e ovos | NÃO TESTADO | Mixin em FarmBlock.turnToDirt e TurtleEggBlock.destroyEgg; qualquer nível do encantamento. |
| 08 | Tridentes com colisão / ejetor | PLANEJADO |  |
| 09 | Rebater neve, ovos e vento | NÃO TESTADO | Mixin Entity.isPickable + evento de ataque. Velocidade 1.5 ao rebater (valor meu). |
| 10 | Cabeças hostis provocam golems | NÃO TESTADO | Lista: zumbi, esqueleto, esqueleto Wither, creeper, dragão. Raio 16. |
| 11 | Capturar slimes/magma cubes com baldes | PLANEJADO |  |
| 12 | Madeira de azaleia | PLANEJADO | Receitas/texturas não especificadas. |
| 13 | Ossos e farinha de osso do Wither | PARCIAL | NÃO TESTADO. Existem: osso, bloco, farinha (3×3), drop 0–2 de esqueleto Wither. NÃO existem receitas (não definidas nos TXT). |
| 14 | Dente-de-leão dourado | PLANEJADO |  |
| 15 | Vidro com/sem bordas | PLANEJADO | Precisa das texturas originais. |
| 16 | Molduras de item invisíveis | PLANEJADO |  |
| 17 | Portais do Nether horizontais | PLANEJADO |  |
| 18 | Vagonetas conectadas por corrente | PLANEJADO |  |
| 19 | Aceleração/freio de vagonetas | PLANEJADO | 60 blocos/s não implementado. |
| 20 | Calculadora | PLANEJADO | Receita pendente. |
| 21 | Trilhos de cobre | PARCIAL | NÃO TESTADO. Bloco, receita, 4 níveis de oxidação, machado, favo de mel e impulso (teto 16 b/s no nível 0). Texturas provisórias. O limite vanilla de velocidade de vagonetas pode anular o impulso. |
| 22 | Trilhos de slime | PARCIAL | NÃO TESTADO. Bloco, receita (bloco de slime) e lançamento vertical (0.9 b/tick). Não exige redstone. Texturas provisórias. |
| 23 | Tempo avança durante o sono | PLANEJADO |  |
| 24 | Slimes e blocos tingíveis | PLANEJADO | Precisa das texturas originais. |
| 25 | Resistência à Lava | PLANEJADO |  |
| 26 | Opções do Random Stuff (tela) | PLANEJADO |  |
| 27 | Tooltips detalhadas | PLANEJADO |  |
| 28 | Descascar madeira no cortador de pedra | PARCIAL | NÃO TESTADO. 23 receitas 1:1 para madeiras vanilla (troncos, madeiras, caules, bambu). Azaleia depende da ideia 12. |
| 29 | Ouro-rosa | PARCIAL | NÃO TESTADO. Itens, receita do bruto e fundição. Faltam molde, mesa de ferraria e equipamentos. Texturas provisórias. |
| 30 | Netherite resistente a cactos | NÃO TESTADO | Mixin: itens cujo id começa com `netherite_` (inclui lingote, fragmento, molde). |
| 31 | Magma Cubes sofrem dano na água | NÃO TESTADO | 1 de dano por segundo em contato com água (valor meu). Chuva não conta. |
| 32 | Cubo de Enxofre: TNT/mel | PLANEJADO |  |
| 33 | Colisão superior de Slimes/Magma Cubes | PLANEJADO |  |
| 34 | Funções extras do Cubo de Enxofre | PLANEJADO |  |

## Ideias complementares sem TXT próprio

- Espada de ouro com dano da netherite: **PARCIAL** — NÃO TESTADO. Soma +4 de dano em golpes corpo a corpo com espada de ouro (netherite 8 − ouro 4). O tooltip da espada continua mostrando o valor de ouro. Durabilidade intacta.
- Bússola marcada: **PLANEJADO**
- Relógio detalhado: **PLANEJADO**
- Luneta aprimorável: **PLANEJADO**
- Água colorida: **PLANEJADO**
- Lâmpadas de redstone coloridas: **PLANEJADO**
- Slabs (inspirado em Slabbed): **PLANEJADO**
- Sprite do trilho energizado ligado: **PLANEJADO**
- Bloco de slime de magma: **PLANEJADO**
- Interface transparente/escura: **PLANEJADO**
- Música ambiente configurável: **PLANEJADO**

Texturas vanilla originais não estão disponíveis para mim; tudo que depende de recolorir/derivar do vanilla usa arte provisória minha ou ficou PLANEJADO.
