# RELATÓRIO DE TESTES

## Executado (ambiente de escrita)
- Leitura do pacote e dos TXT: OK.
- Inspeção da textura da corrente (Pillow): 16×16 RGBA, 3 cores, transparência real.
- `java -version`: OpenJDK 21 apenas JRE (sem `javac`); o projeto exige JDK 25.
- Acesso a maven.fabricmc.net / services.gradle.org: FALHOU (sem internet).
- Validação de sintaxe de 75 arquivos JSON: OK (só sintaxe, não o conteúdo exigido pelo jogo).
- Balanceamento de chaves/parênteses e pacotes dos 13 arquivos Java: OK (verificação textual; NÃO é compilação).

## NÃO executado
- `gradlew clean build`, `runClient`, qualquer teste no jogo. Não existe JAR.
- Nenhuma receita, bloco, item, mixin ou evento foi carregado no Minecraft.

Atualize este arquivo depois da primeira compilação real.
