# DECISÕES TÉCNICAS

## Versões (gradle.properties)
Minecraft 26.3 · Fabric Loader 0.19.5 · Fabric API 0.161.0+26.3 · Loom 1.18.2 (`net.fabricmc.fabric-loom`) · Gradle 9.7.1 · Java 25.
Origem: releases/wikis de mods de terceiros para 26.3. **Não confirmado em fabricmc.net/develop.**

## Estratégia contra erros (código escrito sem poder compilar)
- Mixins só onde não há evento da Fabric API. Alvos por texto (`targets = "..."`) onde possível, `injectors.defaultRequire = 0` e `required = false`, para que um nome errado desative só aquela mecânica.
- Eventos (`ServerTickEvents`, `ServerLivingEntityEvents`, `AttackEntityCallback`, `UseBlockCallback`) concentrados em `Behaviors.java`.
- Nomes de classes são os da Mojang (Minecraft 26 não é ofuscado), escritos de memória: podem ter erro.

## Valores escolhidos por mim (a especificação não os define; ajuste se quiser)
| Item | Valor | Onde |
|---|---|---|
| Saída das receitas de trilho de cobre e de slime | 6 (igual ao trilho energizado vanilla) | data/.../recipe |
| Saída do ouro-rosa bruto | 1 | recipe |
| Dano extra da espada de ouro | +4 | RandomStuff.GOLD_SWORD_EXTRA_DAMAGE |
| Impulso do trilho de cobre | teto 0.8/0.65/0.5/0.4 blocos/tick por oxidação; aceleração 0.04/0.03/0.015/0 | Behaviors |
| Lançamento do trilho de slime | 0.9 blocos/tick vertical | Behaviors |
| Oxidação do trilho de cobre | 5,69% por random tick por nível | CopperRailBlock |
| Dano do cubo de magma na água | 1 por segundo | Behaviors |
| Raio do aldeão / do golem | 10 / 16 blocos | Behaviors |
| Drop do osso do Wither | 0–2 | Behaviors |
| Velocidade ao rebater projétil | 1.5 | Behaviors |
Receitas de ossos do Wither **não foram criadas** (os TXT mandam não inventar).

## Limitações conhecidas
- Texturas de trilhos, ouro-rosa e osso do Wither são arte provisória minha (sem as texturas vanilla para recolorir).
- A textura da corrente enviada não foi usada: a corrente continua vanilla.
- Minecarts têm limite próprio de velocidade no vanilla; o impulso do cobre pode ser limitado por ele (regra `minecart_max_speed`, nome exato a confirmar no jogo). Os 60 blocos/s não foram implementados.
- Gradle Wrapper: gerado por `compilar.bat` na primeira execução (sem internet aqui para gerar o jar).
