package com.randomstuff.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import java.util.Set;

/** Remove vegetacao (plantas, plantacoes, grama, flores) em 3x3 ao redor do ponto de uso. */
public class WitherBoneMealItem extends Item {
    private static final Set<String> EXTRA_PLANTS = Set.of(
            "short_grass", "grass", "tall_grass", "fern", "large_fern", "dead_bush", "sweet_berry_bush");

    public WitherBoneMealItem(Properties properties) {
        super(properties);
    }

    private static boolean isVegetation(BlockState s) {
        if (s.is(BlockTags.FLOWERS) || s.is(BlockTags.CROPS) || s.is(BlockTags.SAPLINGS)) return true;
        return EXTRA_PLANTS.contains(BuiltInRegistries.BLOCK.getKey(s.getBlock()).getPath());
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel)) return InteractionResult.SUCCESS;
        BlockPos center = context.getClickedPos();
        int removed = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                for (int dy = 0; dy <= 2; dy++) {
                    BlockPos p = center.offset(dx, dy, dz);
                    if (isVegetation(level.getBlockState(p))) {
                        level.destroyBlock(p, false);
                        removed++;
                    }
                }
            }
        }
        if (removed == 0) return InteractionResult.PASS;
        context.getItemInHand().consume(1, context.getPlayer());
        return InteractionResult.SUCCESS;
    }
}
