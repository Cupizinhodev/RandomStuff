package com.randomstuff.mixin;

import com.randomstuff.RandomStuff;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.Items;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Espada de ouro: golpes corpo a corpo recebem dano extra para igualar a espada de netherite. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityMixin {
    @Unique
    private static boolean randomstuff$busy = false;

    @Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true)
    private void randomstuff$goldSword(ServerLevel level, DamageSource source, float amount,
                                       CallbackInfoReturnable<Boolean> cir) {
        if (randomstuff$busy) return;
        if (!(source.getEntity() instanceof LivingEntity attacker)) return;
        if (source.getDirectEntity() != attacker) return;
        if (!source.is(DamageTypes.PLAYER_ATTACK) && !source.is(DamageTypes.MOB_ATTACK)) return;
        if (!attacker.getMainHandItem().is(Items.GOLDEN_SWORD)) return;
        randomstuff$busy = true;
        try {
            cir.setReturnValue(((LivingEntity) (Object) this)
                    .hurtServer(level, source, amount + RandomStuff.GOLD_SWORD_EXTRA_DAMAGE));
        } finally {
            randomstuff$busy = false;
        }
    }
}
