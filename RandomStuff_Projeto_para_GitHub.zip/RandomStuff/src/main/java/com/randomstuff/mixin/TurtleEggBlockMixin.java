package com.randomstuff.mixin;

import com.randomstuff.util.FeatherFalling;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 07: Queda Suave nas botas impede quebrar ovos de tartaruga ao pisar. */
@Mixin(targets = "net.minecraft.world.level.block.TurtleEggBlock")
public abstract class TurtleEggBlockMixin {
    @Inject(method = "destroyEgg", at = @At("HEAD"), cancellable = true)
    private void randomstuff$noCrush(Level level, BlockState state, BlockPos pos, Entity entity, int chance,
                                     CallbackInfo ci) {
        if (FeatherFalling.protects(entity)) ci.cancel();
    }
}
