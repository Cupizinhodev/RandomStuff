package com.randomstuff.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** 09: torna bolas de neve, ovos e cargas de vento "acertaveis" por ataques do jogador. */
@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(method = "isPickable", at = @At("HEAD"), cancellable = true)
    private void randomstuff$pickable(CallbackInfoReturnable<Boolean> cir) {
        EntityType<?> t = ((Entity) (Object) this).getType();
        if (t == EntityType.SNOWBALL || t == EntityType.EGG || t == EntityType.WIND_CHARGE) {
            cir.setReturnValue(true);
        }
    }
}
