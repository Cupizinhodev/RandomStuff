package com.randomstuff.mixin;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** 30: itens cujo id comeca com "netherite_" nao sao destruidos por cactos. */
@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {
    @Inject(method = "hurtServer", at = @At("HEAD"), cancellable = true)
    private void randomstuff$cactus(ServerLevel level, DamageSource source, float amount,
                                    CallbackInfoReturnable<Boolean> cir) {
        if (source.is(DamageTypes.CACTUS)) {
            ItemEntity self = (ItemEntity) (Object) this;
            String path = BuiltInRegistries.ITEM.getKey(self.getItem().getItem()).getPath();
            if (path.startsWith("netherite_")) cir.setReturnValue(false);
        }
    }
}
