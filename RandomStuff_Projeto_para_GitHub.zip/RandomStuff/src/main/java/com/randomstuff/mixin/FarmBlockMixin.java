package com.randomstuff.mixin;

import com.randomstuff.util.FeatherFalling;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** 07: Queda Suave nas botas impede pisotear terra arada. */
@Mixin(targets = "net.minecraft.world.level.block.FarmBlock")
public abstract class FarmBlockMixin {
    @Inject(method = "turnToDirt", at = @At("HEAD"), cancellable = true)
    private static void randomstuff$noTrample(Entity entity, BlockState state, Level level, BlockPos pos,
                                              CallbackInfo ci) {
        if (entity != null && FeatherFalling.protects(entity)) ci.cancel();
    }
}
