package com.randomstuff;

import com.randomstuff.block.CopperRailBlock;
import com.randomstuff.block.SlimeRailBlock;
import java.util.IdentityHashMap;
import java.util.Map;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.tags.FluidTags;
import net.minecraft.tags.ItemTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.phys.Vec3;

/** Mecanicas baseadas em eventos da Fabric API (sem mixin). */
public final class Behaviors {
    private static final Map<EntityType<?>, Boolean> MINECART_CACHE = new IdentityHashMap<>();
    // Velocidade maxima (blocos/tick) e aceleracao do trilho de cobre por nivel de oxidacao.
    private static final double[] COPPER_CAP = {0.8, 0.65, 0.5, 0.4};
    private static final double[] COPPER_ACCEL = {0.04, 0.03, 0.015, 0.0};
    private static final double SLIME_RAIL_LAUNCH = 0.9;

    private Behaviors() {}

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(Behaviors::onServerTick);

        // 01: slimes e cubos de magma nao sofrem dano de queda (outros danos continuam).
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            EntityType<?> t = entity.getType();
            if ((t == EntityType.SLIME || t == EntityType.MAGMA_CUBE) && source.is(DamageTypes.FALL)) {
                return false;
            }
            return true;
        });

        // 13: esqueleto Wither dropa 0-2 ossos do Wither (valor escolhido por mim, ver DECISOES_TECNICAS).
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> {
            if (entity.getType() == EntityType.WITHER_SKELETON && entity.level() instanceof ServerLevel sl) {
                int n = entity.getRandom().nextInt(3);
                if (n > 0) entity.spawnAtLocation(sl, new ItemStack(ModItems.WITHER_BONE, n));
            }
        });

        // 09: rebater bolas de neve, ovos e cargas de vento com um ataque.
        AttackEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            if (!(level instanceof ServerLevel) || player.isSpectator()) return InteractionResult.PASS;
            EntityType<?> t = entity.getType();
            if (t == EntityType.SNOWBALL || t == EntityType.EGG || t == EntityType.WIND_CHARGE) {
                Vec3 look = player.getLookAngle();
                entity.setDeltaMovement(look.scale(1.5));
                if (entity instanceof Projectile p) p.setOwner(player);
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });

        // 21: machado raspa a oxidacao; favo de mel encera o trilho de cobre.
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (!(level instanceof ServerLevel)) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState st = level.getBlockState(pos);
            if (!(st.getBlock() instanceof CopperRailBlock)) return InteractionResult.PASS;
            ItemStack held = player.getItemInHand(hand);
            if (held.is(Items.HONEYCOMB) && !st.getValue(CopperRailBlock.WAXED)) {
                level.setBlock(pos, st.setValue(CopperRailBlock.WAXED, true), 3);
                level.playSound(null, pos, SoundEvents.HONEYCOMB_WAX_ON, SoundSource.BLOCKS, 1.0F, 1.0F);
                held.consume(1, player);
                return InteractionResult.SUCCESS;
            }
            if (held.is(ItemTags.AXES)) {
                BlockState next = null;
                if (st.getValue(CopperRailBlock.WAXED)) next = st.setValue(CopperRailBlock.WAXED, false);
                else if (st.getValue(CopperRailBlock.OXIDATION) > 0)
                    next = st.setValue(CopperRailBlock.OXIDATION, st.getValue(CopperRailBlock.OXIDATION) - 1);
                if (next != null) {
                    level.setBlock(pos, next, 3);
                    level.playSound(null, pos, SoundEvents.AXE_SCRAPE, SoundSource.BLOCKS, 1.0F, 1.0F);
                    held.hurtAndBreak(1, player,
                            hand == InteractionHand.MAIN_HAND ? EquipmentSlot.MAINHAND : EquipmentSlot.OFFHAND);
                    return InteractionResult.SUCCESS;
                }
            }
            return InteractionResult.PASS;
        });
    }

    private static boolean isMinecart(EntityType<?> type) {
        return MINECART_CACHE.computeIfAbsent(type,
                t -> BuiltInRegistries.ENTITY_TYPE.getKey(t).getPath().endsWith("minecart"));
    }

    private static boolean wearsHostileHead(Player p) {
        ItemStack head = p.getItemBySlot(EquipmentSlot.HEAD);
        return head.is(Items.ZOMBIE_HEAD) || head.is(Items.SKELETON_SKULL)
                || head.is(Items.WITHER_SKELETON_SKULL) || head.is(Items.CREEPER_HEAD)
                || head.is(Items.DRAGON_HEAD);
    }

    private static void buoy(Entity e, TagKey<Fluid> fluid) {
        if (e.getFluidHeight(fluid) > 0.4) {
            Vec3 v = e.getDeltaMovement();
            if (v.y < 0.08) e.setDeltaMovement(v.x, Math.min(0.08, v.y + 0.06), v.z);
        }
    }

    private static void onServerTick(MinecraftServer server) {
        for (ServerLevel level : server.getAllLevels()) {
            for (Entity e : level.getAllEntities()) {
                EntityType<?> t = e.getType();
                if (t == EntityType.SLIME) {
                    // 02: slime flutua na agua.
                    if (e.isInWater()) buoy(e, FluidTags.WATER);
                } else if (t == EntityType.MAGMA_CUBE) {
                    // 02: cubo de magma flutua na lava. 31: sofre dano na agua (1 de dano por segundo).
                    if (e.isInLava()) buoy(e, FluidTags.LAVA);
                    if (e.isInWater() && e.tickCount % 20 == 0 && e instanceof LivingEntity le) {
                        le.hurtServer(level, level.damageSources().generic(), 1.0F);
                    }
                } else if (t == EntityType.VILLAGER && e instanceof Mob m && e.tickCount % 5 == 0) {
                    // 06: aldeao segue jogador que segura esmeralda (raio 10).
                    Player p = level.getNearestPlayer(e, 10.0);
                    if (p != null && !p.isSpectator()
                            && (p.getMainHandItem().is(Items.EMERALD) || p.getOffhandItem().is(Items.EMERALD))
                            && e.distanceTo(p) > 2.5F) {
                        m.getNavigation().moveTo(p, 0.6);
                    }
                } else if (t == EntityType.IRON_GOLEM && e instanceof Mob m && e.tickCount % 10 == 0) {
                    // 10: golem ataca jogador com cabeca de mob hostil (raio 16).
                    Player p = level.getNearestPlayer(e, 16.0);
                    if (p != null && !p.isCreative() && !p.isSpectator() && wearsHostileHead(p)
                            && m.getTarget() == null) {
                        m.setTarget(p);
                    }
                } else if (isMinecart(t)) {
                    tickMinecart(level, e);
                }
            }
        }
    }

    private static void tickMinecart(ServerLevel level, Entity cart) {
        BlockPos pos = cart.blockPosition();
        BlockState bs = level.getBlockState(pos);
        if (!(bs.getBlock() instanceof CopperRailBlock) && !(bs.getBlock() instanceof SlimeRailBlock)) {
            bs = level.getBlockState(pos.below());
        }
        Vec3 v = cart.getDeltaMovement();
        if (bs.getBlock() instanceof CopperRailBlock) {
            int ox = bs.getValue(CopperRailBlock.OXIDATION);
            double h = Math.hypot(v.x, v.z);
            if (h > 0.01 && h < COPPER_CAP[ox]) {
                double f = Math.min(COPPER_CAP[ox], h + COPPER_ACCEL[ox]) / h;
                cart.setDeltaMovement(v.x * f, v.y, v.z * f);
            }
        } else if (bs.getBlock() instanceof SlimeRailBlock && v.y < 0.2) {
            cart.setDeltaMovement(0.0, SLIME_RAIL_LAUNCH, 0.0);
        }
    }
}
