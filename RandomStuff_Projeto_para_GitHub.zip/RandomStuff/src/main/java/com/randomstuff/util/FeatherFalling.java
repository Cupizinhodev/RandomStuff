package com.randomstuff.util;

import net.minecraft.core.Holder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.Enchantment;
import net.minecraft.world.item.enchantment.Enchantments;

public final class FeatherFalling {
    private FeatherFalling() {}

    public static boolean protects(Entity entity) {
        if (!(entity instanceof Player player)) return false;
        ItemStack boots = player.getItemBySlot(EquipmentSlot.FEET);
        for (Holder<Enchantment> h : boots.getEnchantments().keySet()) {
            if (h.is(Enchantments.FEATHER_FALLING)) return true;
        }
        return false;
    }
}
