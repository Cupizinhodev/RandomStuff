package com.randomstuff.block;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RailBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;

/** Trilho de cobre: oxida com o tempo (0-3). Encerado (waxed) nao oxida. */
public class CopperRailBlock extends RailBlock {
    public static final IntegerProperty OXIDATION = IntegerProperty.create("oxidation", 0, 3);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");

    public CopperRailBlock(Properties properties) {
        super(properties);
        this.registerDefaultState(this.defaultBlockState().setValue(OXIDATION, 0).setValue(WAXED, false));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(OXIDATION, WAXED);
    }

    @Override
    protected boolean isRandomlyTicking(BlockState state) {
        return !state.getValue(WAXED) && state.getValue(OXIDATION) < 3;
    }

    @Override
    protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (!state.getValue(WAXED) && state.getValue(OXIDATION) < 3 && random.nextFloat() < 0.0569F) {
            level.setBlock(pos, state.setValue(OXIDATION, state.getValue(OXIDATION) + 1), 3);
        }
    }
}
