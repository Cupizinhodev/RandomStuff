package com.randomstuff.block;

import net.minecraft.world.level.block.RailBlock;

/** Trilho de slime: o lancamento vertical e feito em Behaviors (tick do servidor). */
public class SlimeRailBlock extends RailBlock {
    public SlimeRailBlock(Properties properties) {
        super(properties);
    }
}
