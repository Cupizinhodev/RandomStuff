package com.randomstuff;

import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RandomStuff implements ModInitializer {
    public static final String MOD_ID = "randomstuff";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Dano extra somado a golpes de espada de ouro (netherite 8 - ouro 4). Ajustavel. */
    public static final float GOLD_SWORD_EXTRA_DAMAGE = 4.0F;

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModBlocks.register();
        ModItems.register();
        Behaviors.register();
        LOGGER.info("Random Stuff carregado.");
    }
}
