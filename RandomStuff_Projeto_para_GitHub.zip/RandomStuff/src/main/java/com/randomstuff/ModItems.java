package com.randomstuff;

import com.randomstuff.item.WitherBoneMealItem;
import java.util.function.Function;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;

public final class ModItems {
    public static final Item RAW_ROSE_GOLD = register("raw_rose_gold", Item::new);
    public static final Item ROSE_GOLD_INGOT = register("rose_gold_ingot", Item::new);
    public static final Item WITHER_BONE = register("wither_bone", Item::new);
    public static final Item WITHER_BONE_MEAL = register("wither_bone_meal", WitherBoneMealItem::new);

    private ModItems() {}

    private static Item register(String name, Function<Item.Properties, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, RandomStuff.id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(new Item.Properties().setId(key)));
    }

    public static void register() {
        ItemGroupEvents.modifyEntriesEvent(CreativeModeTabs.INGREDIENTS).register(entries -> {
            entries.accept(RAW_ROSE_GOLD);
            entries.accept(ROSE_GOLD_INGOT);
            entries.accept(WITHER_BONE);
            entries.accept(WITHER_BONE_MEAL);
        });
    }
}
