# Random Stuff (Fabric, Minecraft Java 26.3)

**Estado: v0.1.0, primeira versao, AINDA NAO COMPILADA por mim** (o ambiente onde foi escrita nao tem internet nem Java 25). Veja `RELATORIO_DE_TESTES.md`.

## Requisitos
- JDK 25 (Temurin, https://adoptium.net). Nao precisa instalar Gradle.
- Para jogar: Minecraft Java 26.3, Fabric Loader >= 0.19.5 e Fabric API 0.161.0+26.3.

## Compilar (Windows)
Dois cliques em `03_SCRIPTS\compilar.bat`. Na primeira vez ele baixa o Gradle 9.7.1 e gera o wrapper.
O mod final e `build/libs/randomstuff-0.1.0.jar`.

## Compilar sem instalar nada (GitHub Actions)
Envie o conteudo desta pasta `RandomStuff` (inclusive `.github`) para a raiz de um repositorio publico. Na aba Actions, o JAR sai em "Artifacts".

## Instalar
Copie `randomstuff-0.1.0.jar` e a Fabric API para `%appdata%\.minecraft\mods` (perfil Fabric 26.3).

## Testar no ambiente de desenvolvimento
`03_SCRIPTS\testar_cliente.bat` (executa `gradlew runClient`).

## Mecânicas incluídas
Veja `STATUS_DAS_IDEIAS.md` e `COMO_TESTAR.md`.
