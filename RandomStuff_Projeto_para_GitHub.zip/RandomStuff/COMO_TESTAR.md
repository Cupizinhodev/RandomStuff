# COMO TESTAR (depois de compilar e instalar)

Crie um mundo Criativo. Se o jogo travar ao abrir, envie o arquivo `logs/latest.log` (ou `crash-reports`).

## Itens e blocos (abra o chat com T)
```
/give @s randomstuff:copper_rail 16
/give @s randomstuff:slime_rail 16
/give @s randomstuff:raw_rose_gold 4
/give @s randomstuff:rose_gold_ingot 4
/give @s randomstuff:wither_bone 4
/give @s randomstuff:wither_bone_meal 4
/give @s randomstuff:wither_bone_block 4
```
## Testes por mecânica
- Receitas (modo Sobrevivência): trilho de cobre (6 cobre + 2 redstone + 1 graveto), trilho de slime (6 ferro + 2 redstone + 1 bloco de slime), ouro-rosa bruto (4 cobre bruto + 4 ouro bruto); fundir na fornalha.
- Cortador de pedra: tronco de carvalho -> tronco de carvalho descascado.
- Corrente (ideia 4): subir pela corrente encostado nela.
- Trilho de cobre: vagoneta empurrada sobre ele deve acelerar; machado raspa oxidação; favo de mel encera.
- Trilho de slime: vagoneta passando é lançada para cima.
- Slime: `/summon slime ~ ~ ~` e jogue-o na água; cair de altura não deve causar dano.
- Cubo de magma: `/summon magma_cube` na água perde vida; na lava flutua.
- Aldeão segue esmeralda; golem ataca com cabeça de zumbi/esqueleto/creeper equipada (modo Sobrevivência).
- Botas com Queda Suave: pular sobre terra arada e ovo de tartaruga não os destrói.
- Bola de neve / ovo / carga de vento: bata nela no ar.
- Espada de ouro: bata num mob e compare com espada de netherite.
- Netherite: solte um item de netherite sobre um cacto.
- Farinha de osso do Wither: use sobre grama/flores; esqueleto Wither dropa ossos.
Anote o que funcionou e o que não; envie para eu atualizar o STATUS.
