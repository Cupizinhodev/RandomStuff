REGRAS PARA QUALQUER CLAUDE QUE MEXER NESTE PROJETO (Random Stuff - Fabric 26.3)
=======================================================================
LEIA ISTO ANTES DE TOCAR EM QUALQUER ARQUIVO.

1. VOCE NAO COMPILA E NAO TESTA. Nao rode gradle/gradlew, nao gere .jar, nao abra o Minecraft.
   Quem compila, roda e testa o mod e o REPLIT. Voce so le, edita arquivos e escreve instrucoes.

2. TUDO o que voce NAO conseguiu corrigir com certeza, ou que precisa ser compilado/testado no jogo,
   deve ser escrito em TAREFAS_REPLIT.txt (arquivo na raiz). Para cada item escreva:
     - o que e (uma frase) e em qual arquivo/linha;
     - o que o Replit deve fazer (comando, classe a conferir com javap, ou o codigo sugerido);
     - como testar no jogo (passo a passo, resultado esperado).
   Nao apague itens antigos: so o Replit marca [X] depois de testar.

3. NUNCA diga que algo "funciona" ou "esta corrigido" se nao foi compilado e testado. Diga "corrigido no codigo,
   NAO testado" e registre em TAREFAS_REPLIT.txt.

4. NUNCA invente API do Minecraft 26.3. Se nao tiver certeza do nome de uma classe/metodo, deixe a mudanca como
   tarefa para o Replit (que confere com javap / bash scripts/extrair_referencias.sh) em vez de chutar.

5. ESTRUTURA FABRIC 26.3 (igual ao template fabric-example-mod-26.3) - NAO MUDE:
     build.gradle, settings.gradle, gradle.properties (so modid/group), gradle/wrapper/*, gradlew(.bat), .github/workflows/build.yml
     src/main/java + src/main/resources  -> codigo/recursos comuns (assets/ e data/ ficam aqui)
     src/client/java + src/client/resources -> codigo/recursos so do cliente (renderers, comandos de cliente, randomstuff.client.mixins.json)
     Mixins comuns:  package com.randomstuff.mixin   | listados em src/main/resources/randomstuff.mixins.json
     Mixins cliente: package com.randomstuff.client.mixin | listados em src/client/resources/randomstuff.client.mixins.json
   Java 25, Minecraft 26.3, Loader 0.19.5, Loom 1.18-SNAPSHOT, Fabric API 0.163.0+26.3, Gradle 9.7.1.
   Todo mixin novo precisa ser adicionado no .mixins.json correspondente (senao nao carrega).

6. NOMES: o id da vaca e MOOBLOOM (dois "o" em "bloom"). O erro antigo "mooblom" ja foi corrigido; nao reintroduza.
   Todo item/bloco novo precisa de: registro Java, items/<nome>.json, models/item (ou block), blockstate (se bloco),
   textura, traducao em lang/pt_br.json E lang/en_us.json, e (se bloco) loot_table/blocks/<nome>.json.
   Em blockstates e modelos use SEMPRE o caminho completo: "randomstuff:block/<modelo>" ou "randomstuff:item/<modelo>".

7. Sprites originais em assets_originais/ NAO podem ser alterados. Nao copie codigo GPL (Slabbed) nem ARR (Improvement Minecarts).

8. Antes de entregar, rode as checagens estaticas (nao compilam, so conferem arquivos):
     python3 scripts/validar_projeto.py
     python3 scripts/validar_assets.py
   e atualize docs/PROGRESSO.md com o que mudou e o que ficou pendente. Mantenha esta regra no topo de
   LEIA_PRIMEIRO.txt e PROMPT_PARA_REPLIT.txt.
