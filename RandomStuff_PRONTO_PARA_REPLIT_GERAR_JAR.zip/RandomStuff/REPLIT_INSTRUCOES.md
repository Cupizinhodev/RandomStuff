# RANDOM STUFF — ENTREGA PARA O REPLIT

## Objetivo

Gerar o JAR de distribuicao do mod Fabric **Random Stuff** para **Minecraft Java 26.3**, preservando as funcionalidades, os assets e a estrutura atual. O Replit deve corrigir os erros reais que impedirem a compilacao, sem remover recursos para "fazer compilar".

## Primeiro passo

1. Importe este ZIP no Replit como projeto existente. Abra a pasta `RandomStuff` (a pasta que contem `settings.gradle`, `build.gradle`, `gradlew` e `src/`) como raiz do projeto.
2. Abra `TAREFAS_REPLIT.txt`, `LEIA_PRIMEIRO.txt`, `docs/PROGRESSO.md`, `docs/PLANO_ETAPAS.md` e os relatórios de etapas. Eles descrevem o estado e as limitações conhecidas.
3. Configure **JDK 25** no ambiente Replit. Confirme com `java -version`. Não tente contornar erro de Java usando versão 21 ou inferior.
4. Não instale Gradle globalmente: use o Gradle Wrapper que já está incluído (`./gradlew`).

## Comando principal

No Shell, execute apenas:

```bash
bash scripts/compilar_replit.sh
```

O script executa os validadores estáticos, `clean build`, localiza o JAR remapeado de distribuição, confere a integridade ZIP e os metadados Fabric, copia o artefato para `entrega/` e gera SHA-256. Ele **não inicia Minecraft nem servidor**.

## Instruções para o agente Replit

- Faça uma leitura do projeto antes de editar. É um projeto Fabric com source sets separados `src/main` e `src/client`; não misture código client-only no source set principal.
- Alvo obrigatório: Minecraft `26.3`, Java `25`, Fabric Loader `0.19.5` ou compatível com 26.3, Fabric API `0.163.0+26.3` e Fabric Loom estável `1.18.4` (configuração já preparada). O Gradle Wrapper está fixado no projeto; não o substitua sem evidência de incompatibilidade.
- O identificador do mod é `randomstuff`; classe principal `com.randomstuff.RandomStuffMod`; classe client `com.randomstuff.client.RandomStuffClient`.
- Preserve `fabric.mod.json`, ambos os arquivos de mixin, todos os JSONs, traduções, modelos, texturas, sons, receitas, loot tables, estruturas, assets originais e documentação.
- Rode os dois validadores Python antes de compilar. Corrija erros de validação sem apagar verificações ou reduzir o escopo.
- Rode o comando principal. Se falhar, leia o primeiro erro causal do log completo `logs/build-replit.log` (não trate mensagens em cascata como causas independentes).
- Corrija incompatibilidades reais de Gradle/Loom, imports, nomes de métodos, assinaturas, mixins, accessors e recursos para a API de Minecraft 26.3. Consulte documentação/código-fonte oficial da versão e confira a assinatura antes de alterar chamadas.
- Depois de cada correção, rode novamente os validadores e a compilação. Continue até obter `BUILD SUCCESSFUL` e o JAR remapeado passar na conferência automatizada.
- Não faça alterações cosméticas, não reescreva sistemas inteiros sem necessidade e não remova uma funcionalidade, mixin, asset ou regra apenas para obter compilação. Se uma função exigir mudança maior ou não puder ser corrigida com segurança, preserve o código e registre o bloqueio com arquivo, erro e evidência em `TAREFAS_REPLIT.txt`.
- Não altere o alvo do Minecraft para outra versão. Não troque Fabric por Forge/NeoForge. Não use dependências de versões incompatíveis.
- Não declare que uma funcionalidade está funcionando no jogo só porque compilou. A tarefa aqui é gerar e inspecionar o JAR; os testes in-game/servidor serão feitos separadamente pelo usuário.

## Entrega obrigatória

Após sucesso, deixe disponíveis:

- `entrega/randomstuff-1.0.0.jar` (ou o nome final equivalente definido pelo `version`/`archivesName`, sempre o JAR de distribuição sem `-dev` e sem `-sources`);
- `entrega/SHA256SUMS.txt`;
- `logs/build-replit.log`;
- `build/libs/` com os artefatos originais do Gradle.

Na resposta final, informe claramente:

1. se o Gradle terminou com `BUILD SUCCESSFUL`;
2. nome, tamanho e SHA-256 do JAR;
3. resultado da inspeção do conteúdo e metadados do JAR;
4. quais erros foram corrigidos;
5. quaisquer pendências que ainda impeçam uma entrega completa.

Não entregue somente `*-dev.jar`, `*-sources.jar`, nem o ZIP do projeto como se fossem o mod instalável. O JAR de distribuição é o produzido pelo `remapJar`/`build` do Loom.
