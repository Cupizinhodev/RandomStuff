#!/usr/bin/env bash
# Depois que o projeto COMPILAR (ou mesmo se falhar depois de baixar o Minecraft), rode:
#   bash scripts/extrair_referencias.sh
# Ele procura o jar do Minecraft que o Gradle baixou e cria referencias_minecraft.zip com:
#  - dados do jogo (arquétipos do Cubo de Enxofre, encantamentos de exemplo, receitas) e
#  - a assinatura (javap) das classes que o mod usa, para o Claude conferir nomes REAIS em vez de adivinhar.
# Envie o referencias_minecraft.zip na conversa.
set -u
cd "$(dirname "$0")/.."
OUT=referencias_minecraft
rm -rf "$OUT" "$OUT.zip"; mkdir -p "$OUT/dados" "$OUT/javap"

JAR=$(find "$HOME/.gradle" .gradle "$HOME/.cache" -name "*.jar" 2>/dev/null | grep -i -E "minecraft" | grep -i -E "merged|client-intermediary|mapped|minecraft-26" | head -1)
if [ -z "$JAR" ]; then
  echo "Nao achei o jar do Minecraft. Rode antes: ./gradlew build   (ele baixa o jogo)"; exit 1
fi
echo "Jar encontrado: $JAR"
unzip -q -o "$JAR" 'data/minecraft/sulfur_cube_archetype/*' 'data/minecraft/enchantment/frost_walker.json' \
  'data/minecraft/enchantment/feather_falling.json' 'data/minecraft/tags/enchantment/*' 'data/minecraft/tags/item/sulfur_cube_archetype/*' \
  'data/minecraft/recipe/brush.json' 'data/minecraft/recipe/hopper.json' -d "$OUT/dados" 2>/dev/null
unzip -l "$JAR" | awk '{print $4}' | grep -E '\.class$' > "$OUT/lista_de_classes.txt"

for C in net.minecraft.world.item.Item\$Properties net.minecraft.world.item.BrushItem net.minecraft.world.item.SpearItem \
  net.minecraft.world.level.block.entity.BeaconBlockEntity net.minecraft.world.level.block.HopperBlock \
  net.minecraft.world.level.block.entity.HopperBlockEntity net.minecraft.world.entity.monster.cubemob.SulfurCube \
  net.minecraft.world.entity.Mob net.minecraft.world.entity.item.ItemEntity net.minecraft.world.entity.projectile.Projectile \
  net.minecraft.world.entity.vehicle.minecart.AbstractMinecart net.minecraft.world.entity.decoration.ItemFrame \
  net.minecraft.world.level.block.state.BlockBehaviour\$Properties net.minecraft.world.level.block.FlowerBlock \
  net.minecraft.world.entity.animal.cow.Cow net.minecraft.world.entity.animal.fox.Fox \
  net.minecraft.world.entity.monster.cubemob.AbstractCubeMob net.minecraft.world.entity.monster.cubemob.Slime \
  net.minecraft.world.entity.monster.cubemob.MagmaCube net.minecraft.world.entity.EntityTypes \
  net.minecraft.world.entity.SpawnPlacements net.minecraft.world.entity.SpawnPlacementTypes \
  net.minecraft.world.entity.Entity net.minecraft.world.entity.LivingEntity net.minecraft.world.entity.Mob \
  net.minecraft.world.entity.EntitySpawnReason net.minecraft.world.damagesource.DamageSource \
  net.minecraft.world.damagesource.DamageTypes net.minecraft.world.entity.animal.Animal \
  net.minecraft.world.item.DyeColor net.minecraft.world.item.DyeItem net.minecraft.world.level.block.SlimeBlock \
  net.minecraft.world.level.storage.ValueInput net.minecraft.world.level.storage.ValueOutput \
  net.minecraft.network.syncher.SynchedEntityData net.minecraft.network.syncher.EntityDataAccessor \
  net.minecraft.network.syncher.EntityDataSerializers net.minecraft.world.item.ItemUtils \
  net.minecraft.client.renderer.entity.LivingEntityRenderer net.minecraft.client.renderer.entity.SlimeRenderer \
  net.minecraft.client.renderer.entity.state.SlimeRenderState net.minecraft.client.renderer.entity.state.LivingEntityRenderState \
  net.minecraft.client.renderer.entity.FoxRenderer net.minecraft.world.entity.animal.fox.Fox \
  net.minecraft.client.renderer.entity.CowRenderer net.minecraft.client.renderer.entity.state.FoxRenderState \
  net.minecraft.client.renderer.entity.state.CowRenderState \
  net.minecraft.client.renderer.block.BlockModelResolver \
  net.minecraft.client.renderer.block.BlockDecorationLayer; do
  javap -p -cp "$JAR" "$C" > "$OUT/javap/$C.txt" 2>&1
done
# classes cujo nome exato nao sei: lista tudo que contem estas palavras
grep -i -E 'sulfur|spear|minecart|beacon|itemframe|ItemFrame|slime|magma|fox|cow|BlockModelResolver|BlockDecorationLayer' "$OUT/lista_de_classes.txt" > "$OUT/classes_relevantes.txt"
zip -q -r "$OUT.zip" "$OUT"
echo "Pronto: $OUT.zip  (envie este arquivo ao Claude)"
