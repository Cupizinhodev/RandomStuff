@echo off
REM Compila o Random Stuff no Windows. Requer JDK 25 instalado.
cd /d "%~dp0\.."
call gradlew.bat build
if errorlevel 1 (
  echo FALHOU. Envie o erro completo ao Claude.
  exit /b 1
)
echo SUCESSO. Veja a pasta build\libs\
