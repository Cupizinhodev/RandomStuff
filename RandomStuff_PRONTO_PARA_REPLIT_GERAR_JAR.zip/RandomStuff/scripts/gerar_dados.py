#!/usr/bin/env python3
"""Gera VariantList.java + todos os JSON (modelos, blockstates, itens, receitas, loot, tags, idiomas) da Etapa 1.
Uso (na raiz do projeto):  python3 scripts/gerar_dados.py
Os arquivos gerados ja vem no ZIP; este script so e necessario para alterar as listas abaixo."""
import json, os
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources"
A = RES / "assets/randomstuff"
D = RES / "data/randomstuff"
M = "randomstuff"

def w(path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

def tag(path, values):
    p = RES/"data"/path
    if p.exists() and path.startswith('minecraft/tags/item/') and not hasattr(tag,'fresh'): pass
    w(p, {"replace":False,"values":values})

lang_en, lang_pt = {}, {}
def name(key, en, pt): lang_en[key] = en; lang_pt[key] = pt

COLORS = [("white","White","Branca","Branco"),("orange","Orange","Laranja","Laranja"),("magenta","Magenta","Magenta","Magenta"),
 ("light_blue","Light Blue","Azul-clara","Azul-claro"),("yellow","Yellow","Amarela","Amarelo"),("lime","Lime","Verde-lima","Verde-lima"),
 ("pink","Pink","Rosa","Rosa"),("gray","Gray","Cinza","Cinza"),("light_gray","Light Gray","Cinza-clara","Cinza-claro"),
 ("cyan","Cyan","Ciano","Ciano"),("purple","Purple","Roxa","Roxo"),("blue","Blue","Azul","Azul"),("brown","Brown","Marrom","Marrom"),
 ("green","Green","Verde","Verde"),("red","Red","Vermelha","Vermelho"),("black","Black","Preta","Preto")]

# ---- variantes: (nome, tipo, bloco_base_vanilla, textura bottom, top, side, en, pt, ferramenta)
def tex(b=None, t=None, s=None): return (b or s, t or s, s)
SL = []  # (nome_base, base, (bottom,top,side), en, pt, tool, [kinds])
SL += [("basalt","basalt",tex(t="block/basalt_top",s="block/basalt_side"),"Basalt","Basalto","pickaxe",["slab"]),
 ("polished_basalt","polished_basalt",tex(t="block/polished_basalt_top",s="block/polished_basalt_side"),"Polished Basalt","Basalto Polido","pickaxe",["slab"]),
 ("end_stone","end_stone",tex(s="block/end_stone"),"End Stone","Pedra do End","pickaxe",["slab"]),
 ("smooth_stone","smooth_stone",tex(s="block/smooth_stone"),"Smooth Stone","Pedra Lisa","pickaxe",["stairs"]),
 ("cut_sandstone","cut_sandstone",tex(b="block/sandstone_bottom",t="block/sandstone_top",s="block/cut_sandstone"),"Cut Sandstone","Arenito Talhado","pickaxe",["stairs"]),
 ("cut_red_sandstone","cut_red_sandstone",tex(b="block/red_sandstone_bottom",t="block/red_sandstone_top",s="block/cut_red_sandstone"),"Cut Red Sandstone","Arenito Vermelho Talhado","pickaxe",["stairs"]),
 ("quartz_bricks","quartz_bricks",tex(s="block/quartz_bricks"),"Quartz Bricks","Tijolos de Quartzo","pickaxe",["slab","stairs"]),
 ("moss","moss_block",tex(s="block/moss_block"),"Moss","Musgo","hoe",["slab","stairs"]),
 ("magma","magma_block",tex(s="block/magma"),"Magma","Magma","pickaxe",["slab","stairs"]),
 ("amethyst","amethyst_block",tex(s="block/amethyst_block"),"Amethyst","Ametista","pickaxe",["slab","stairs"])]
# nomes de display no idioma: Slab/Stairs
WALLS = [("amethyst","amethyst_block","block/amethyst_block","Amethyst","Ametista"),
 ("quartz","quartz_block","block/quartz_block_side","Quartz","Quartzo"),
 ("dark_prismarine","dark_prismarine","block/dark_prismarine","Dark Prismarine","Prismarine Escura"),
 ("prismarine_bricks","prismarine_bricks","block/prismarine_bricks","Prismarine Bricks","Tijolos de Prismarine"),
 ("terracotta","terracotta","block/terracotta","Terracotta","Terracota")]
for c,en,ptf,ptm in COLORS:
    WALLS.append((f"{c}_terracotta", f"{c}_terracotta", f"block/{c}_terracotta", f"{en} Terracotta", f"Terracota {ptf}"))
for c,en,ptf,ptm in COLORS:
    WALLS.append((f"{c}_concrete", f"{c}_concrete", f"block/{c}_concrete", f"{en} Concrete", f"Concreto {ptm}"))

entries = []  # para Java: (nome, base, kind)
tool_pick, tool_hoe, tool_axe = [], [], []
all_slab, all_stairs, all_wall = [], [], []
blocks_self_drop = []

def tag_tool(n, tool): {"pickaxe":tool_pick,"hoe":tool_hoe,"axe":tool_axe}[tool].append(f"{M}:{n}")

def item_def(n, model=None):
    w(A/"items"/f"{n}.json", {"model":{"type":"minecraft:model","model":model or f"{M}:item/{n}"}})
def item_flat(n, tex_path):
    w(A/"models/item"/f"{n}.json", {"parent":"minecraft:item/generated","textures":{"layer0":tex_path}}); item_def(n)
def item_block(n, block_model=None):
    item_def(n, block_model or f"{M}:block/{n}")
def loot_self(n, slab=False):
    entry = {"type":"minecraft:item","name":f"{M}:{n}"}
    if slab:
        entry["functions"] = [{"function":"minecraft:set_count","count":2,"add":False,
            "conditions":[{"condition":"minecraft:block_state_property","block":f"{M}:{n}","properties":{"type":"double"}}]},
            {"function":"minecraft:explosion_decay"}]
    w(D/"loot_table/blocks"/f"{n}.json", {"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,
        "entries":[entry],"conditions":[{"condition":"minecraft:survives_explosion"}]}]} if not slab else
        {"type":"minecraft:block","pools":[{"rolls":1,"bonus_rolls":0,"entries":[entry]}]})
def recipe(n, obj): w(D/"recipe"/f"{n}.json", obj)
def stonecut(n, ing, res, cnt): recipe(f"{n}_from_stonecutting", {"type":"minecraft:stonecutting","ingredient":ing,"result":{"id":f"{M}:{n}","count":cnt}})

for (nb, base, (tb,tt,ts), en, pt, tool, kinds) in SL:
    for kind in kinds:
        n = f"{nb}_{kind}"
        entries.append((n, base, kind.upper())); tag_tool(n, tool); blocks_self_drop.append(n)
        if kind == "slab":
            all_slab.append(f"{M}:{n}")
            name(f"block.{M}.{n}", f"{en} Slab", f"Laje de {pt}")
            tx = {"bottom":tb,"top":tt,"side":ts}
            w(A/"models/block"/f"{n}.json", {"parent":"minecraft:block/slab","textures":tx})
            w(A/"models/block"/f"{n}_top.json", {"parent":"minecraft:block/slab_top","textures":tx})
            w(A/"blockstates"/f"{n}.json", {"variants":{"type=bottom":{"model":f"{M}:block/{n}"},"type=top":{"model":f"{M}:block/{n}_top"},
                "type=double":{"model":f"minecraft:block/{base}"}}})
            item_block(n); loot_self(n, slab=True)
            recipe(n, {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"minecraft:{base}"},"pattern":["###"],"result":{"id":f"{M}:{n}","count":6}})
            stonecut(n, f"minecraft:{base}", n, 2)
        else:
            all_stairs.append(f"{M}:{n}")
            name(f"block.{M}.{n}", f"{en} Stairs", f"Escada de {pt}")
            tx = {"bottom":tb,"top":tt,"side":ts}
            for suf, par in (("","stairs"),("_inner","inner_stairs"),("_outer","outer_stairs")):
                w(A/"models/block"/f"{n}{suf}.json", {"parent":f"minecraft:block/{par}","textures":tx})
            rot = {"bottom":{"east":0,"west":180,"south":90,"north":270},"top":{"east":0,"west":180,"south":90,"north":270}}
            shapes = {"straight":(0,""),"inner_left":(-90,"_inner"),"inner_right":(0,"_inner"),"outer_left":(-90,"_outer"),"outer_right":(0,"_outer")}
            variants = {}
            for half in ("bottom","top"):
                for facing, y0 in rot[half].items():
                    for shp,(dy,suf) in shapes.items():
                        y = y0 if shp=="straight" else (y0+dy) % 360
                        # no 'top' as formas inner/outer left/right deslocam diferentemente (padrao do jogo)
                        if half=="top" and shp!="straight":
                            y = (y0 + (0 if shp.endswith("left") else 90)) % 360
                        v = {"model":f"{M}:block/{n}{suf}","uvlock":True}
                        if half=="top": v["x"]=180
                        if y: v["y"]=y
                        variants[f"facing={facing},half={half},shape={shp}"]=v
            w(A/"blockstates"/f"{n}.json", {"variants":variants})
            item_block(n); loot_self(n)
            recipe(n, {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"minecraft:{base}"},"pattern":["#  ","## ","###"],"result":{"id":f"{M}:{n}","count":4}})
            stonecut(n, f"minecraft:{base}", n, 1)

for (nb, base, tx, en, pt) in WALLS:
    n = f"{nb}_wall"; entries.append((n, base, "WALL")); tool_pick.append(f"{M}:{n}"); all_wall.append(f"{M}:{n}"); blocks_self_drop.append(n)
    name(f"block.{M}.{n}", f"{en} Wall", f"Muro de {pt}")
    for suf, par in (("_post","template_wall_post"),("_side","template_wall_side"),("_side_tall","template_wall_side_tall"),("_inventory","wall_inventory")):
        w(A/"models/block"/f"{n}{suf}.json", {"parent":f"minecraft:block/{par}","textures":{"wall":tx}})
    mp = [{"when":{"up":"true"},"apply":{"model":f"{M}:block/{n}_post"}}]
    for kind,suf in (("low","_side"),("tall","_side_tall")):
        for d,y in (("north",0),("east",90),("south",180),("west",270)):
            ap = {"model":f"{M}:block/{n}{suf}","uvlock":True}
            if y: ap["y"]=y
            mp.append({"when":{d:kind},"apply":ap})
    w(A/"blockstates"/f"{n}.json", {"multipart":mp})
    item_block(n, f"{M}:block/{n}_inventory"); loot_self(n)
    recipe(n, {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"minecraft:{base}"},"pattern":["###","###"],"result":{"id":f"{M}:{n}","count":6}})
    stonecut(n, f"minecraft:{base}", n, 1)

# ---- Ouro Rosa
name(f"item.{M}.raw_rose_gold","Raw Rose Gold","Ouro Rosa Bruto"); name(f"item.{M}.rose_gold_ingot","Rose Gold Ingot","Lingote de Ouro Rosa")
name(f"block.{M}.rose_gold_block","Block of Rose Gold","Bloco de Ouro Rosa"); name(f"block.{M}.raw_rose_gold_block","Block of Raw Rose Gold","Bloco de Ouro Rosa Bruto")
for n,t in (("raw_rose_gold","item/raw_rose_gold"),("rose_gold_ingot","item/rose_gold_ingot")): item_flat(n, f"{M}:{t}")
for n in ("rose_gold_block","raw_rose_gold_block"):
    w(A/"models/block"/f"{n}.json", {"parent":"minecraft:block/cube_all","textures":{"all":f"{M}:block/{n}"}})
    w(A/"blockstates"/f"{n}.json", {"variants":{"":{"model":f"{M}:block/{n}"}}}); item_block(n); loot_self(n); tool_pick.append(f"{M}:{n}")
recipe("raw_rose_gold", {"type":"minecraft:crafting_shaped","category":"misc","key":{"C":"minecraft:raw_copper","A":"minecraft:amethyst_shard","O":"minecraft:raw_gold"},
    "pattern":["CCC","CAO","OOO"],"result":{"id":f"{M}:raw_rose_gold","count":1}})
for typ,t,cat in (("smelting",200,"misc"),("blasting",100,"misc")):
    recipe(f"rose_gold_ingot_from_{typ}", {"type":f"minecraft:{typ}","category":cat,"ingredient":f"{M}:raw_rose_gold","result":{"id":f"{M}:rose_gold_ingot"},"experience":1.0,"cookingtime":t})
recipe("rose_gold_block", {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"{M}:rose_gold_ingot"},"pattern":["###","###","###"],"result":{"id":f"{M}:rose_gold_block","count":1}})
recipe("rose_gold_ingot_from_block", {"type":"minecraft:crafting_shapeless","category":"misc","ingredients":[f"{M}:rose_gold_block"],"result":{"id":f"{M}:rose_gold_ingot","count":9}})
recipe("raw_rose_gold_block", {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"{M}:raw_rose_gold"},"pattern":["###","###","###"],"result":{"id":f"{M}:raw_rose_gold_block","count":1}})
recipe("raw_rose_gold_from_block", {"type":"minecraft:crafting_shapeless","category":"misc","ingredients":[f"{M}:raw_rose_gold_block"],"result":{"id":f"{M}:raw_rose_gold","count":9}})

# ---- Osso de Wither
name(f"item.{M}.wither_bone","Wither Bone","Osso de Wither"); name(f"item.{M}.wither_bone_meal","Wither Bone Meal","Farinha de Osso de Wither")
name(f"block.{M}.wither_bone_block","Wither Bone Block","Bloco de Osso de Wither")
item_flat("wither_bone", f"{M}:item/wither_bone"); item_flat("wither_bone_meal", f"{M}:item/wither_bone_meal")
w(A/"models/block/wither_bone_block.json", {"parent":"minecraft:block/cube_column","textures":{"end":f"{M}:block/wither_bone_block_top","side":f"{M}:block/wither_bone_block_side"}})
w(A/"models/block/wither_bone_block_horizontal.json", {"parent":"minecraft:block/cube_column_horizontal","textures":{"end":f"{M}:block/wither_bone_block_top","side":f"{M}:block/wither_bone_block_side"}})
w(A/"blockstates/wither_bone_block.json", {"variants":{"axis=y":{"model":f"{M}:block/wither_bone_block"},
    "axis=z":{"model":f"{M}:block/wither_bone_block_horizontal","x":90},"axis=x":{"model":f"{M}:block/wither_bone_block_horizontal","x":90,"y":90}}})
item_block("wither_bone_block"); loot_self("wither_bone_block"); tool_pick.append(f"{M}:wither_bone_block")
recipe("wither_bone_meal", {"type":"minecraft:crafting_shapeless","category":"misc","ingredients":[f"{M}:wither_bone"],"result":{"id":f"{M}:wither_bone_meal","count":3}})
recipe("wither_bone_block", {"type":"minecraft:crafting_shaped","category":"building","key":{"#":f"{M}:wither_bone_meal"},"pattern":["###","###","###"],"result":{"id":f"{M}:wither_bone_block","count":1}})
recipe("wither_bone_meal_from_block", {"type":"minecraft:crafting_shapeless","category":"misc","ingredients":[f"{M}:wither_bone_block"],"result":{"id":f"{M}:wither_bone_meal","count":9}})

# ---- Abobora Branca
name(f"block.{M}.white_pumpkin","White Pumpkin","Abóbora Branca"); name(f"block.{M}.carved_white_pumpkin","Carved White Pumpkin","Abóbora Branca Entalhada")
name(f"block.{M}.white_jack_o_lantern","White Jack o'Lantern","Jack o'Lantern Branca")
w(A/"models/block/white_pumpkin.json", {"parent":"minecraft:block/cube_column","textures":{"end":f"{M}:block/white_pumpkin_top","side":f"{M}:block/white_pumpkin_side"}})
w(A/"blockstates/white_pumpkin.json", {"variants":{"":{"model":f"{M}:block/white_pumpkin"}}}); item_block("white_pumpkin")
for n,t in (("carved_white_pumpkin","carved_white_pumpkin"),("white_jack_o_lantern","white_jack_o_lantern")):
    w(A/"models/block"/f"{n}.json", {"parent":"minecraft:block/orientable","textures":{"top":f"{M}:block/white_pumpkin_top","front":f"{M}:block/{t}","side":f"{M}:block/white_pumpkin_side"}})
    w(A/"blockstates"/f"{n}.json", {"variants":{f"facing={f}":({"model":f"{M}:block/{n}","y":y} if y else {"model":f"{M}:block/{n}"}) for f,y in (("north",0),("east",90),("south",180),("west",270))}})
    item_block(n); loot_self(n)
loot_self("white_pumpkin")
tool_axe += [f"{M}:white_pumpkin",f"{M}:carved_white_pumpkin",f"{M}:white_jack_o_lantern"]
recipe("white_jack_o_lantern", {"type":"minecraft:crafting_shaped","category":"building","key":{"A":f"{M}:carved_white_pumpkin","B":"minecraft:soul_torch"},"pattern":["A","B"],"result":{"id":f"{M}:white_jack_o_lantern","count":1}})
recipe("pumpkin_seeds_from_white_pumpkin", {"type":"minecraft:crafting_shapeless","category":"misc","ingredients":[f"{M}:white_pumpkin"],"result":{"id":"minecraft:pumpkin_seeds","count":4}})


# ---- Molde de ferraria do Ouro Rosa (item simples; vira SmithingTemplateItem na Etapa 1b)
name(f"item.{M}.rose_gold_upgrade_smithing_template","Smithing Template: Rose Gold Upgrade","Molde de Ferraria: Melhoria de Ouro Rosa")
item_flat("rose_gold_upgrade_smithing_template", f"{M}:item/rose_gold_upgrade_smithing_template")

# ---- Esqueleto Wither: dropa Osso de Wither no lugar do osso normal (substitui a tabela vanilla)
def _cnt(lo, hi): return {"type":"minecraft:uniform","min":lo,"max":hi}
def _loot(lo, hi): return {"function":"minecraft:enchanted_count_increase","enchantment":"minecraft:looting","count":_cnt(0.0,1.0)}
w(RES/"data/minecraft/loot_table/entities/wither_skeleton.json", {"type":"minecraft:entity","pools":[
 {"rolls":1.0,"bonus_rolls":0.0,"entries":[{"type":"minecraft:item","name":"minecraft:coal","functions":[
   {"function":"minecraft:set_count","count":_cnt(-1.0,1.0),"add":False},_loot(0,1)]}]},
 {"rolls":1.0,"bonus_rolls":0.0,"entries":[{"type":"minecraft:item","name":f"{M}:wither_bone","functions":[
   {"function":"minecraft:set_count","count":_cnt(0.0,2.0),"add":False},_loot(0,1)]}]},
 {"rolls":1.0,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:killed_by_player"},
   {"condition":"minecraft:random_chance_with_enchanted_bonus","enchantment":"minecraft:looting",
    "unenchanted_chance":0.025,"enchanted_chance":{"type":"minecraft:linear","base":0.04,"per_level_above_first":0.01}}],
  "entries":[{"type":"minecraft:item","name":"minecraft:wither_skeleton_skull"}]}],
 "random_sequence":"minecraft:entities/wither_skeleton"})

# ---- Equipamentos de Ouro Rosa (Etapa 1b): obtidos so por ferraria (ouro -> ouro rosa), como a Netherite
EQUIP = [("sword","golden_sword","Sword","Espada","handheld","swords"),("pickaxe","golden_pickaxe","Pickaxe","Picareta","handheld","pickaxes"),
 ("axe","golden_axe","Axe","Machado","handheld","axes"),("shovel","golden_shovel","Shovel","Pá","handheld","shovels"),
 ("hoe","golden_hoe","Hoe","Enxada","handheld","hoes"),("helmet","golden_helmet","Helmet","Capacete","generated","head_armor"),
 ("chestplate","golden_chestplate","Chestplate","Peitoral","generated","chest_armor"),("leggings","golden_leggings","Leggings","Calças","generated","leg_armor"),
 ("boots","golden_boots","Boots","Botas","generated","foot_armor"),("horse_armor","golden_horse_armor","Horse Armor","Armadura de Cavalo","generated",None)]
for key, base, en, pt, parent, tg in EQUIP:
    n = f"rose_gold_{key}"
    name(f"item.{M}.{n}", f"Rose Gold {en}", f"{pt} de Ouro Rosa")
    w(A/"models/item"/f"{n}.json", {"parent":f"minecraft:item/{parent}","textures":{"layer0":f"{M}:item/{n}"}}); item_def(n)
    recipe(f"{n}_smithing", {"type":"minecraft:smithing_transform","template":f"{M}:rose_gold_upgrade_smithing_template",
        "base":f"minecraft:{base}","addition":f"{M}:rose_gold_ingot","result":{"id":f"{M}:{n}","count":1}})
    if tg: tag(f"minecraft/tags/item/{tg}.json", [f"{M}:{n}"])
w(A/"equipment/rose_gold.json", {"layers":{"humanoid":[{"texture":f"{M}:rose_gold"}],"humanoid_leggings":[{"texture":f"{M}:rose_gold"}],"horse_body":[{"texture":f"{M}:rose_gold"}]}})
tag(f"{M}/tags/item/rose_gold_repair.json", [f"{M}:rose_gold_ingot"])

# ============ ETAPA 2: baldes, flores, cenoura dourada, receitas diversas ============
for n,en,pt in (("slime_bucket","Bucket of Slime","Balde com Slime"),("magma_cube_bucket","Bucket of Magma Cube","Balde com Cubo de Magma")):
    name(f"item.{M}.{n}", en, pt); item_flat(n, f"{M}:item/{n}")
for n,en,pt,dye in (("buttercup","Buttercup","Botão-de-ouro","yellow_dye"),("pink_daisy","Pink Daisy","Margarida Rosa","pink_dye"),("magenta_tulip","Magenta Tulip","Tulipa Magenta","magenta_dye")):
    name(f"block.{M}.{n}", en, pt)
    w(A/"models/block"/f"{n}.json", {"parent":"minecraft:block/cross","textures":{"cross":f"{M}:block/{n}"}})
    w(A/"blockstates"/f"{n}.json", {"variants":{"":{"model":f"{M}:block/{n}"}}})
    w(A/"models/item"/f"{n}.json", {"parent":"minecraft:item/generated","textures":{"layer0":f"{M}:block/{n}"}}); item_def(n)
    loot_self(n)
    recipe(f"{dye}_from_{n}", {"type":"minecraft:crafting_shapeless","category":"misc","group":dye,"ingredients":[f"{M}:{n}"],"result":{"id":f"minecraft:{dye}","count":1}})
FLOWERS = [f"{M}:buttercup", f"{M}:pink_daisy", f"{M}:magenta_tulip"]
# cenoura dourada (plantacao): 8 idades -> 4 texturas, como a cenoura normal
name(f"block.{M}.golden_carrots","Golden Carrots","Cenouras Douradas")
for i in range(4):
    w(A/"models/block"/f"golden_carrots_stage{i}.json", {"parent":"minecraft:block/crop","textures":{"crop":f"{M}:block/golden_carrots_stage{i}"}})
w(A/"blockstates/golden_carrots.json", {"variants":{f"age={a}":{"model":f"{M}:block/golden_carrots_stage{[0,0,1,1,2,2,2,3][a]}"} for a in range(8)}})
w(D/"loot_table/blocks/golden_carrots.json", {"type":"minecraft:block","pools":[
 {"rolls":1.0,"bonus_rolls":0.0,"entries":[{"type":"minecraft:item","name":"minecraft:golden_carrot"}]},
 {"rolls":1.0,"bonus_rolls":0.0,"conditions":[{"condition":"minecraft:block_state_property","block":f"{M}:golden_carrots","properties":{"age":"7"}}],
  "entries":[{"type":"minecraft:item","name":"minecraft:golden_carrot","functions":[{"function":"minecraft:apply_bonus","enchantment":"minecraft:fortune","formula":"minecraft:binomial_with_bonus_count","parameters":{"extra":3,"probability":0.5714286}}]}]}],
 "functions":[{"function":"minecraft:explosion_decay"}]})
# troncos no cortador de pedra viram madeira descascada
for wood in ("oak","spruce","birch","jungle","acacia","dark_oak","mangrove","cherry","pale_oak"):
    recipe(f"stripped_{wood}_wood_from_stonecutting", {"type":"minecraft:stonecutting","ingredient":f"minecraft:{wood}_log","result":{"id":f"minecraft:stripped_{wood}_wood","count":1}})
for stem in ("crimson","warped"):
    recipe(f"stripped_{stem}_hyphae_from_stonecutting", {"type":"minecraft:stonecutting","ingredient":f"minecraft:{stem}_stem","result":{"id":f"minecraft:stripped_{stem}_hyphae","count":1}})
tag("minecraft/tags/block/small_flowers.json", FLOWERS); tag("minecraft/tags/item/small_flowers.json", FLOWERS)
tag("minecraft/tags/block/flowers.json", FLOWERS); tag("minecraft/tags/item/flowers.json", FLOWERS)
tag("minecraft/tags/block/crops.json", [f"{M}:golden_carrots"]); tag("minecraft/tags/block/maintains_farmland.json", [f"{M}:golden_carrots"])

# ============ DISCOS (usam as musicas Criativo que o proprio jogo ja contem; nenhum audio e redistribuido) ============
DISCS = [("aria_math","Aria Math",310,2),("biome_fest","Biome Fest",378,3),("blind_spots","Blind Spots",332,4),
         ("dreiton","Dreiton",497,5),("haunt_muskie","Haunt Muskie",361,6),("taswell","Taswell",515,7)]
snd = {}
for n,title,secs,comp in DISCS:
    snd[f"music_disc.{n}"] = {"sounds":[{"name":f"minecraft:music/game/creative/{n}","stream":True}]}
    w(D/"jukebox_song"/f"{n}.json", {"comparator_output":comp,"description":{"translate":f"jukebox_song.{M}.{n}"},
        "length_in_seconds":float(secs),"sound_event":f"{M}:music_disc.{n}"})
    name(f"jukebox_song.{M}.{n}", f"C418 - {title}", f"C418 - {title}")
    name(f"item.{M}.music_disc_{n}", "Music Disc", "Disco de Música")
    item_flat(f"music_disc_{n}", f"{M}:item/music_disc_{n}")
w(A/"sounds.json", snd)

# ---- tags
for kind, lst in (("slabs",all_slab),("stairs",all_stairs),("walls",all_wall)):
    tag(f"minecraft/tags/block/{kind}.json", lst); tag(f"minecraft/tags/item/{kind}.json", lst)
tag("minecraft/tags/block/mineable/pickaxe.json", tool_pick); tag("minecraft/tags/block/mineable/hoe.json", tool_hoe); tag("minecraft/tags/block/mineable/axe.json", tool_axe)
tag("minecraft/tags/block/needs_iron_tool.json", [f"{M}:rose_gold_block",f"{M}:raw_rose_gold_block"])

# ---- idiomas
w(A/"lang/en_us.json", dict(sorted(lang_en.items()))); w(A/"lang/pt_br.json", dict(sorted(lang_pt.items())))
w(A/"lang/en_us.json", {**dict(sorted(lang_en.items())), "itemGroup.randomstuff.main":"Random Stuff"})
w(A/"lang/pt_br.json", {**dict(sorted(lang_pt.items())), "itemGroup.randomstuff.main":"Random Stuff"})

# ---- Java
j = ["package com.randomstuff.registry;","","import java.util.List;","",
 "/** GERADO por scripts/gerar_dados.py - nao edite a mao. Variantes de laje/escada/muro baseadas em blocos vanilla. */",
 "public final class VariantList {","\tpublic enum Kind { SLAB, STAIRS, WALL }","",
 "\tpublic record Entry(String name, String baseBlock, Kind kind) {}","",
 "\tpublic static final List<Entry> ENTRIES = List.of("]
j += [f'\t\tnew Entry("{n}", "{b}", Kind.{k}){"," if i<len(entries)-1 else ""}' for i,(n,b,k) in enumerate(entries)]
j += ["\t);","","\tprivate VariantList() {}","}",""]
p = ROOT/"src/main/java/com/randomstuff/registry/VariantList.java"; p.parent.mkdir(parents=True, exist_ok=True); p.write_text("\n".join(j), encoding="utf-8")
print("variantes:", len(entries), "| lajes", len(all_slab), "escadas", len(all_stairs), "muros", len(all_wall))
