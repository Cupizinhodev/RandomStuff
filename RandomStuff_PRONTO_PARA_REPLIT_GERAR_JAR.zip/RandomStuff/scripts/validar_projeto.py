#!/usr/bin/env python3
"""Auditoria estatica do Random Stuff. Nao executa Gradle nem compila o mod."""
from __future__ import annotations

import hashlib
import json
import re
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src" / "main" / "resources"
ASSET_ROOT = ROOT / "assets_originais" / "random stuff sprites"
MANIFEST = ROOT / "docs" / "briefing_original" / "MANIFESTO_ASSETS.json"

errors: list[str] = []
warnings: list[str] = []
counts = {"json": 0, "png": 0, "manifest": 0, "java": 0}
json_seen: set[Path] = set()


def fail(message: str) -> None:
    errors.append(message)


def warn(message: str) -> None:
    warnings.append(message)


def read_json(path: Path):
    try:
        if path not in json_seen:
            json_seen.add(path)
            counts["json"] += 1
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:
        fail(f"JSON invalido: {path.relative_to(ROOT)} ({exc})")
        return None


def png_dimensions(path: Path):
    with path.open("rb") as stream:
        header = stream.read(24)
    if len(header) != 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or header[12:16] != b"IHDR":
        raise ValueError("assinatura/cabecalho PNG invalido")
    return struct.unpack(">II", header[16:24])


def main() -> int:
    if not MANIFEST.is_file() or not ASSET_ROOT.is_dir():
        fail("Manifesto ou pasta de assets originais nao encontrada.")
    else:
        manifest = read_json(MANIFEST) or []
        counts["manifest"] = len(manifest)
        seen = set()
        for entry in manifest:
            rel = entry["path"]
            if rel in seen:
                fail(f"Entrada duplicada no manifesto: {rel}")
            seen.add(rel)
            path = ASSET_ROOT / rel
            if not path.is_file():
                fail(f"Asset do manifesto ausente: {rel}")
                continue
            digest = hashlib.sha256(path.read_bytes()).hexdigest()
            if digest != entry["sha256"]:
                fail(f"SHA-256 divergente: {rel}")
            try:
                dims = png_dimensions(path)
                if list(dims) != entry["dimensions"]:
                    fail(f"Dimensoes divergentes: {rel} ({dims})")
            except Exception as exc:
                fail(f"PNG invalido: {rel} ({exc})")

    for path in RES.rglob("*.json"):
        read_json(path)

    meta_path = RES / "fabric.mod.json"
    meta = read_json(meta_path) if meta_path.exists() else None
    if not meta:
        fail("fabric.mod.json ausente ou invalido.")
    else:
        if meta.get("id") != "randomstuff":
            fail("Mod ID nao e randomstuff.")
        if meta.get("depends", {}).get("minecraft") != "~26.3":
            warn("A dependencia de Minecraft nao esta fixada em ~26.3.")
        for side, entries in meta.get("entrypoints", {}).items():
            for class_name in entries:
                rel = Path(*class_name.split(".")).with_suffix(".java")
                candidates = [ROOT / "src" / "main" / "java" / rel,
                              ROOT / "src" / "client" / "java" / rel]
                if not any(candidate.is_file() for candidate in candidates):
                    fail(f"Entrypoint {side} sem classe: {class_name}")

    mixin_configs = [
        (RES / "randomstuff.mixins.json", ROOT / "src" / "main" / "java", "mixins"),
        (ROOT / "src" / "client" / "resources" / "randomstuff.client.mixins.json",
         ROOT / "src" / "client" / "java", "client"),
    ]
    for config_path, source_root, list_key in mixin_configs:
        config = read_json(config_path) if config_path.exists() else None
        if config is None:
            fail(f"Configuracao de mixins ausente/invalida: {config_path.relative_to(ROOT)}")
            continue
        package = config.get("package", "").replace(".", "/")
        for mixin in config.get(list_key, []):
            class_path = source_root / package / f"{mixin}.java"
            if not class_path.is_file():
                fail(f"Mixin declarado sem classe: {mixin} ({config_path.name})")

    for path in RES.rglob("*.png"):
        counts["png"] += 1
        try:
            png_dimensions(path)
        except Exception as exc:
            fail(f"PNG de recurso invalido: {path.relative_to(ROOT)} ({exc})")

    # Blockstates -> modelos do mod.
    for path in (RES / "assets" / "randomstuff" / "blockstates").glob("*.json"):
        data = read_json(path)
        if data is None:
            continue
        for model in re.findall(r'"model"\s*:\s*"randomstuff:([^"]+)"',
                                json.dumps(data, ensure_ascii=False)):
            model_root = RES / "assets" / "randomstuff" / "models"
            candidates = (model_root / f"{model}.json", model_root / "block" / f"{model}.json")
            if not any(target.is_file() for target in candidates):
                fail(f"Modelo referenciado ausente: {path.name} -> {model}")

    # Modelos -> texturas do mod.
    for path in (RES / "assets" / "randomstuff" / "models").rglob("*.json"):
        data = read_json(path)
        if data is None:
            continue
        for texture in re.findall(
                r'"(?:layer0|all|side|top|bottom|end|particle|wall)"\s*:\s*"randomstuff:([^"]+)"',
                json.dumps(data, ensure_ascii=False)):
            target = RES / "assets" / "randomstuff" / "textures" / f"{texture}.png"
            if not target.is_file():
                fail(f"Textura referenciada ausente: {path.relative_to(RES)} -> {texture}")

    # Camadas de equipamento usam caminhos de textura sem o prefixo textures/.
    for path in (RES / "assets" / "randomstuff" / "equipment").rglob("*.json"):
        data = read_json(path)
        if data is None:
            continue
        for layer, entries in data.get("layers", {}).items():
            for entry in entries:
                texture = entry.get("texture", "")
                if not texture.startswith("randomstuff:"):
                    continue
                texture_path = texture.split(":", 1)[1]
                target = (RES / "assets" / "randomstuff" / "textures" / "entity" /
                          "equipment" / layer / f"{texture_path}.png")
                if not target.is_file():
                    fail(f"Textura de equipamento ausente: {path.relative_to(RES)} -> {layer}/{texture_path}")

    # Armor Trim de Ouro Rosa: material de datapack, tag do ingrediente e paleta 8x1.
    trim_material_path = RES / "data/randomstuff/trim_material/rose_gold.json"
    trim_material = read_json(trim_material_path) if trim_material_path.exists() else None
    if not trim_material:
        fail("Material de Armor Trim ausente/invalido: data/randomstuff/trim_material/rose_gold.json")
    else:
        if trim_material.get("asset_name") != "rose_gold":
            fail("Armor Trim Ouro Rosa: asset_name incorreto.")
        if trim_material.get("ingredient") != "randomstuff:rose_gold_ingot":
            fail("Armor Trim Ouro Rosa: ingrediente nao aponta para o lingote.")
        if not isinstance(trim_material.get("item_model_index"), (int, float)):
            fail("Armor Trim Ouro Rosa: item_model_index ausente ou invalido.")
        if trim_material.get("description", {}).get("translate") != "trim_material.randomstuff.rose_gold":
            fail("Armor Trim Ouro Rosa: chave de traducao ausente/incorreta.")

    trim_tag_path = RES / "data/minecraft/tags/item/trim_materials.json"
    trim_tag = read_json(trim_tag_path) if trim_tag_path.exists() else None
    if not trim_tag or "randomstuff:rose_gold_ingot" not in trim_tag.get("values", []):
        fail("Lingote de Ouro Rosa nao esta na tag minecraft:trim_materials.")

    palette_path = RES / "assets/randomstuff/textures/trims/color_palettes/rose_gold.png"
    if not palette_path.is_file():
        fail("Paleta de Armor Trim ausente: textures/trims/color_palettes/rose_gold.png")
    else:
        try:
            if png_dimensions(palette_path) != (8, 1):
                fail("Paleta de Armor Trim Ouro Rosa deve medir exatamente 8x1 pixels.")
        except Exception as exc:
            fail(f"Paleta de Armor Trim Ouro Rosa invalida: {exc}")

    for locale in ("pt_br", "en_us"):
        lang_path = RES / f"assets/randomstuff/lang/{locale}.json"
        lang = read_json(lang_path) if lang_path.exists() else None
        if not lang or "trim_material.randomstuff.rose_gold" not in lang:
            fail(f"Traducao do Armor Trim Ouro Rosa ausente em {locale}.")

    java_roots = [ROOT / "src" / "main" / "java", ROOT / "src" / "client" / "java"]
    java_files = [p for base in java_roots if base.exists() for p in base.rglob("*.java")]
    counts["java"] = len(java_files)

    for required in ["gradlew", "gradlew.bat", "gradle/wrapper/gradle-wrapper.jar",
                     "gradle/wrapper/gradle-wrapper.properties"]:
        if not (ROOT / required).is_file():
            fail(f"Componente do Gradle Wrapper ausente: {required}")

    if not (ROOT / "src" / "test").exists():
        warn("Nao ha suite de testes automatizados em src/test; esta verificacao e estatica.")

    # Fechamento estatico da Etapa 4: fontes, mixins e caminhos 26.3.
    stage4_sources = [
        "src/main/java/com/randomstuff/mixin/AbstractCubeMobMixin.java",
        "src/main/java/com/randomstuff/mixin/SlimeFallDamageMixin.java",
        "src/main/java/com/randomstuff/mixin/SpawnPlacementsInvoker.java",
        "src/main/java/com/randomstuff/feature/SlimeDyeing.java",
        "src/main/java/com/randomstuff/feature/SlimeBlockDyeing.java",
        "src/main/java/com/randomstuff/feature/DyeColorItems.java",
        "src/main/java/com/randomstuff/entity/SlimeColorAccess.java",
        "src/client/java/com/randomstuff/client/mixin/SlimeRenderStateMixin.java",
        "src/client/java/com/randomstuff/client/mixin/AbstractCubeMobRendererMixin.java",
        "src/client/java/com/randomstuff/client/mixin/LivingEntityRendererSlimeTintMixin.java",
    ]
    for relative in stage4_sources:
        if not (ROOT / relative).is_file():
            fail(f"Fonte necessaria ao fechamento da Etapa 4 ausente: {relative}")

    source_text = "\n".join(path.read_text(encoding="utf-8", errors="ignore") for path in java_files)
    obsolete_api_fragments = [
        "net.minecraft.world.entity.monster.Slime",
        "net.minecraft.world.entity.monster.MagmaCube",
        "net.minecraft.world.entity.animal.Fox",
        "EntitySpawnReason.SPAWN_ITEM;",
        "getDyeColor()",
    ]
    for fragment in obsolete_api_fragments:
        if fragment in source_text:
            fail(f"Referencia antiga/incompativel com o mapeamento 26.3: {fragment}")

    slime_colors = ["white", "orange", "magenta", "light_blue", "yellow", "lime", "pink", "gray",
                    "light_gray", "cyan", "purple", "blue", "brown", "green", "red", "black"]
    for color in slime_colors:
        block = f"{color}_slime_block"
        expected = [
            RES / f"assets/randomstuff/blockstates/{block}.json",
            RES / f"assets/randomstuff/models/block/{block}.json",
            RES / f"assets/randomstuff/models/item/{block}.json",
            RES / f"data/randomstuff/loot_table/blocks/{block}.json",
        ]
        for target in expected:
            if not target.is_file():
                fail(f"Arquivo de variante colorida de Slime ausente: {target.relative_to(RES)}")

    print("AUDITORIA ESTATICA — RANDOM STUFF")
    print(f"JSON lidos: {counts['json']}")
    print(f"PNG de recursos verificados: {counts['png']}")
    print(f"Assets originais no manifesto: {counts['manifest']}")
    print(f"Classes Java encontradas: {counts['java']}")
    print(f"Erros: {len(errors)} | Avisos: {len(warnings)}")
    for item in errors:
        print("ERRO:", item)
    for item in warnings:
        print("AVISO:", item)
    print("IMPORTANTE: este script nao compila, nao inicia Minecraft e nao valida comportamento em runtime.")
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
