#!/usr/bin/env python3
# Verifica PNGs, dimensões, modo de cor e arquivos corrompidos.
# Uso: python validar_assets.py "caminho/para/random stuff sprites"
from pathlib import Path
import sys
try:
    from PIL import Image
except ImportError:
    print("Instale Pillow: python -m pip install pillow")
    raise SystemExit(2)

PROJECT_ROOT = Path(__file__).resolve().parent.parent
root = Path(sys.argv[1]).expanduser().resolve() if len(sys.argv) > 1 else PROJECT_ROOT / "assets_originais" / "random stuff sprites"
if not root.exists():
    print(f"Pasta não encontrada: {root}")
    raise SystemExit(1)

total = 0
errors = 0
for path in sorted(root.rglob("*.png")):
    total += 1
    try:
        with Image.open(path) as im:
            im.verify()
        with Image.open(path) as im:
            print(f"OK | {im.width:4}x{im.height:<4} | {im.mode:5} | {path.relative_to(root)}")
    except Exception as exc:
        errors += 1
        print(f"ERRO | {path}: {exc}")
print(f"\nTotal: {total} PNG(s); erros: {errors}")
raise SystemExit(1 if errors else 0)
