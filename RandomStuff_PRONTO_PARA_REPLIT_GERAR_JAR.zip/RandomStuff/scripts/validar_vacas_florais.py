#!/usr/bin/env python3
"""Valida o mapeamento de variantes e os ganchos de comportamento das vacas florais."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MATRIX = ROOT / 'docs' / 'MATRIZ_VARIANTES_MOOBLOOM_MOONLIP.json'
ENTITY = ROOT / 'src/main/java/com/randomstuff/entity/FlowerCowEntity.java'
REGISTRY = ROOT / 'src/main/java/com/randomstuff/registry/ModEntities.java'
RENDERER = ROOT / 'src/client/java/com/randomstuff/client/FlowerCowRenderer.java'
RENDER_STATE = ROOT / 'src/client/java/com/randomstuff/client/FlowerCowRenderState.java'
CLIENT = ROOT / 'src/client/java/com/randomstuff/client/RandomStuffClient.java'

data = json.loads(MATRIX.read_text(encoding='utf-8'))
errors = []
for name, expected in [('moobloom', 9), ('moonlip', 7)]:
    variants = data.get(name, [])
    if len(variants) != expected:
        errors.append(f'{name}: esperado {expected} variantes, encontrado {len(variants)}')
    for entry in variants:
        for key in ('adult_texture', 'baby_texture', 'overlay_texture'):
            path = ROOT / 'src/main/resources' / entry[key]
            if not path.is_file():
                errors.append(f'{name}/{entry.get("variant")}: arquivo ausente: {entry[key]}')

source = ENTITY.read_text(encoding='utf-8') if ENTITY.exists() else ''
registry = REGISTRY.read_text(encoding='utf-8') if REGISTRY.exists() else ''
renderer = RENDERER.read_text(encoding='utf-8') if RENDERER.exists() else ''
render_state = RENDER_STATE.read_text(encoding='utf-8') if RENDER_STATE.exists() else ''
client = CLIENT.read_text(encoding='utf-8') if CLIENT.exists() else ''
for token in ('implements Shearable', 'readyForShearing', 'void shear(', 'REGROW_TICKS', 'HAS_FLOWERS', 'FLOWER_VARIANT', 'addAdditionalSaveData', 'readAdditionalSaveData'):
    if token not in source:
        errors.append(f'FlowerCowEntity sem mecanismo esperado: {token}')
for token in ('isMoonlip()', 'isEyeOfWaxOpen()', 'REGROW_TICKS = 20 * 60 * 2'):
    if token not in source:
        errors.append(f'FlowerCowEntity sem regra esperada: {token}')
for token in ('MOOBLOOM', 'MOONLIP', 'new FlowerCowEntity'):
    if token not in registry:
        errors.append(f'ModEntities sem registro esperado: {token}')

print(f'Moobloom: {len(data.get("moobloom", []))}/9 variantes')
print(f'Moonlip: {len(data.get("moonlip", []))}/7 variantes')
for token in ('BlockDecorationLayer', 'bodyTexture(state)', 'flowerBlock(', 'OPEN_EYEBLOSSOM', 'CLOSED_EYEBLOSSOM'):
    if token not in renderer:
        errors.append(f'FlowerCowRenderer sem recurso visual esperado: {token}')
for token in ('FlowerCowRenderer(context, false)', 'FlowerCowRenderer(context, true)'):
    if token not in client:
        errors.append(f'Registro de renderer ausente: {token}')
for token in ('flowerVariant', 'hasFlowers', 'eyeOfWaxOpen', 'flowerModel'):
    if token not in render_state:
        errors.append(f'FlowerCowRenderState sem campo: {token}')
print('Texturas de corpo adulto/bebe e arquivos de overlay: verificados')
print('Renderer por variante, flor 3D e ciclo Eye-of-Wax: ' + ('encontrados' if not errors else 'com pendencias'))
print('Mecanismos de tesoura/regeneracao/persistencia: ' + ('encontrados' if not errors else 'com pendencias'))
print(f'Erros: {len(errors)}')
for error in errors:
    print('ERRO:', error)
raise SystemExit(1 if errors else 0)
