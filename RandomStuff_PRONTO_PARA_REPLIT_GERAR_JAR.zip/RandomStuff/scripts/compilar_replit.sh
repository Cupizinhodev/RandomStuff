#!/usr/bin/env bash
# Pipeline unico para o Replit: valida estaticamente, compila/remapeia e prepara o JAR final.
# Nao inicia Minecraft nem servidor.
set -Eeuo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

mkdir -p logs entrega
LOG="logs/build-replit.log"

fail() {
  echo
  echo "FALHA: $*" | tee -a "$LOG"
  echo "Consulte o log completo em: $LOG"
  exit 1
}

: > "$LOG"
echo "=== RANDOM STUFF | PIPELINE REPLIT ===" | tee -a "$LOG"
echo "Projeto: $ROOT" | tee -a "$LOG"

command -v java >/dev/null 2>&1 || fail "Java nao encontrado. Configure JDK 25 no ambiente Replit."
JAVA_LINE="$(java -version 2>&1 | head -n 1)"
echo "$JAVA_LINE" | tee -a "$LOG"
JAVA_MAJOR="$(printf '%s' "$JAVA_LINE" | sed -nE 's/.*version "([0-9]+).*/\1/p')"
[ -n "$JAVA_MAJOR" ] || fail "Nao foi possivel identificar a versao do Java."
[ "$JAVA_MAJOR" -ge 25 ] || fail "JDK 25 ou superior e obrigatorio; encontrado Java $JAVA_MAJOR."

command -v python3 >/dev/null 2>&1 || fail "Python 3 nao encontrado; necessario para validacao e conferencia do JAR."
[ -f gradle/wrapper/gradle-wrapper.jar ] || fail "Gradle Wrapper incompleto: gradle-wrapper.jar ausente."
[ -f gradle/wrapper/gradle-wrapper.properties ] || fail "gradle-wrapper.properties ausente."
chmod +x ./gradlew

run_logged() {
  echo "+ $*" | tee -a "$LOG"
  "$@" 2>&1 | tee -a "$LOG"
}

echo "=== 1/3 VALIDACAO ESTATICA ===" | tee -a "$LOG"
run_logged python3 scripts/validar_projeto.py || fail "validar_projeto.py encontrou erros. Corrija-os antes da compilacao."
run_logged python3 scripts/validar_assets.py || fail "validar_assets.py encontrou erros."

# Nao usamos --refresh-dependencies por padrao: reduz downloads e tempo. O log completo
# fica preservado para diagnostico; o Replit pode repetir com --refresh-dependencies se necessario.
echo "=== 2/3 COMPILACAO E REMAPEAMENTO ===" | tee -a "$LOG"
if ! ./gradlew clean build --no-daemon --stacktrace --max-workers=2 2>&1 | tee -a "$LOG"; then
  fail "Gradle falhou. Leia logs/build-replit.log e corrija os erros reais de compilacao/configuracao."
fi

# O build do Loom deve produzir o JAR remapeado sem classificador -dev ou -sources.
echo "=== 3/3 IDENTIFICACAO E CONFERENCIA DO JAR ===" | tee -a "$LOG"
JAR="$(find build/libs -maxdepth 1 -type f -name '*.jar' ! -name '*-sources.jar' ! -name '*-dev.jar' -printf '%f\n' | sort | head -n 1)"
[ -n "$JAR" ] || fail "Nenhum JAR de distribuicao encontrado em build/libs/. Verifique a tarefa remapJar do Loom."

if ! python3 - "$ROOT/build/libs/$JAR" <<'PY'
import json, sys, zipfile
from pathlib import Path
jar = Path(sys.argv[1])
with zipfile.ZipFile(jar) as z:
    bad = z.testzip()
    if bad:
        raise SystemExit(f"Entrada corrompida no JAR: {bad}")
    names = set(z.namelist())
    required = ["fabric.mod.json", "randomstuff.mixins.json"]
    missing = [x for x in required if x not in names]
    if missing:
        raise SystemExit("Recursos obrigatorios ausentes do JAR: " + ", ".join(missing))
    meta = json.loads(z.read("fabric.mod.json").decode("utf-8"))
    if meta.get("id") != "randomstuff":
        raise SystemExit("fabric.mod.json dentro do JAR tem mod id incorreto")
    if "${version}" in meta.get("version", ""):
        raise SystemExit("Placeholder ${version} nao foi expandido no JAR")
    classes = [n for n in names if n.endswith(".class")]
    if not classes:
        raise SystemExit("O JAR nao contem classes Java")
    print(f"JAR conferido: {jar.name}")
    print(f"Mod ID: {meta['id']} | versao: {meta.get('version')}")
    print(f"Classes: {len(classes)} | entradas: {len(names)}")
PY
then
  fail "A conferencia estrutural do JAR falhou."
fi

cp "build/libs/$JAR" "entrega/$JAR"
sha256sum "entrega/$JAR" | tee entrega/SHA256SUMS.txt | tee -a "$LOG"
echo "" | tee -a "$LOG"
echo "SUCESSO: JAR de distribuicao preparado em entrega/$JAR" | tee -a "$LOG"
echo "Log: $LOG" | tee -a "$LOG"
echo "IMPORTANTE: compilacao concluida; isso nao substitui teste no Minecraft/servidor." | tee -a "$LOG"
