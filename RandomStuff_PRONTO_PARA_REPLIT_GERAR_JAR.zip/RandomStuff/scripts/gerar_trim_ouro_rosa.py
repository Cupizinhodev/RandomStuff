#!/usr/bin/env python3
"""Gera o material de Armor Trim do Ouro Rosa para Minecraft 26.3.
Uso: python3 scripts/gerar_trim_ouro_rosa.py
Nao altera sprites originais nem executa Gradle/Minecraft.
"""
from __future__ import annotations
import json
import struct
import zlib
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources"
MATERIAL = {
    "asset_name": "rose_gold",
    "description": {
        "translate": "trim_material.randomstuff.rose_gold",
        "color": "#C16D6D"
    },
    "ingredient": "randomstuff:rose_gold_ingot",
    "item_model_index": 1.1
}
PALETTE = [
    (92, 43, 47), (118, 64, 59), (153, 72, 77), (177, 80, 86),
    (193, 109, 109), (227, 154, 151), (247, 180, 172), (255, 228, 228)
]

def png_chunk(kind: bytes, payload: bytes) -> bytes:
    return (struct.pack(">I", len(payload)) + kind + payload +
            struct.pack(">I", zlib.crc32(kind + payload) & 0xffffffff))

def palette_png() -> bytes:
    # Paleta RGB 8x1; sem dependência de Pillow.
    pixels = b"".join(bytes(rgb) for rgb in PALETTE)
    raw_scanline = b"\x00" + pixels
    ihdr = struct.pack(">IIBBBBB", 8, 1, 8, 2, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + png_chunk(b"IHDR", ihdr) +
            png_chunk(b"IDAT", zlib.compress(raw_scanline)) +
            png_chunk(b"IEND", b""))

def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

def main() -> None:
    write_json(RES / "data/randomstuff/trim_material/rose_gold.json", MATERIAL)
    write_json(RES / "data/minecraft/tags/item/trim_materials.json",
               {"replace": False, "values": ["randomstuff:rose_gold_ingot"]})
    palette = RES / "assets/randomstuff/textures/trims/color_palettes/rose_gold.png"
    palette.parent.mkdir(parents=True, exist_ok=True)
    palette.write_bytes(palette_png())
    for locale, name in (("pt_br", "Ouro Rosa"), ("en_us", "Rose Gold")):
        lang = RES / f"assets/randomstuff/lang/{locale}.json"
        values = json.loads(lang.read_text(encoding="utf-8"))
        values["trim_material.randomstuff.rose_gold"] = name
        lang.write_text(json.dumps(values, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
                        encoding="utf-8")
    print("Armor Trim Ouro Rosa gerado: material, tag, paleta 8x1 e traducoes.")

if __name__ == "__main__":
    main()
