package com.randomstuff.client;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

/**
 * Unica configuracao do mod: saturacao visual (0-100, padrao 50 = neutro), persistente em config/randomstuff.json.
 * Ajuste no jogo: /randomstuff saturation <0-100>. O efeito usa passos de 5 (post effects saturation_N).
 */
public final class SaturationConfig {
	public static final int DEFAULT = 50;
	private static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("randomstuff.json");
	private static int value = DEFAULT;

	private SaturationConfig() {}

	public static int get() {
		return value;
	}

	public static void set(int v) {
		value = Math.max(0, Math.min(100, v));
		save();
	}

	/** Identificador do post effect para o valor atual, ou null quando neutro (50). */
	public static Identifier effectId() {
		int step = Math.round(value / 5.0F) * 5;
		return step == DEFAULT ? null : Identifier.fromNamespaceAndPath("randomstuff", "saturation_" + step);
	}

	public static boolean isSaturationEffect(Identifier id) {
		return id.getNamespace().equals("randomstuff") && id.getPath().startsWith("saturation_");
	}

	public static void load() {
		try {
			if (Files.exists(FILE)) {
				JsonObject json = new Gson().fromJson(Files.readString(FILE), JsonObject.class);
				if (json != null && json.has("saturation")) value = Math.max(0, Math.min(100, json.get("saturation").getAsInt()));
			} else {
				save();
			}
		} catch (IOException | RuntimeException e) {
			value = DEFAULT;
		}
	}

	private static void save() {
		try {
			JsonObject json = new JsonObject();
			json.addProperty("saturation", value);
			Files.writeString(FILE, new Gson().toJson(json));
		} catch (IOException ignored) {
		}
	}

	public static void registerCommand() {
		ClientCommandRegistrationCallback.EVENT.register((dispatcher, buildContext) ->
				dispatcher.register(LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("randomstuff")
						.then(LiteralArgumentBuilder.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource>literal("saturation")
								.executes(ctx -> {
									ctx.getSource().sendFeedback(Component.literal("Saturation: " + value + " (default 50)"));
									return value;
								})
								.then(com.mojang.brigadier.builder.RequiredArgumentBuilder
										.<net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource, Integer>argument("value", IntegerArgumentType.integer(0, 100))
										.executes(ctx -> {
											set(IntegerArgumentType.getInteger(ctx, "value"));
											ctx.getSource().sendFeedback(Component.literal("Saturation set to " + value));
											return value;
										})))));
	}
}
