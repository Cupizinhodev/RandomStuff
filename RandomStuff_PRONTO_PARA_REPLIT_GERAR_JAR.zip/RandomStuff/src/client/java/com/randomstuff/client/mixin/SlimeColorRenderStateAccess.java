package com.randomstuff.client.mixin;

/** Ponte entre o render-state do Slime e o corante sincronizado pela entidade. */
public interface SlimeColorRenderStateAccess {
    int randomstuff$getColor();
    void randomstuff$setColor(int colorId);
}
