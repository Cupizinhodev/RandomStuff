package com.randomstuff.client;

import net.minecraft.client.renderer.block.BlockModelRenderState;
import net.minecraft.client.renderer.entity.state.CowRenderState;
import net.minecraft.resources.Identifier;

/** Snapshot visual da vaca floral: nao guarda referencia para a entidade viva. */
public final class FlowerCowRenderState extends CowRenderState {
    public int flowerVariant;
    public boolean moonlip;
    public boolean hasFlowers;
    public boolean eyeOfWaxOpen;
    public Identifier bodyTexture;
    public final BlockModelRenderState flowerModel = new BlockModelRenderState();
}
