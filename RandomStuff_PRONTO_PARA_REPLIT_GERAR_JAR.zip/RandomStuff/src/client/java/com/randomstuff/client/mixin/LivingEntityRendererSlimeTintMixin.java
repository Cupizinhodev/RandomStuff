package com.randomstuff.client.mixin;

import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.SlimeRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.state.SlimeRenderState;
import net.minecraft.world.item.DyeColor;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Aplica a cor apenas ao Slime vanilla; Magma Cube e outros renderers nao sao alterados. */
@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererSlimeTintMixin {
    @Inject(method = "getModelTint", at = @At("HEAD"), cancellable = true)
    private void randomstuff$tintSlime(LivingEntityRenderState state,
                                       CallbackInfoReturnable<Integer> cir) {
        if (!(this instanceof SlimeRenderer) || !(state instanceof SlimeRenderState slimeState)) return;
        int colorId = ((SlimeColorRenderStateAccess) slimeState).randomstuff$getColor();
        if (colorId < 0 || colorId >= 16) return;
        cir.setReturnValue(0xFF000000 | DyeColor.byId(colorId).getTextureDiffuseColor());
    }
}
