package com.randomstuff.client;

import com.randomstuff.entity.vehicle.CopperHopperMinecart;
import net.minecraft.client.model.geom.EntityModelLayers;
import net.minecraft.client.renderer.entity.AbstractMinecartRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.MinecartRenderState;

/** Renderizador vanilla de carrinho, que usa o BlockState de exibição do carrinho-funil de cobre. */
public final class CopperHopperMinecartRenderer extends AbstractMinecartRenderer<CopperHopperMinecart, MinecartRenderState> {
	public CopperHopperMinecartRenderer(EntityRendererProvider.Context context) {
		super(context, EntityModelLayers.MINECART);
	}

	@Override
	public MinecartRenderState createRenderState() {
		return new MinecartRenderState();
	}
}
