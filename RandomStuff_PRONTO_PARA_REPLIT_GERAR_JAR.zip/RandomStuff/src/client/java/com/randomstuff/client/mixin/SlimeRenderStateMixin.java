package com.randomstuff.client.mixin;

import net.minecraft.client.renderer.entity.state.SlimeRenderState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;

@Mixin(SlimeRenderState.class)
public abstract class SlimeRenderStateMixin implements SlimeColorRenderStateAccess {
    @Unique private int randomstuff$color = -1;

    @Override
    public int randomstuff$getColor() {
        return this.randomstuff$color;
    }

    @Override
    public void randomstuff$setColor(int colorId) {
        this.randomstuff$color = colorId;
    }
}
