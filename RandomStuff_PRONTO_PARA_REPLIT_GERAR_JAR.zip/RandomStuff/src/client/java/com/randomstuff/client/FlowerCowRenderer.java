package com.randomstuff.client;

import com.mojang.math.Axis;
import com.randomstuff.entity.FlowerCowEntity;
import com.randomstuff.registry.ModBlocks;
import net.minecraft.client.renderer.block.BlockModelResolver;
import net.minecraft.client.renderer.entity.CowRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MushroomCowRenderer;
import net.minecraft.client.renderer.entity.layers.BlockDecorationLayer;
import net.minecraft.client.renderer.entity.state.CowRenderState;
import net.minecraft.client.model.animal.cow.CowModel;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Renderer com textura por variante e flor 3D no dorso, removida junto com a tesoura. */
public final class FlowerCowRenderer extends CowRenderer {
    private final BlockModelResolver blockModelResolver;
    private final boolean moonlip;

    public FlowerCowRenderer(EntityRendererProvider.Context context, boolean moonlip) {
        super(context);
        this.moonlip = moonlip;
        this.blockModelResolver = context.getBlockModelResolver();
        this.addLayer(new BlockDecorationLayer<CowRenderState, CowModel>(
                this,
                state -> ((FlowerCowRenderState) state).flowerModel,
                pose -> {
                    pose.translate(0.0D, -0.35D, 0.48D);
                    pose.mulPose(Axis.YP.rotationDegrees(-48.0F));
                    pose.scale(-0.72F, -0.72F, 0.72F);
                }
        ));
    }

    @Override
    public FlowerCowRenderState createRenderState() {
        return new FlowerCowRenderState();
    }

    @Override
    public void extractRenderState(Cow entity, CowRenderState baseState, float partialTick) {
        super.extractRenderState(entity, baseState, partialTick);
        FlowerCowRenderState state = (FlowerCowRenderState) baseState;
        if (!(entity instanceof FlowerCowEntity flowerCow)) return;

        state.flowerVariant = flowerCow.getFlowerVariant();
        state.moonlip = this.moonlip;
        state.hasFlowers = flowerCow.hasFlowers();
        state.eyeOfWaxOpen = flowerCow.isEyeOfWaxOpen();
        state.bodyTexture = bodyTexture(state);

        BlockState flower = state.hasFlowers
                ? flowerBlock(state.moonlip, state.flowerVariant, state.eyeOfWaxOpen)
                : Blocks.AIR.defaultBlockState();
        this.blockModelResolver.update(state.flowerModel, flower, MushroomCowRenderer.BLOCK_DISPLAY_CONTEXT);
    }

    @Override
    public Identifier getTextureLocation(CowRenderState baseState) {
        FlowerCowRenderState state = (FlowerCowRenderState) baseState;
        return state.bodyTexture != null ? state.bodyTexture : id("textures/entity/flower_cow/body_amarelo_adult.png");
    }

    private static Identifier bodyTexture(FlowerCowRenderState s) {
        String age = s.isBaby ? "baby" : "adult";
        String body;
        if (s.moonlip) {
            body = switch (s.flowerVariant) {
                case 0, 3 -> "rosa";
                case 1 -> "laranja";
                case 2 -> "vermelho";
                case 4 -> "branco";
                case 5 -> "margarida";
                default -> "magenta";
            };
        } else {
            body = switch (s.flowerVariant) {
                case 0, 2 -> "amarelo";
                case 1 -> "vermelho";
                case 3 -> "azul_claro";
                case 4 -> "roxo";
                case 5, 6 -> "branco";
                case 7 -> "azul";
                default -> "cinza";
            };
        }
        String suffix = s.flowerVariant == 8 && !s.moonlip && s.eyeOfWaxOpen ? "_open" : "";
        return id("textures/entity/flower_cow/body_" + body + "_" + age + suffix + ".png");
    }

    private static BlockState flowerBlock(boolean moonlip, int variant, boolean eyeOfWaxOpen) {
        Block block;
        if (moonlip) {
            block = switch (variant) {
                case 0 -> ModBlocks.PINK_DAISY;
                case 1 -> Blocks.ORANGE_TULIP;
                case 2 -> Blocks.RED_TULIP;
                case 3 -> Blocks.PINK_TULIP;
                case 4 -> Blocks.WHITE_TULIP;
                case 5 -> Blocks.OXEYE_DAISY;
                default -> ModBlocks.MAGENTA_TULIP;
            };
        } else {
            block = switch (variant) {
                case 0 -> ModBlocks.BUTTERCUP;
                case 1 -> Blocks.POPPY;
                case 2 -> Blocks.DANDELION;
                case 3 -> Blocks.BLUE_ORCHID;
                case 4 -> Blocks.ALLIUM;
                case 5 -> Blocks.AZURE_BLUET;
                case 6 -> Blocks.LILY_OF_THE_VALLEY;
                case 7 -> Blocks.CORNFLOWER;
                default -> eyeOfWaxOpen ? Blocks.OPEN_EYEBLOSSOM : Blocks.CLOSED_EYEBLOSSOM;
            };
        }
        return block.defaultBlockState();
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("randomstuff", path);
    }
}
