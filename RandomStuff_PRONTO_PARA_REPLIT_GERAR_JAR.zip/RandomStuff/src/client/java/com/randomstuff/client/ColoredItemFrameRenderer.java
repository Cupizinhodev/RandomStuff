package com.randomstuff.client;

import com.randomstuff.registry.ModColoredFrames;
import net.minecraft.client.renderer.block.BlockModelResolver;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemFrameRenderer;
import net.minecraft.client.renderer.entity.state.ItemFrameRenderState;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.level.block.state.BlockState;

/** Mantem o render e as interacoes vanilla, trocando apenas o modelo da moldura no mundo. */
public final class ColoredItemFrameRenderer extends ItemFrameRenderer<ItemFrame> {
	private final BlockModelResolver blockModelResolver;
	private final String color;
	private final boolean invisible;

	public ColoredItemFrameRenderer(EntityRendererProvider.Context context, String color) {
		super(context);
		this.blockModelResolver = context.getBlockModelResolver();
		this.color = color;
		this.invisible = false;
	}

	public ColoredItemFrameRenderer(EntityRendererProvider.Context context) {
		super(context);
		this.blockModelResolver = context.getBlockModelResolver();
		this.color = null;
		this.invisible = true;
	}

	@Override
	public void extractRenderState(ItemFrame entity, ItemFrameRenderState state, float partialTicks) {
		super.extractRenderState(entity, state, partialTicks);
		if (this.invisible) {
			state.frameModel.clear();
			state.isInvisible = true;
		} else if (this.color != null && !state.isInvisible) {
			BlockState frameState = ModColoredFrames.frameState(this.color, state.mapId != null);
			this.blockModelResolver.update(state.frameModel, frameState, ItemFrameRenderer.BLOCK_DISPLAY_CONTEXT);
		}
	}
}
