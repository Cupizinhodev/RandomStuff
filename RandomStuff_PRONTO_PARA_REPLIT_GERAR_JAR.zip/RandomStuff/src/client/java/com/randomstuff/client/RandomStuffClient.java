package com.randomstuff.client;

import java.util.List;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.entity.EntityRenderers;
import com.randomstuff.registry.ModEntities;
import com.randomstuff.registry.ModCopperHopperMinecart;
import com.randomstuff.registry.ModColoredFrames;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;

/** Filtros de tela locais das cabeças. A seleção é recalculada no cliente. */
public class RandomStuffClient implements ClientModInitializer {
    private static final List<Identifier> RANDOMSTUFF_FILTERS = List.of(
            id("esqueleto"), id("creeper"), id("zumbi"), id("piglin"), id("dragao_do_end"));

    @Override
    public void onInitializeClient() {
        SaturationConfig.load();
        SaturationConfig.registerCommand();
        EntityRenderers.register(ModEntities.MOOBLOOM, context -> new FlowerCowRenderer(context, false));
        EntityRenderers.register(ModEntities.MOONLIP, context -> new FlowerCowRenderer(context, true));
        EntityRenderers.register(ModEntities.BLACK_FOX, BlackFoxRenderer::new);
        EntityRenderers.register(ModCopperHopperMinecart.TYPE, CopperHopperMinecartRenderer::new);
        for (String color : ModColoredFrames.COLORS) {
            EntityRenderers.register(ModColoredFrames.type(color), context -> new ColoredItemFrameRenderer(context, color));
        }
        EntityRenderers.register(ModColoredFrames.INVISIBLE_TYPE, ColoredItemFrameRenderer::new);
        ClientTickEvents.END_CLIENT_TICK.register(client -> updateHeadFilter(client));
    }

    private static void updateHeadFilter(Minecraft client) {
        if (client.gameRenderer == null) return;
        List<Identifier> requested = client.gameRenderer.getRequestedPostEffects();
        Identifier desired = null;
        if (client.player != null) {
            Item head = client.player.getItemBySlot(EquipmentSlot.HEAD).getItem();
            if (head == Items.SKELETON_SKULL) desired = id("esqueleto");
            else if (head == Items.CREEPER_HEAD) desired = id("creeper");
            else if (head == Items.ZOMBIE_HEAD) desired = id("zumbi");
            else if (head == Items.PIGLIN_HEAD) desired = id("piglin");
            else if (head == Items.DRAGON_HEAD) desired = id("dragao_do_end");
        }

        // Remove apenas filtros deste mod; outros post effects ativos sao preservados.
        requested.removeIf(id -> RANDOMSTUFF_FILTERS.contains(id) || SaturationConfig.isSaturationEffect(id));
        Identifier saturation = SaturationConfig.effectId();
        if (saturation != null) requested.add(saturation);
        if (desired != null) requested.add(desired);
    }

    private static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath("randomstuff", path);
    }
}
