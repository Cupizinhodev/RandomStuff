package com.randomstuff.client;

import com.randomstuff.entity.BlackFoxEntity;
import net.minecraft.client.renderer.entity.FoxRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.state.FoxRenderState;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.animal.fox.Fox;

/** Renderizador da Raposa Negra; nao modifica o renderizador/skin da raposa vanilla. */
public final class BlackFoxRenderer extends FoxRenderer {
    private static final Identifier TEXTURE = Identifier.fromNamespaceAndPath(
            "randomstuff", "textures/entity/fox/black_fox.png");

    public BlackFoxRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public Identifier getTextureLocation(FoxRenderState state) {
        return TEXTURE;
    }
}
