package com.randomstuff.client.mixin;

import com.randomstuff.entity.SlimeColorAccess;
import net.minecraft.client.renderer.entity.LivingEntityRenderer;
import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;
import net.minecraft.client.renderer.entity.state.SlimeRenderState;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.cubemob.Slime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Copia a cor para o snapshot visual; o renderer nunca consulta a entidade viva durante o submit. */
@Mixin(LivingEntityRenderer.class)
public abstract class AbstractCubeMobRendererMixin {
    @Inject(method = "extractRenderState", at = @At("TAIL"))
    private void randomstuff$extractSlimeColor(LivingEntity entity, LivingEntityRenderState state,
                                               float partialTicks, CallbackInfo ci) {
        if (entity instanceof Slime slime && state instanceof SlimeRenderState slimeState) {
            ((SlimeColorRenderStateAccess) slimeState).randomstuff$setColor(
                    ((SlimeColorAccess) slime).randomstuff$getColor());
        }
    }
}
