package com.randomstuff.block.entity;

import com.randomstuff.block.CopperHopperBlock;
import com.randomstuff.registry.ModCopperHoppers;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.NonNullList;
import net.minecraft.network.chat.Component;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.HopperMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.entity.HopperBlockEntity;
import net.minecraft.world.level.block.entity.RandomizableContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;

/**
 * Funil de Cobre: 5 slots (como o funil normal). O "filtro" e o tipo de item que ja esta guardado:
 * so entram/saem itens desse tipo e uma unidade e sempre preservada (nunca e ejetada).
 * Logica de transferencia propria (nao depende do HopperBlockEntity vanilla).
 */
public class CopperHopperBlockEntity extends RandomizableContainerBlockEntity {
	public static final int SIZE = 5;
	private NonNullList<ItemStack> items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
	private int cooldown = 0;

	public CopperHopperBlockEntity(BlockPos pos, BlockState state) {
		super(ModCopperHoppers.BLOCK_ENTITY, pos, state);
	}

	@Override
	protected NonNullList<ItemStack> getItems() {
		return items;
	}

	@Override
	protected void setItems(NonNullList<ItemStack> items) {
		this.items = items;
	}

	@Override
	protected Component getDefaultName() {
		return Component.translatable("container.randomstuff.copper_hopper");
	}

	@Override
	protected AbstractContainerMenu createMenu(int containerId, Inventory inventory) {
		return new HopperMenu(containerId, inventory, this);
	}

	@Override
	public int getContainerSize() {
		return SIZE;
	}

	/**
	 * A unidade que define o filtro nao pode ser retirada pelo inventario/menu.
	 * Sem esta protecao, o jogador poderia esvaziar o ultimo item e apagar o filtro,
	 * contrariando a regra de que uma unidade fica sempre preservada.
	 */
	@Override
	public ItemStack removeItem(int slot, int amount) {
		if (slot < 0 || slot >= items.size() || amount <= 0) return ItemStack.EMPTY;
		ItemStack current = items.get(slot);
		if (current.isEmpty()) return ItemStack.EMPTY;
		int removable = Math.min(amount, Math.max(0, totalItems() - 1));
		if (removable == 0) return ItemStack.EMPTY;
		ItemStack removed = current.split(removable);
		if (current.isEmpty()) items.set(slot, ItemStack.EMPTY);
		setChanged();
		return removed;
	}

	@Override
	public ItemStack removeItemNoUpdate(int slot) {
		if (slot < 0 || slot >= items.size()) return ItemStack.EMPTY;
		ItemStack current = items.get(slot);
		if (current.isEmpty()) return ItemStack.EMPTY;
		int removable = Math.min(current.getCount(), Math.max(0, totalItems() - 1));
		if (removable == 0) return ItemStack.EMPTY;
		ItemStack removed = current.copyWithCount(removable);
		current.shrink(removable);
		if (current.isEmpty()) items.set(slot, ItemStack.EMPTY);
		return removed;
	}

	@Override
	protected void loadAdditional(ValueInput input) {
		super.loadAdditional(input);
		this.items = NonNullList.withSize(SIZE, ItemStack.EMPTY);
		if (!this.tryLoadLootTable(input)) {
			ContainerHelper.loadAllItems(input, this.items);
		}
		this.cooldown = input.getIntOr("TransferCooldown", 0);
	}

	@Override
	protected void saveAdditional(ValueOutput output) {
		super.saveAdditional(output);
		if (!this.trySaveLootTable(output)) {
			ContainerHelper.saveAllItems(output, this.items);
		}
		output.putInt("TransferCooldown", this.cooldown);
	}

	/** Copia dos itens (usada ao trocar de variante por oxidacao/cera/raspagem sem perder o conteudo). */
	public NonNullList<ItemStack> snapshot() {
		NonNullList<ItemStack> copy = NonNullList.withSize(SIZE, ItemStack.EMPTY);
		for (int i = 0; i < SIZE; i++) copy.set(i, items.get(i).copy());
		return copy;
	}

	public void restore(NonNullList<ItemStack> saved, int savedCooldown) {
		for (int i = 0; i < SIZE; i++) items.set(i, saved.get(i));
		this.cooldown = savedCooldown;
		setChanged();
	}

	public int getCooldown() {
		return cooldown;
	}

	// ---- Filtro ----

	/** O filtro e o primeiro item nao vazio guardado; vazio = aceita qualquer coisa (o primeiro vira o filtro). */
	public ItemStack filterStack() {
		for (ItemStack s : items) if (!s.isEmpty()) return s;
		return ItemStack.EMPTY;
	}

	public boolean accepts(ItemStack stack) {
		ItemStack f = filterStack();
		return f.isEmpty() || ItemStack.isSameItemSameComponents(f, stack);
	}

	@Override
	public boolean canPlaceItem(int slot, ItemStack stack) {
		return accepts(stack);
	}

	private int totalItems() {
		int n = 0;
		for (ItemStack s : items) n += s.getCount();
		return n;
	}

	/** Insere no proprio funil; devolve o que sobrou. */
	public ItemStack insert(ItemStack stack) {
		if (stack.isEmpty() || !accepts(stack)) return stack;
		for (int i = 0; i < SIZE && !stack.isEmpty(); i++) {
			ItemStack slot = items.get(i);
			if (!slot.isEmpty() && ItemStack.isSameItemSameComponents(slot, stack)) {
				int room = Math.min(getMaxStackSize(), slot.getMaxStackSize()) - slot.getCount();
				int move = Math.min(room, stack.getCount());
				if (move > 0) {
					slot.grow(move);
					stack.shrink(move);
				}
			}
		}
		for (int i = 0; i < SIZE && !stack.isEmpty(); i++) {
			if (items.get(i).isEmpty()) {
				int move = Math.min(Math.min(getMaxStackSize(), stack.getMaxStackSize()), stack.getCount());
				items.set(i, stack.copyWithCount(move));
				stack.shrink(move);
			}
		}
		setChanged();
		return stack;
	}

	// ---- Tick ----

	public static void serverTick(Level level, BlockPos pos, BlockState state, CopperHopperBlockEntity be) {
		if (be.cooldown > 0) {
			be.cooldown--;
			return;
		}
		if (!state.getValue(HopperBlock.ENABLED)) return;
		boolean moved = be.eject(level, pos, state);
		moved |= be.suck(level, pos);
		if (moved && state.getBlock() instanceof CopperHopperBlock block) {
			be.cooldown = block.transferTicks();
			be.setChanged();
		}
	}

	private boolean eject(Level level, BlockPos pos, BlockState state) {
		// Sempre preserva pelo menos uma unidade do filtro.
		if (totalItems() <= 1) return false;
		Direction facing = state.getValue(HopperBlock.FACING);
		net.minecraft.world.Container dest = HopperBlockEntity.getContainerAt(level, pos.relative(facing));
		if (dest == null) return false;
		for (int i = SIZE - 1; i >= 0; i--) {
			ItemStack slot = items.get(i);
			if (slot.isEmpty()) continue;
			ItemStack one = slot.copyWithCount(1);
			ItemStack rest = HopperBlockEntity.addItem(this, dest, one, facing.getOpposite());
			if (rest.isEmpty()) {
				slot.shrink(1);
				dest.setChanged();
				return true;
			}
			// destino nao aceitou este item; como todos os itens sao do mesmo tipo, nao adianta tentar outro slot
			return false;
		}
		return false;
	}

	private boolean suck(Level level, BlockPos pos) {
		BlockPos above = pos.above();
		net.minecraft.world.Container src = HopperBlockEntity.getContainerAt(level, above);
		if (src != null) {
			for (int i = 0; i < src.getContainerSize(); i++) {
				ItemStack s = src.getItem(i);
				if (s.isEmpty() || !accepts(s)) continue;
				if (src instanceof net.minecraft.world.WorldlyContainer w
						&& !w.canTakeItemThroughFace(i, s, Direction.DOWN)) continue;
				ItemStack one = s.copyWithCount(1);
				if (insert(one).isEmpty()) {
					src.removeItem(i, 1);
					src.setChanged();
					return true;
				}
			}
			return false;
		}
		AABB box = new AABB(above.getX(), above.getY(), above.getZ(), above.getX() + 1, above.getY() + 1, above.getZ() + 1);
		List<ItemEntity> entities = level.getEntitiesOfClass(ItemEntity.class, box, EntitySelector.ENTITY_STILL_ALIVE);
		for (ItemEntity entity : entities) {
			ItemStack s = entity.getItem();
			if (!accepts(s)) continue;
			int before = s.getCount();
			ItemStack rest = insert(s.copy());
			if (rest.getCount() < before) {
				if (rest.isEmpty()) entity.discard();
				else entity.setItem(rest);
				return true;
			}
		}
		return false;
	}
}
