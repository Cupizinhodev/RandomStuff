package com.randomstuff.block;

import com.randomstuff.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HorizontalDirectionalBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Abobora Branca: funciona como a abobora normal (tesoura entalha e solta 4 sementes). Nao e fabricavel. */
public class WhitePumpkinBlock extends Block {
	public WhitePumpkinBlock(Properties properties) {
		super(properties);
	}

	@Override
	protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
			Player player, InteractionHand hand, BlockHitResult hit) {
		if (!stack.is(Items.SHEARS)) {
			return super.useItemOn(stack, state, level, pos, player, hand, hit);
		}
		if (level instanceof ServerLevel serverLevel) {
			Direction face = hit.getDirection();
			Direction facing = face.getAxis() == Direction.Axis.Y ? player.getDirection().getOpposite() : face;
			serverLevel.playSound(null, pos, SoundEvents.PUMPKIN_CARVE, SoundSource.BLOCKS, 1.0F, 1.0F);
			serverLevel.setBlock(pos, ModBlocks.CARVED_WHITE_PUMPKIN.defaultBlockState()
					.setValue(HorizontalDirectionalBlock.FACING, facing), Block.UPDATE_ALL_IMMEDIATE);
			ItemEntity seeds = new ItemEntity(serverLevel,
					pos.getX() + 0.5 + facing.getStepX() * 0.65, pos.getY() + 0.1, pos.getZ() + 0.5 + facing.getStepZ() * 0.65,
					new ItemStack(Items.PUMPKIN_SEEDS, 4));
			seeds.setDeltaMovement(0.05 * facing.getStepX() + serverLevel.random.nextDouble() * 0.02, 0.05,
					0.05 * facing.getStepZ() + serverLevel.random.nextDouble() * 0.02);
			serverLevel.addFreshEntity(seeds);
			stack.hurtAndBreak(1, player, hand);
		}
		return InteractionResult.SUCCESS;
	}
}
