package com.randomstuff.block;

import com.randomstuff.block.entity.CopperHopperBlockEntity;
import com.randomstuff.registry.ModCopperHoppers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.ItemTags;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;

/** Funil de Cobre: 4 estagios de oxidacao x (normal | encerado). Mais rapido quando novo, mais lento oxidado. */
public class CopperHopperBlock extends HopperBlock {
	public enum Age {
		NORMAL(6), EXPOSED(8), WEATHERED(10), OXIDIZED(12);

		public final int transferTicks;

		Age(int transferTicks) {
			this.transferTicks = transferTicks;
		}
	}

	private final Age age;
	private final boolean waxed;

	public CopperHopperBlock(Properties properties, Age age, boolean waxed) {
		super(properties);
		this.age = age;
		this.waxed = waxed;
	}

	public Age age() {
		return age;
	}

	public boolean waxed() {
		return waxed;
	}

	public int transferTicks() {
		return age.transferTicks;
	}

	@Override
	public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
		return new CopperHopperBlockEntity(pos, state);
	}

	@Override
	public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
		return level.isClientSide() ? null
				: createTickerHelper(type, ModCopperHoppers.BLOCK_ENTITY, CopperHopperBlockEntity::serverTick);
	}

	@Override
	protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) return InteractionResult.SUCCESS;
		if (level.getBlockEntity(pos) instanceof CopperHopperBlockEntity be) {
			player.openMenu(be);
		}
		return InteractionResult.CONSUME;
	}

	@Override
	protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos, Player player,
			InteractionHand hand, BlockHitResult hit) {
		if (!waxed && stack.is(Items.HONEYCOMB)) {
			if (!level.isClientSide()) {
				swap(level, pos, state, ModCopperHoppers.get(age, true));
				stack.consume(1, player);
				level.levelEvent(3003, pos, 0); // WAX_ON
			}
			return InteractionResult.SUCCESS;
		}
		if (stack.is(ItemTags.AXES)) {
			Block target = null;
			int event = 0;
			if (waxed) {
				target = ModCopperHoppers.get(age, false);
				event = 3004; // WAX_OFF
			} else if (age != Age.NORMAL) {
				target = ModCopperHoppers.get(Age.values()[age.ordinal() - 1], false);
				event = 3005; // SCRAPE
			}
			if (target != null) {
				if (!level.isClientSide()) {
					swap(level, pos, state, target);
					stack.hurtAndBreak(1, player, hand);
					level.levelEvent(event, pos, 0);
				}
				return InteractionResult.SUCCESS;
			}
		}
		return super.useItemOn(stack, state, level, pos, player, hand, hit);
	}

	@Override
	protected void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
		if (waxed || age == Age.OXIDIZED) return;
		if (random.nextFloat() < 0.05688889F) {
			swap(level, pos, state, ModCopperHoppers.get(Age.values()[age.ordinal() + 1], false));
		}
	}

	/** Troca o bloco preservando orientacao, estado e o conteudo do funil. */
	private static void swap(Level level, BlockPos pos, BlockState old, Block replacement) {
		NonNullList<ItemStack> saved = null;
		int cooldown = 0;
		if (level.getBlockEntity(pos) instanceof CopperHopperBlockEntity be) {
			saved = be.snapshot();
			cooldown = be.getCooldown();
			be.clearContent(); // evita que o conteudo seja dropado na troca
		}
		level.setBlock(pos, replacement.withPropertiesOf(old), Block.UPDATE_ALL);
		if (saved != null && level.getBlockEntity(pos) instanceof CopperHopperBlockEntity fresh) {
			fresh.restore(saved, cooldown);
		}
	}
}
