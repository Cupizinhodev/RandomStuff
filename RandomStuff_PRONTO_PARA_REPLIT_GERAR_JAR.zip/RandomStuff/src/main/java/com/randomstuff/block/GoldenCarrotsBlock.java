package com.randomstuff.block;

import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;
import net.minecraft.world.level.block.CropBlock;

/** Plantacao de cenoura dourada (variante natural rara da cenoura). Solta cenouras douradas. */
public class GoldenCarrotsBlock extends CropBlock {
	public GoldenCarrotsBlock(Properties properties) {
		super(properties);
	}

	@Override
	protected ItemLike getBaseSeedId() {
		return Items.GOLDEN_CARROT;
	}
}
