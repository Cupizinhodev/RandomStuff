package com.randomstuff.block;

import net.minecraft.core.BlockPos;
import net.minecraft.core.cauldron.CauldronInteractions;
import net.minecraft.core.component.DataComponents;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.DyeColor;
import com.randomstuff.feature.DyeColorItems;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.DyedItemColor;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Caldeirão de água colorida. A última tintura aplicada substitui a cor anterior. */
public final class ColoredWaterCauldronBlock extends LayeredCauldronBlock {
    public static final EnumProperty<DyeColor> COLOR = EnumProperty.create("color", DyeColor.class);

    public ColoredWaterCauldronBlock(BlockBehaviour.Properties properties) {
        super(Biome.Precipitation.RAIN, CauldronInteractions.WATER, properties);
        registerDefaultState(defaultBlockState().setValue(COLOR, DyeColor.WHITE));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder) {
        super.createBlockStateDefinition(builder);
        builder.add(COLOR);
    }

    @Override
    protected InteractionResult useItemOn(ItemStack stack, BlockState state, Level level, BlockPos pos,
            Player player, InteractionHand hand, BlockHitResult hit) {
        DyeColor nextColor = DyeColorItems.getColor(stack);
        if (nextColor != null) {
            if (state.getValue(COLOR) == nextColor) return InteractionResult.CONSUME;
            if (!level.isClientSide()) {
                level.setBlock(pos, state.setValue(COLOR, nextColor), 3);
                if (!player.getAbilities().instabuild) stack.shrink(1);
                level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.SUCCESS;
        }

        // Itens que usam o componente DYED_COLOR (por exemplo, armaduras de couro)
        // podem ser tingidos diretamente no caldeirão. Cada peça consome um nível.
        if (stack.has(DataComponents.DYED_COLOR) && state.getValue(LEVEL) > 0) {
            if (!level.isClientSide()) {
                stack.set(DataComponents.DYED_COLOR,
                        new DyedItemColor(state.getValue(COLOR).getTextureDiffuseColor()));
                LayeredCauldronBlock.lowerFillLevel(state, level, pos);
                level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.SUCCESS;
        }
        return super.useItemOn(stack, state, level, pos, player, hand, hit);
    }
}
