package com.randomstuff.effect;

import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectCategory;

/** Efeito marcador do Beacon; os efeitos visuais/funcionais sao aplicados pelos mixins do Beacon. */
public final class BeaconMarkerEffect extends MobEffect {
    public BeaconMarkerEffect(int color) {
        super(MobEffectCategory.BENEFICIAL, color);
    }
}
