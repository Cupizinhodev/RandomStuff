package com.randomstuff.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.projectile.FishingHook;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.entity.vehicle.Boat;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Ao fisgar um passageiro, remove apenas a criatura do barco; o barco permanece intacto. */
@Mixin(FishingHook.class)
public abstract class FishingHookBoatMixin {
    @Inject(method = "onHitEntity", at = @At("HEAD"))
    private void randomstuff$dismountBoatPassenger(EntityHitResult hit, CallbackInfo ci) {
        Entity target = hit.getEntity();
        if (target.isPassenger() && target.getVehicle() instanceof Boat) {
            target.stopRiding();
        }
    }
}
