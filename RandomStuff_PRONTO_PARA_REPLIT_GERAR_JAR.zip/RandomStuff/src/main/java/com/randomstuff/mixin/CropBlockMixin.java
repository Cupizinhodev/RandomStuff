package com.randomstuff.mixin;

import com.randomstuff.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Cenoura madura tem pequena chance de virar a variante dourada (a cada tick aleatorio no estagio final). */
@Mixin(CropBlock.class)
public abstract class CropBlockMixin {
	@Inject(method = "randomTick", at = @At("RETURN"))
	private void randomstuff$goldenCarrot(BlockState state, ServerLevel level, BlockPos pos, RandomSource random, CallbackInfo ci) {
		BlockState now = level.getBlockState(pos);
		if (now.is(Blocks.CARROTS) && now.getValue(CropBlock.AGE) == CropBlock.MAX_AGE && random.nextFloat() < 0.03F) {
			level.setBlock(pos, ModBlocks.GOLDEN_CARROTS.defaultBlockState().setValue(CropBlock.AGE, CropBlock.MAX_AGE), Block.UPDATE_CLIENTS);
		}
	}
}
