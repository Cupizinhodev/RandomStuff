package com.randomstuff.mixin;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnPlacementType;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Acesso controlado ao registro vanilla de spawn placements (privado em 26.3). */
@Mixin(SpawnPlacements.class)
public interface SpawnPlacementsInvoker {
    @Invoker("register")
    static <T extends Mob> void randomstuff$register(EntityType<T> type,
                                                      SpawnPlacementType placement,
                                                      Heightmap.Types heightmap,
                                                      SpawnPlacements.SpawnPredicate<T> predicate) {
        throw new AssertionError("Invoker do Mixin nao aplicado");
    }
}
