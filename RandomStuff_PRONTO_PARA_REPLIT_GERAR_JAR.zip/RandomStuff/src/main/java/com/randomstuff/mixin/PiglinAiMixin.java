package com.randomstuff.mixin;

import com.randomstuff.feature.MobHeads;
import java.util.Optional;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.monster.piglin.Piglin;
import net.minecraft.world.entity.monster.piglin.PiglinAi;
import net.minecraft.world.entity.EquipmentSlot;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Piglins escolhem alvos pela Brain e nao por Mob#setTarget. Filtra o resultado
 * central da busca vanilla para que o uso da cabeca de Piglin tambem proteja
 * contra o alvo passivo e contra uma memoria de raiva ainda ativa.
 */
@Mixin(PiglinAi.class)
public abstract class PiglinAiMixin {
    @Inject(method = "findNearestValidAttackTarget", at = @At("RETURN"), cancellable = true)
    private static void randomstuff$ignorePiglinHead(ServerLevel level, Piglin piglin,
            CallbackInfoReturnable<Optional<? extends LivingEntity>> cir) {
        Optional<? extends LivingEntity> result = cir.getReturnValue();
        if (result.isPresent() && result.get() instanceof Player player
                && MobHeads.protects(piglin, player.getItemBySlot(EquipmentSlot.HEAD))) {
            cir.setReturnValue(Optional.empty());
        }
    }
}
