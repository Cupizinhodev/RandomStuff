package com.randomstuff.mixin;

import com.randomstuff.feature.LavaResistance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** O encantamento impede dano direto de lava; não concede imunidade a fogo comum. */
@Mixin(Entity.class)
public abstract class LavaResistanceMixin {
	@Inject(method = "isInvulnerableTo", at = @At("HEAD"), cancellable = true, require = 0)
	private void randomstuff$lavaResistance(ServerLevel level, DamageSource source, CallbackInfoReturnable<Boolean> cir) {
		Entity self = (Entity) (Object) this;
		if (self instanceof LivingEntity living && source.is(DamageTypes.LAVA) && LavaResistance.protects(living)) {
			cir.setReturnValue(true);
		}
	}
}
