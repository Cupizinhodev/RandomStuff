package com.randomstuff.mixin;

import com.randomstuff.feature.BeaconEffects;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Holder;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.effect.MobEffect;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BeaconBlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adiciona Brilho/Respiracao ao menu vanilla e aplica o contorno tambem a criaturas. */
@Mixin(BeaconBlockEntity.class)
public abstract class BeaconBlockEntityMixin {
    @Shadow @Final @Mutable
    public static List<List<Holder<MobEffect>>> BEACON_EFFECTS;

    @Shadow @Final @Mutable
    private static Set<Holder<MobEffect>> VALID_EFFECTS;

    @Inject(method = "<clinit>", at = @At("TAIL"))
    private static void randomstuff$addBeaconEffects(CallbackInfo ci) {
        List<List<Holder<MobEffect>>> rows = new ArrayList<>(BEACON_EFFECTS);
        List<Holder<MobEffect>> primary = new ArrayList<>(rows.get(0));
        primary.add(BeaconEffects.GLOWING);
        primary.add(BeaconEffects.BREATHING);
        rows.set(0, List.copyOf(primary));
        BEACON_EFFECTS = List.copyOf(rows);

        Set<Holder<MobEffect>> valid = new HashSet<>(VALID_EFFECTS);
        valid.add(BeaconEffects.GLOWING);
        valid.add(BeaconEffects.BREATHING);
        VALID_EFFECTS = Set.copyOf(valid);
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private static void randomstuff$glowNearbyCreatures(Level level, BlockPos pos, BlockState state,
                                                        BeaconBlockEntity beacon, CallbackInfo ci) {
        if (!(level instanceof ServerLevel serverLevel) || serverLevel.getGameTime() % 20L != 0L) return;

        BeaconBlockEntityAccessor access = (BeaconBlockEntityAccessor) beacon;
        if (access.randomstuff$getLevels() <= 0 || beacon.getBeamSections().isEmpty()) return;
        if (!BeaconEffects.GLOWING.equals(access.randomstuff$getPrimaryPower())
                && !BeaconEffects.GLOWING.equals(access.randomstuff$getSecondaryPower())) return;

        int radius = 10 + 10 * access.randomstuff$getLevels();
        AABB area = new AABB(pos).inflate(radius).expandTowards(0.0D, serverLevel.getHeight(), 0.0D);
        for (LivingEntity target : serverLevel.getEntitiesOfClass(LivingEntity.class, area, LivingEntity::isAlive)) {
            target.addEffect(new MobEffectInstance(MobEffects.GLOWING, 45, 0, true, false, false));
        }
    }
}
