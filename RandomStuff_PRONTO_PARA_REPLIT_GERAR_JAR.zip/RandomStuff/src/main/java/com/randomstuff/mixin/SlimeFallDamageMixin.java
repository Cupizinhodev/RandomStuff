package com.randomstuff.mixin;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.cubemob.MagmaCube;
import net.minecraft.world.entity.monster.cubemob.Slime;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Cancela somente a fonte FALL normal; estalactites, estalagmites e outros impactos continuam perigosos. */
@Mixin(LivingEntity.class)
public abstract class SlimeFallDamageMixin {
    @Inject(method = "causeFallDamage", at = @At("HEAD"), cancellable = true)
    private void randomstuff$cancelOrdinaryCubeFallDamage(double fallDistance, float damageModifier,
                                                           DamageSource damageSource,
                                                           CallbackInfoReturnable<Boolean> cir) {
        if (((Object) this instanceof Slime || (Object) this instanceof MagmaCube)
                && damageSource.is(DamageTypes.FALL)) {
            cir.setReturnValue(false);
        }
    }
}
