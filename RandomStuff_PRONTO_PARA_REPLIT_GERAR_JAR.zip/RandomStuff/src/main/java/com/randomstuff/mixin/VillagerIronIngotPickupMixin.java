package com.randomstuff.mixin;

import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.GameRules;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Permite que somente Villagers recolham lingotes de ferro para reparar Golems. */
@Mixin(Villager.class)
public abstract class VillagerIronIngotPickupMixin {
    @Inject(method = "wantsToPickUp", at = @At("RETURN"), cancellable = true)
    private void randomstuff$allowVillagerIronIngot(ServerLevel level, ItemStack stack,
                                                     CallbackInfoReturnable<Boolean> cir) {
        Villager villager = (Villager) (Object) this;
        if (stack.is(Items.IRON_INGOT) && level.getGameRules().get(GameRules.MOB_GRIEFING)
                && villager.canPickUpLoot() && villager.getInventory().canAddItem(stack)) {
            cir.setReturnValue(true);
        }
    }
}
