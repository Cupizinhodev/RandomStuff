package com.randomstuff.mixin;

import com.mojang.datafixers.util.Pair;
import com.randomstuff.RandomStuffMod;
import java.util.function.Consumer;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.biome.Climate;
import net.minecraft.world.level.biome.OverworldBiomeBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Ajusta a tabela vanilla do Overworld no ponto em que cada faixa climática é emitida. */
@Mixin(OverworldBiomeBuilder.class)
public abstract class OverworldBiomeBuilderMixin {
    @Unique
    private static final ResourceKey<Biome> RANDOMSTUFF_CHERRY_BAMBOO_GROVE =
            ResourceKey.create(Registries.BIOME, RandomStuffMod.id("cherry_bamboo_grove"));

    @Inject(method = "addSurfaceBiome", at = @At("HEAD"), cancellable = true)
    private void randomstuff$adjustSurfaceBiomeParameters(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> biomes,
            Climate.Parameter temperature, Climate.Parameter humidity, Climate.Parameter continentalness,
            Climate.Parameter erosion, Climate.Parameter weirdness, float offset, ResourceKey<Biome> biome,
            CallbackInfo ci) {
        if (biome.equals(Biomes.CHERRY_GROVE)) {
            // Reserva 10% da faixa térmica de Cherry Grove para a Cerejeira Bambuzal.
            // As duas partes são disjuntas; nenhuma outra entrada vanilla é removida.
            ci.cancel();
            long min = temperature.min();
            long max = temperature.max();
            if (max - min < 2L) {
                randomstuff$emitPair(biomes, temperature, humidity, continentalness, erosion, weirdness, offset, Biomes.CHERRY_GROVE);
                return;
            }
            long split = min + Math.max(1L, Math.round((max - min) * 0.90D));
            split = Math.min(split, max - 1L);
            Climate.Parameter cherryTemperature = new Climate.Parameter(min, split);
            Climate.Parameter bambooTemperature = new Climate.Parameter(split + 1L, max);
            randomstuff$emitPair(biomes, cherryTemperature, humidity, continentalness, erosion, weirdness, offset, Biomes.CHERRY_GROVE);
            randomstuff$emitPair(biomes, bambooTemperature, humidity, continentalness, erosion, weirdness, offset, RANDOMSTUFF_CHERRY_BAMBOO_GROVE);
            return;
        }

        if (biome.equals(Biomes.PALE_GARDEN)) {
            ci.cancel();
            randomstuff$emitExpanded(biomes, temperature, humidity, continentalness, erosion, weirdness, offset, biome, 1.04F);
        } else if (biome.equals(Biomes.DAPPLED_FOREST)) {
            ci.cancel();
            randomstuff$emitExpanded(biomes, temperature, humidity, continentalness, erosion, weirdness, offset, biome, 1.025F);
        }
    }

    @Unique
    private static void randomstuff$emitExpanded(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> biomes,
            Climate.Parameter temperature, Climate.Parameter humidity, Climate.Parameter continentalness,
            Climate.Parameter erosion, Climate.Parameter weirdness, float offset, ResourceKey<Biome> biome, float factor) {
        randomstuff$emitPair(biomes, randomstuff$scale(temperature, factor), randomstuff$scale(humidity, factor),
                randomstuff$scale(continentalness, factor), randomstuff$scale(erosion, factor),
                randomstuff$scale(weirdness, factor), offset, biome);
    }

    @Unique
    private static void randomstuff$emitPair(
            Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> biomes,
            Climate.Parameter temperature, Climate.Parameter humidity, Climate.Parameter continentalness,
            Climate.Parameter erosion, Climate.Parameter weirdness, float offset, ResourceKey<Biome> biome) {
        biomes.accept(Pair.of(Climate.parameters(temperature, humidity, continentalness, erosion, Climate.Parameter.point(0.0F), weirdness, offset), biome));
        biomes.accept(Pair.of(Climate.parameters(temperature, humidity, continentalness, erosion, Climate.Parameter.point(1.0F), weirdness, offset), biome));
    }

    @Unique
    private static Climate.Parameter randomstuff$scale(Climate.Parameter parameter, float factor) {
        long center = (parameter.min() + parameter.max()) / 2L;
        long half = Math.round((parameter.max() - parameter.min()) * 0.5D * factor);
        return new Climate.Parameter(Math.max(-20000L, center - half), Math.min(20000L, center + half));
    }
}
