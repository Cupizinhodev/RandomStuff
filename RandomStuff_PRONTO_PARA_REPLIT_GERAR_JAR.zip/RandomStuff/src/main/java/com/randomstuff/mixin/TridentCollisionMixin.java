package com.randomstuff.mixin;

import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.arrow.ThrownTrident;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Amplia levemente o raio de selecao de colisao do tridente, sem alterar outros projeteis. */
@Mixin(Projectile.class)
public abstract class TridentCollisionMixin {
    @Inject(method = "getPickRadius", at = @At("RETURN"), cancellable = true)
    private void randomstuff$improveTridentHitbox(CallbackInfoReturnable<Float> cir) {
        if ((Object) this instanceof ThrownTrident) {
            cir.setReturnValue(cir.getReturnValue() + 0.15F);
        }
    }
}
