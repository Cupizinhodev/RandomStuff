package com.randomstuff.mixin;

import com.randomstuff.feature.LavaResistance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** Com Resistência à Lava, a entidade usa a física de natação em água enquanto está na lava. */
@Mixin(LivingEntity.class)
public abstract class LavaSwimMixin {
    @Redirect(
            method = "travelInFluid",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/world/entity/LivingEntity;travelInLava(Lnet/minecraft/world/phys/Vec3;DZD)V")
    )
    private void randomstuff$swimInLava(LivingEntity entity, Vec3 input, double baseGravity, boolean isFalling, double oldY) {
        LivingEntityTravelInvoker invoker = (LivingEntityTravelInvoker) entity;
        if (LavaResistance.protects(entity)) {
            invoker.randomstuff$invokeTravelInWater(input, baseGravity, isFalling, oldY);
        } else {
            invoker.randomstuff$invokeTravelInLava(input, baseGravity, isFalling, oldY);
        }
    }
}
