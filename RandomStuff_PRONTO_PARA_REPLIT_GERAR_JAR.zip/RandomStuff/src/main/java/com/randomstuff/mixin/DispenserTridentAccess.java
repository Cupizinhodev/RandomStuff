package com.randomstuff.mixin;

import net.minecraft.core.BlockPos;

public interface DispenserTridentAccess {
    void randomstuff$setDispenserPos(BlockPos pos);
}
