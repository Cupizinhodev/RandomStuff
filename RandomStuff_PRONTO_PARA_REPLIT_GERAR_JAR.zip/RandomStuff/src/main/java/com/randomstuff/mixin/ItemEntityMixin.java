package com.randomstuff.mixin;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.tags.FluidTags;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Itens de Netherite (lingote, sucata, ferramentas, armadura, bloco) flutuam na superficie da lava em vez de afundar. */
@Mixin(ItemEntity.class)
public abstract class ItemEntityMixin {
	@Inject(method = "tick", at = @At("TAIL"))
	private void randomstuff$netheriteFloatsOnLava(CallbackInfo ci) {
		ItemEntity self = (ItemEntity) (Object) this;
		if (!BuiltInRegistries.ITEM.getKey(self.getItem().getItem()).getPath().contains("netherite")) {
			return;
		}
		if (self.getFluidHeight(FluidTags.LAVA) <= 0.1D) {
			return;
		}
		// a gravidade ja puxou o item neste tick; soma uma subida um pouco maior para ele ficar boiando na superficie
		Vec3 motion = self.getDeltaMovement();
		self.setDeltaMovement(motion.x * 0.95D, Math.min(motion.y + 0.06D, 0.05D), motion.z * 0.95D);
	}
}
