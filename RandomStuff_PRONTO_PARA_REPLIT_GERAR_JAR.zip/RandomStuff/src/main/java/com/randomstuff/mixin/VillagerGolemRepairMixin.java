package com.randomstuff.mixin;

import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.animal.golem.IronGolem;
import net.minecraft.world.entity.npc.villager.Villager;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Villagers com lingotes procuram Golems no ultimo estagio de dano e os reparam. */
@Mixin(Villager.class)
public abstract class VillagerGolemRepairMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void randomstuff$repairNearbyGolem(CallbackInfo ci) {
        Villager villager = (Villager) (Object) this;
        if (villager.level().isClientSide() || villager.tickCount % 20 != 0
                || villager.isBaby() || villager.isTrading()) return;

        SimpleContainer inventory = villager.getInventory();
        ItemStack heldItem = villager.getMainHandItem();
        if (!heldItem.isEmpty() && !heldItem.is(Items.IRON_INGOT)) return;
        if (heldItem.isEmpty()) {
            ItemStack reservedIngot = inventory.removeItemType(Items.IRON_INGOT, 1);
            if (reservedIngot.isEmpty()) return;
            villager.setItemSlot(EquipmentSlot.MAINHAND, reservedIngot);
            villager.setGuaranteedDrop(EquipmentSlot.MAINHAND);
        }

        AABB searchArea = villager.getBoundingBox().inflate(10.0D, 5.0D, 10.0D);
        IronGolem target = villager.level().getEntitiesOfClass(IronGolem.class, searchArea,
                        golem -> golem.isAlive() && golem.getHealth() <= golem.getMaxHealth() * 0.25F)
                .stream()
                .min((first, second) -> Double.compare(villager.distanceToSqr(first), villager.distanceToSqr(second)))
                .orElse(null);

        if (target == null) {
            villager.getNavigation().stop();
            return;
        }

        villager.getLookControl().setLookAt(target, 30.0F, 30.0F);
        if (villager.distanceToSqr(target) > 6.25D) {
            villager.getNavigation().moveTo(target, 1.0D);
            return;
        }

        target.heal(target.getMaxHealth() * 0.25F);
        target.playSound(SoundEvents.IRON_GOLEM_REPAIR, 1.0F, 1.0F);
        villager.setItemSlot(EquipmentSlot.MAINHAND, ItemStack.EMPTY);
        villager.getNavigation().stop();
    }
}
