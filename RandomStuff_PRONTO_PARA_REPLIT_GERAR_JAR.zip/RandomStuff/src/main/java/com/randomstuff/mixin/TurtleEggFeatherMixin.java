package com.randomstuff.mixin;

import com.randomstuff.feature.FeatherFalling;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.TurtleEggBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Queda de Penas impede quebrar ovos de tartaruga ao pisar/cair. */
@Mixin(TurtleEggBlock.class)
public abstract class TurtleEggFeatherMixin {
	@Inject(method = "destroyEgg", at = @At("HEAD"), cancellable = true, require = 0)
	private void randomstuff$noBreak(Level level, BlockState state, BlockPos pos, Entity entity, int inc, CallbackInfo ci) {
		if (FeatherFalling.has(entity)) ci.cancel();
	}
}
