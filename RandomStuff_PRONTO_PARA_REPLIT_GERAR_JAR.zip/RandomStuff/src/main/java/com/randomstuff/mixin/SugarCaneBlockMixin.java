package com.randomstuff.mixin;

import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;

/** Farinha de osso acelera a cana-de-acucar: cresce um bloco no topo (altura maxima 3, como no jogo). */
@Mixin(SugarCaneBlock.class)
public abstract class SugarCaneBlockMixin implements BonemealableBlock {
	private static BlockPos randomstuff$top(LevelReader level, BlockPos pos) {
		BlockPos top = pos;
		while (level.getBlockState(top.above()).is(Blocks.SUGAR_CANE)) {
			top = top.above();
		}
		return top;
	}

	private static int randomstuff$height(LevelReader level, BlockPos top) {
		int height = 1;
		while (level.getBlockState(top.below(height)).is(Blocks.SUGAR_CANE)) {
			height++;
		}
		return height;
	}

	@Override
	public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state) {
		BlockPos top = randomstuff$top(level, pos);
		return level.isEmptyBlock(top.above()) && randomstuff$height(level, top) < 3;
	}

	@Override
	public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
		return true;
	}

	@Override
	public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
		BlockPos top = randomstuff$top(level, pos);
		if (level.isEmptyBlock(top.above()) && randomstuff$height(level, top) < 3) {
			level.setBlockAndUpdate(top.above(), Blocks.SUGAR_CANE.defaultBlockState());
		}
	}
}
