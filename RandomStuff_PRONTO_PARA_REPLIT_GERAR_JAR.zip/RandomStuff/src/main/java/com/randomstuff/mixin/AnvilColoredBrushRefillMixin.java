package com.randomstuff.mixin;

import com.randomstuff.item.ColoredBrushItem;
import net.minecraft.world.inventory.AnvilMenu;
import net.minecraft.world.inventory.DataSlot;
import net.minecraft.world.item.DyeColor;
import com.randomstuff.feature.DyeColorItems;
import net.minecraft.world.item.ItemStack;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Recarga pincel colorido + corante correspondente nos slots reais da bigorna. */
@Mixin(AnvilMenu.class)
public abstract class AnvilColoredBrushRefillMixin {
	@Shadow @Final private DataSlot cost;
	@Shadow private int repairItemCountCost;

	@Inject(method = "createResult", at = @At("TAIL"))
	private void randomstuff$refillColoredBrush(CallbackInfo ci) {
		ItemCombinerMenuAccessor access = (ItemCombinerMenuAccessor) this;
		ItemStack brushStack = access.randomstuff$getInputSlots().getItem(0);
		ItemStack dyeStack = access.randomstuff$getInputSlots().getItem(1);

		DyeColor dyeColor = DyeColorItems.getColor(dyeStack);
		if (brushStack.getItem() instanceof ColoredBrushItem brush
				&& dyeColor != null && dyeColor == brush.getColor()
				&& ColoredBrushItem.getPaint(brushStack) < ColoredBrushItem.MAX_PAINT) {
			ItemStack output = brushStack.copy();
			ColoredBrushItem.setPaint(output, ColoredBrushItem.MAX_PAINT);
			access.randomstuff$getResultSlots().setItem(0, output);
			this.cost.set(1);
			this.repairItemCountCost = 1;
		}
	}
}
