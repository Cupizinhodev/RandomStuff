package com.randomstuff.mixin;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

/** Invocadores para reutilizar a física de natação em água ao nadar na lava. */
@Mixin(LivingEntity.class)
public interface LivingEntityTravelInvoker {
    @Invoker("travelInWater")
    void randomstuff$invokeTravelInWater(Vec3 input, double baseGravity, boolean isFalling, double oldY);

    @Invoker("travelInLava")
    void randomstuff$invokeTravelInLava(Vec3 input, double baseGravity, boolean isFalling, double oldY);
}
