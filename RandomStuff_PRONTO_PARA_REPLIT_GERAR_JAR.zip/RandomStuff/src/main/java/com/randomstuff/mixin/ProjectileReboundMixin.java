package com.randomstuff.mixin;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.entity.projectile.ProjectileDeflection;
import net.minecraft.world.item.ItemStack;
import net.minecraft.tags.ItemTags;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Rebate ovos, bolas de neve e cargas de vento quando atingidos por ferramentas de combate. */
@Mixin(Player.class)
public abstract class ProjectileReboundMixin {
    @Inject(method = "attack", at = @At("HEAD"), cancellable = true)
    private void randomstuff$reboundProjectiles(Entity target, CallbackInfo ci) {
        if (!(target instanceof Projectile projectile)) return;
        EntityType<?> type = projectile.getType();
        if (type != EntityTypes.EGG && type != EntityTypes.SNOWBALL && type != EntityTypes.WIND_CHARGE) return;

        Player player = (Player) (Object) this;
        ItemStack weapon = player.getMainHandItem();
        if (!weapon.is(ItemTags.SWORDS) && !weapon.is(ItemTags.AXES) && !weapon.is(ItemTags.SHOVELS)) return;

        if (!player.level().isClientSide() && projectile.deflect(ProjectileDeflection.REVERSE, player, null, true, 1.0)) {
            projectile.setOwner(player);
            ci.cancel();
        }
    }
}
