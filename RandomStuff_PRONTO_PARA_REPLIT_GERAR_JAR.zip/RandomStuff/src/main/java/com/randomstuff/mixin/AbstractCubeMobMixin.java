package com.randomstuff.mixin;

import com.randomstuff.entity.SlimeColorAccess;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.monster.cubemob.AbstractCubeMob;
import net.minecraft.world.entity.monster.cubemob.MagmaCube;
import net.minecraft.world.entity.monster.cubemob.Slime;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Extensoes comuns dos cubemobs. Os hooks sao limitados a Slime/MagmaCube; o Cubo de Enxofre
 * e qualquer outro AbstractCubeMob preservam integralmente o comportamento original.
 */
@Mixin(AbstractCubeMob.class)
public abstract class AbstractCubeMobMixin implements SlimeColorAccess {
    @Unique private static final String RANDOMSTUFF_COLOR_TAG = "RandomStuffSlimeColor";
    @Unique private static final EntityDataAccessor<Integer> RANDOMSTUFF_COLOR =
            SynchedEntityData.defineId(AbstractCubeMob.class, EntityDataSerializers.INT);
    @Unique private int randomstuff$targetScanTicks;
    @Unique private int randomstuff$waterDamageTicks;
    @Unique private int randomstuff$landingDamageCooldown;

    @Override
    public int randomstuff$getColor() {
        return ((AbstractCubeMob) (Object) this).getEntityData().get(RANDOMSTUFF_COLOR);
    }

    @Override
    public void randomstuff$setColor(int colorId) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        if (mob instanceof Slime) {
            mob.getEntityData().set(RANDOMSTUFF_COLOR, colorId >= 0 && colorId < 16 ? colorId : -1);
        }
    }

    @Inject(method = "defineSynchedData", at = @At("TAIL"))
    private void randomstuff$defineColor(SynchedEntityData.Builder builder, CallbackInfo ci) {
        builder.define(RANDOMSTUFF_COLOR, -1);
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void randomstuff$saveColor(ValueOutput output, CallbackInfo ci) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        if (mob instanceof Slime) output.putInt(RANDOMSTUFF_COLOR_TAG, randomstuff$getColor());
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void randomstuff$loadColor(ValueInput input, CallbackInfo ci) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        if (mob instanceof Slime) randomstuff$setColor(input.getIntOr(RANDOMSTUFF_COLOR_TAG, -1));
    }

    /** Mantem os alvos vanilla; quando nao ha alvo, procura somente a especie cubemob oposta. */
    @Inject(method = "tick", at = @At("TAIL"))
    private void randomstuff$specialCubeBehaviour(CallbackInfo ci) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        if (!(mob instanceof Slime) && !(mob instanceof MagmaCube)) return;
        if (!(mob.level() instanceof ServerLevel serverLevel)) return;

        if (this.randomstuff$landingDamageCooldown > 0) --this.randomstuff$landingDamageCooldown;

        Vec3 velocity = mob.getDeltaMovement();
        if (mob instanceof Slime && mob.isInWater() && velocity.y < 0.06D) {
            mob.setDeltaMovement(velocity.x, Math.max(0.035D, velocity.y + 0.035D), velocity.z);
        } else if (mob instanceof MagmaCube && mob.isInLava() && velocity.y < 0.06D) {
            mob.setDeltaMovement(velocity.x, Math.max(0.035D, velocity.y + 0.035D), velocity.z);
        }

        if (mob instanceof MagmaCube) {
            if (mob.isInWater()) {
                if (++this.randomstuff$waterDamageTicks >= 20) {
                    this.randomstuff$waterDamageTicks = 0;
                    mob.hurtServer(serverLevel, mob.damageSources().drown(), 1.0F);
                }
            } else {
                this.randomstuff$waterDamageTicks = 0;
            }
        }

        if (++this.randomstuff$targetScanTicks < 10) return;
        this.randomstuff$targetScanTicks = 0;
        LivingEntity current = mob.getTarget();
        if (current != null && current.isAlive()) return;

        AABB searchBox = mob.getBoundingBox().inflate(16.0D);
        AbstractCubeMob nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (AbstractCubeMob candidate : mob.level().getEntitiesOfClass(AbstractCubeMob.class, searchBox,
                other -> other != mob && other.isAlive()
                        && ((mob instanceof Slime && other instanceof MagmaCube)
                        || (mob instanceof MagmaCube && other instanceof Slime)))) {
            double distance = mob.distanceToSqr(candidate);
            if (distance < nearestDistance) {
                nearestDistance = distance;
                nearest = candidate;
            }
        }
        if (nearest != null) mob.setTarget(nearest);
    }

    /** Slimes menores que surgem da divisao herdam a cor do Slime original. */
    @Inject(method = "setUpSplitCube", at = @At("TAIL"))
    private void randomstuff$inheritSplitColor(AbstractCubeMob child, int halfSize, float xd, float zd,
                                               CallbackInfo ci) {
        AbstractCubeMob parent = (AbstractCubeMob) (Object) this;
        if (parent instanceof Slime && child instanceof Slime) {
            ((SlimeColorAccess) child).randomstuff$setColor(randomstuff$getColor());
        }
    }

    /** Permite que cubos pequenos tambem ataquem a especie rival, sem mudar o dano vanilla a outros alvos. */
    @Inject(method = "canDealDamage", at = @At("RETURN"), cancellable = true)
    private void randomstuff$canAttackOppositeCube(CallbackInfoReturnable<Boolean> cir) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        LivingEntity target = mob.getTarget();
        if ((mob instanceof Slime && target instanceof MagmaCube)
                || (mob instanceof MagmaCube && target instanceof Slime)) {
            cir.setReturnValue(true);
        }
    }

    /** Ataque recíproco controlado: 1 ponto de dano e empurrão moderado, maior nos tamanhos pequenos. */
    @Inject(method = "dealDamage", at = @At("HEAD"), cancellable = true)
    private void randomstuff$attackOppositeCube(LivingEntity target, CallbackInfo ci) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        boolean opposite = (mob instanceof Slime && target instanceof MagmaCube)
                || (mob instanceof MagmaCube && target instanceof Slime);
        if (!opposite || !(mob.level() instanceof ServerLevel serverLevel)) return;

        target.hurtServer(serverLevel, mob.damageSources().mobAttack(mob), 1.0F);
        double dx = target.getX() - mob.getX();
        double dz = target.getZ() - mob.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length > 1.0E-5D) {
            double strength = Math.max(0.18D, 0.55D / Math.max(1, mob.getSize()));
            target.push(dx / length * strength, 0.12D, dz / length * strength);
        }
        ci.cancel();
    }

    /** Contato empurra criaturas; pousar por cima quica. Magma Cube aplica calor leve no pouso. */
    @Inject(method = "push", at = @At("TAIL"))
    private void randomstuff$pushAndBounce(Entity other, CallbackInfo ci) {
        AbstractCubeMob mob = (AbstractCubeMob) (Object) this;
        if (!(mob instanceof Slime) && !(mob instanceof MagmaCube)) return;
        if (mob.level().isClientSide || !other.isAlive() || other == mob) return;
        if (other instanceof AbstractCubeMob) return; // o combate entre cubos e tratado pelo alvo/ataque

        Vec3 velocity = other.getDeltaMovement();
        double top = mob.getY() + mob.getBbHeight();
        boolean landingOnTop = other.getY() >= top - 0.18D && (velocity.y < -0.05D || other.onGround());
        double dx = other.getX() - mob.getX();
        double dz = other.getZ() - mob.getZ();
        double length = Math.sqrt(dx * dx + dz * dz);
        if (length < 1.0E-5D) length = 1.0D;

        if (landingOnTop) {
            other.setDeltaMovement(velocity.x, Math.max(0.58D, -velocity.y * 0.65D), velocity.z);
            other.resetFallDistance();
            if (mob instanceof MagmaCube && other instanceof LivingEntity living
                    && this.randomstuff$landingDamageCooldown == 0
                    && mob.level() instanceof ServerLevel serverLevel) {
                living.hurtServer(serverLevel, mob.damageSources().hotFloor(), 1.0F);
                this.randomstuff$landingDamageCooldown = 10;
            }
        } else if (other instanceof LivingEntity) {
            double strength = Math.max(0.12D, 0.42D / Math.max(1, mob.getSize()));
            other.push(dx / length * strength, 0.035D, dz / length * strength);
        }
    }
}
