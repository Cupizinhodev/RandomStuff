package com.randomstuff.mixin;

import com.randomstuff.feature.PaneSeparation;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.CrossCollisionBlock;
import net.minecraft.world.level.block.IronBarsBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.ScheduledTickAccess;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Permite escolher o estilo de conexão dos painéis de vidro no momento da colocação:
 * sem agachar, comportamento vanilla; agachado, mantém bordas nos encontros entre painéis.
 */
@Mixin(IronBarsBlock.class)
public abstract class GlassPaneSeparationMixin {
    @Inject(method = "createBlockStateDefinition", at = @At("TAIL"))
    private void randomstuff$addSeparatedState(
            StateDefinition.Builder<net.minecraft.world.level.block.Block, BlockState> builder,
            CallbackInfo ci) {
        builder.add(PaneSeparation.SEPARATED);
    }

    @Inject(method = "getStateForPlacement", at = @At("RETURN"), cancellable = true)
    private void randomstuff$rememberCrouchPlacement(
            BlockPlaceContext context, CallbackInfoReturnable<BlockState> cir) {
        BlockState placed = cir.getReturnValue();
        if (placed == null || !PaneSeparation.isGlassPane(placed)) {
            return;
        }

        boolean separated = context.getPlayer() != null && context.getPlayer().isShiftKeyDown();
        placed = placed.setValue(PaneSeparation.SEPARATED, separated);

        // O novo painel não pode criar conexão com um painel separado já existente,
        // nem com painéis vizinhos quando ele próprio foi colocado agachado.
        for (Direction direction : Direction.Plane.HORIZONTAL) {
            BlockState neighbor = context.getLevel().getBlockState(context.getClickedPos().relative(direction));
            if (PaneSeparation.isGlassPane(neighbor)
                    && (separated || neighbor.getValue(PaneSeparation.SEPARATED))) {
                BooleanProperty connection = CrossCollisionBlock.PROPERTY_BY_DIRECTION.get(direction);
                placed = placed.setValue(connection, false);
            }
        }

        cir.setReturnValue(placed);
    }

    @Inject(method = "updateShape", at = @At("HEAD"), cancellable = true)
    private void randomstuff$keepSeparatedPaneBorders(
            BlockState state,
            LevelReader level,
            ScheduledTickAccess ticks,
            BlockPos pos,
            Direction directionToNeighbour,
            BlockPos neighbourPos,
            BlockState neighbourState,
            RandomSource random,
            CallbackInfoReturnable<BlockState> cir) {
        if (!directionToNeighbour.getAxis().isHorizontal()
                || !PaneSeparation.isGlassPane(state)
                || !PaneSeparation.isGlassPane(neighbourState)) {
            return;
        }

        if (state.getValue(PaneSeparation.SEPARATED)
                || neighbourState.getValue(PaneSeparation.SEPARATED)) {
            BooleanProperty connection = CrossCollisionBlock.PROPERTY_BY_DIRECTION.get(directionToNeighbour);
            cir.setReturnValue(state.setValue(connection, false));
        }
    }
}
