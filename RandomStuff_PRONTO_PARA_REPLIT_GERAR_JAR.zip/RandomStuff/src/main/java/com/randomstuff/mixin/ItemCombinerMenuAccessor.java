package com.randomstuff.mixin;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.ItemCombinerMenu;
import net.minecraft.world.inventory.ResultContainer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Acesso aos inventarios compartilhados pelos menus de bigorna e outros combinadores. */
@Mixin(ItemCombinerMenu.class)
public interface ItemCombinerMenuAccessor {
	@Accessor("inputSlots")
	Container randomstuff$getInputSlots();

	@Accessor("resultSlots")
	ResultContainer randomstuff$getResultSlots();
}
