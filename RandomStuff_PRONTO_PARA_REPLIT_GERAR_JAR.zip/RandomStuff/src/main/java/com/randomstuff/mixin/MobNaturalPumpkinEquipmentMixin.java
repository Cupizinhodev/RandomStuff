package com.randomstuff.mixin;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.monster.skeleton.AbstractSkeleton;
import net.minecraft.world.entity.monster.zombie.Zombie;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.level.biome.Biome;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Equipamento raro aplicado somente ao finalizar spawn natural na Floresta Salpicada. */
@Mixin(Mob.class)
public abstract class MobNaturalPumpkinEquipmentMixin {
    @Unique
    private static final ResourceKey<Biome> DAPPLED_FOREST = ResourceKey.create(
            Registries.BIOME, Identifier.withDefaultNamespace("dappled_forest"));

    @Inject(method = "finalizeSpawn", at = @At("TAIL"))
    private void randomstuff$equipPumpkinOnNaturalSpawn(ServerLevelAccessor level, DifficultyInstance difficulty,
                                                         EntitySpawnReason reason, SpawnGroupData groupData,
                                                         CallbackInfoReturnable<SpawnGroupData> cir) {
        if (reason != EntitySpawnReason.NATURAL) return;

        Mob mob = (Mob) (Object) this;
        if (!(mob instanceof Zombie || mob instanceof AbstractSkeleton || mob.getType().equals(EntityTypes.CREEPER))) return;
        if (!level.getBiome(mob.blockPosition()).is(DAPPLED_FOREST)) return;
        if (!mob.getItemBySlot(EquipmentSlot.HEAD).isEmpty()) return;

        float roll = mob.getRandom().nextFloat();
        if (roll < 0.004F) {
            mob.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.JACK_O_LANTERN));
            mob.setDropChance(EquipmentSlot.HEAD, 0.085F);
        } else if (roll < 0.025F) {
            mob.setItemSlot(EquipmentSlot.HEAD, new ItemStack(Items.CARVED_PUMPKIN));
            mob.setDropChance(EquipmentSlot.HEAD, 0.085F);
        }
    }
}
