package com.randomstuff.mixin;

import com.randomstuff.feature.BeaconEffects;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Preenche a reserva dobrada uma vez ao receber o efeito, sem renovar o ar a cada pulso do Beacon. */
@Mixin(LivingEntity.class)
public abstract class LivingEntityBeaconBreathingMixin {
    @Unique private boolean randomstuff$hadBeaconBreathing;

    @Inject(method = "tick", at = @At("TAIL"))
    private void randomstuff$adjustAirOnEffectTransition(CallbackInfo ci) {
        LivingEntity living = (LivingEntity) (Object) this;
        if (BeaconEffects.BREATHING == null) return;

        boolean hasBreathing = living.hasEffect(BeaconEffects.BREATHING);
        if (hasBreathing && !randomstuff$hadBeaconBreathing) {
            living.setAirSupply(living.getMaxAirSupply());
        } else if (!hasBreathing && randomstuff$hadBeaconBreathing
                && living.getAirSupply() > living.getMaxAirSupply()) {
            living.setAirSupply(living.getMaxAirSupply());
        }
        randomstuff$hadBeaconBreathing = hasBreathing;
    }
}
