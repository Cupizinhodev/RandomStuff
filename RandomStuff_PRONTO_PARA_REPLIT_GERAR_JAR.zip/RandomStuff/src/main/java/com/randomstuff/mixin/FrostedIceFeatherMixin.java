package com.randomstuff.mixin;

import com.randomstuff.feature.FeatherFalling;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.FrostedIceBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.util.RandomSource;
import net.minecraft.world.phys.AABB;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Queda de Penas evita que o gelo fragil derreta/quebre pelo tick enquanto o jogador pisa nele. */
@Mixin(FrostedIceBlock.class)
public abstract class FrostedIceFeatherMixin {
    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void randomstuff$protectFrostedIce(BlockState state, ServerLevel level, BlockPos pos,
                                               RandomSource random, CallbackInfo ci) {
        // A caixa inclui a face superior do bloco, onde ficam os pes da entidade.
        AABB standingArea = new AABB(pos).inflate(0.15D, 0.3D, 0.15D);
        for (LivingEntity entity : level.getEntitiesOfClass(LivingEntity.class, standingArea,
                living -> living.isAlive() && living.getOnPos().equals(pos))) {
            if (FeatherFalling.has(entity)) {
                // Reagenda para que o gelo volte a envelhecer normalmente quando a entidade sair.
                level.scheduleTick(pos, Blocks.FROSTED_ICE, 20);
                ci.cancel();
                return;
            }
        }
    }
}
