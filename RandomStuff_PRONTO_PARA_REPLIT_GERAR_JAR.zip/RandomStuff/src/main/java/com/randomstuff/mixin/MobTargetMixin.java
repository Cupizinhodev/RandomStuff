package com.randomstuff.mixin;

import com.randomstuff.feature.MobHeads;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.player.Player;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Cabecas de mobs: impede que o mob escolha como alvo um jogador usando a cabeca da sua propria especie.
 * Piglins tambem sao tratados separadamente por PiglinAiMixin, pois escolhem alvos pela Brain.
 */
@Mixin(Mob.class)
public abstract class MobTargetMixin {
	@Inject(method = "setTarget", at = @At("HEAD"), cancellable = true)
	private void randomstuff$ignoreSameSpeciesHead(LivingEntity target, CallbackInfo ci) {
		if (target instanceof Player player && MobHeads.protects((Mob) (Object) this, player.getItemBySlot(EquipmentSlot.HEAD))) {
			ci.cancel();
		}
	}
}
