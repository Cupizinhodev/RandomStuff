package com.randomstuff.mixin;

import com.randomstuff.feature.BeaconEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/** Faz a capacidade maxima de ar valer o dobro enquanto Respiração estiver ativo. */
@Mixin(Entity.class)
public abstract class EntityBeaconBreathingMixin {
    @Inject(method = "getMaxAirSupply", at = @At("RETURN"), cancellable = true)
    private void randomstuff$doubleAirSupply(CallbackInfoReturnable<Integer> cir) {
        Entity entity = (Entity) (Object) this;
        if (entity instanceof LivingEntity living && BeaconEffects.BREATHING != null
                && living.hasEffect(BeaconEffects.BREATHING)) {
            cir.setReturnValue(cir.getReturnValue() * 2);
        }
    }
}
