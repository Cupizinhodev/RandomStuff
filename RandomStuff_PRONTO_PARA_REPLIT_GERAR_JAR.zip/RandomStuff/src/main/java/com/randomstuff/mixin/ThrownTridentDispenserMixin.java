package com.randomstuff.mixin;

import com.randomstuff.mixin.DispenserTridentAccess;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.Container;
import net.minecraft.world.entity.projectile.arrow.ThrownTrident;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.DispenserBlockEntity;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.entity.item.ItemEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Lealdade em tridente de ejetor devolve o item ao inventario do ejetor de origem. */
@Mixin(ThrownTrident.class)
public abstract class ThrownTridentDispenserMixin implements DispenserTridentAccess {
    @Shadow private boolean dealtDamage;

    @Unique private BlockPos randomstuff$dispenserPos;
    @Unique private boolean randomstuff$returning;

    @Override
    public void randomstuff$setDispenserPos(BlockPos pos) {
        this.randomstuff$dispenserPos = pos.immutable();
    }

    @Inject(method = "tick", at = @At("TAIL"))
    private void randomstuff$returnToDispenser(CallbackInfo ci) {
        ThrownTrident trident = (ThrownTrident) (Object) this;
        if (randomstuff$dispenserPos == null || trident.level().isClientSide()) return;
        ServerLevel level = (ServerLevel) trident.level();

        var enchantments = level.registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
        ItemStack weaponStack = trident.getWeaponItem();
        if (EnchantmentHelper.getItemEnchantmentLevel(enchantments.getOrThrow(Enchantments.LOYALTY), weaponStack) <= 0) return;
        ItemStack tridentStack = trident.getPickupItemStackOrigin();

        if (!randomstuff$returning && (((AbstractArrowAccess) trident).randomstuff$isInGround() || dealtDamage)) {
            randomstuff$returning = true;
            ((AbstractArrowAccess) trident).randomstuff$setInGround(false);
            trident.setNoPhysics(true);
            trident.setNoGravity(true);
        }
        if (!randomstuff$returning) return;
        trident.setNoPhysics(true);
        trident.setNoGravity(true);
        ((AbstractArrowAccess) trident).randomstuff$setInGround(false);

        BlockEntity blockEntity = level.getBlockEntity(randomstuff$dispenserPos);
        if (!(blockEntity instanceof DispenserBlockEntity dispenser)) {
            ItemStack drop = tridentStack.copy();
            level.addFreshEntity(new ItemEntity(level, trident.getX(), trident.getY(), trident.getZ(), drop));
            trident.discard();
            return;
        }

        Vec3 destination = Vec3.atCenterOf(randomstuff$dispenserPos).add(0.0D, 0.35D, 0.0D);
        Vec3 difference = destination.subtract(trident.position());
        if (difference.lengthSqr() <= 1.0D) {
            Container inventory = dispenser;
            ItemStack returningStack = tridentStack.copy();
            for (int slot = 0; slot < inventory.getContainerSize(); slot++) {
                if (inventory.getItem(slot).isEmpty()) {
                    inventory.setItem(slot, returningStack);
                    inventory.setChanged();
                    trident.discard();
                    return;
                }
            }
            // Se estiver cheio, o tridente aguarda ao lado do ejetor sem desaparecer.
            trident.setPos(destination.x, destination.y + 0.8D, destination.z);
            trident.setDeltaMovement(Vec3.ZERO);
            return;
        }

        Vec3 step = difference.normalize().scale(0.8D);
        trident.setPos(trident.getX() + step.x, trident.getY() + step.y, trident.getZ() + step.z);
        trident.setDeltaMovement(Vec3.ZERO);
    }

    @Inject(method = "addAdditionalSaveData", at = @At("TAIL"))
    private void randomstuff$saveDispenserOrigin(ValueOutput output, CallbackInfo ci) {
        if (randomstuff$dispenserPos == null) return;
        output.putInt("RandomStuffDispenserX", randomstuff$dispenserPos.getX());
        output.putInt("RandomStuffDispenserY", randomstuff$dispenserPos.getY());
        output.putInt("RandomStuffDispenserZ", randomstuff$dispenserPos.getZ());
        output.putBoolean("RandomStuffReturning", randomstuff$returning);
    }

    @Inject(method = "readAdditionalSaveData", at = @At("TAIL"))
    private void randomstuff$loadDispenserOrigin(ValueInput input, CallbackInfo ci) {
        if (input.getInt("RandomStuffDispenserX").isEmpty()) return;
        randomstuff$dispenserPos = new BlockPos(
                input.getIntOr("RandomStuffDispenserX", 0),
                input.getIntOr("RandomStuffDispenserY", 0),
                input.getIntOr("RandomStuffDispenserZ", 0)
        );
        randomstuff$returning = input.getBooleanOr("RandomStuffReturning", false);
    }
}
