package com.randomstuff.mixin;

import com.randomstuff.feature.FeatherFalling;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.FarmBlock;
import net.minecraft.world.level.block.state.BlockState;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Queda de Penas impede pisotear plantacoes (mantem o dano de queda normal). */
@Mixin(FarmBlock.class)
public abstract class FarmBlockFeatherMixin {
	@Inject(method = "fallOn", at = @At("HEAD"), cancellable = true, require = 0)
	private void randomstuff$noTrample(Level level, BlockState state, BlockPos pos, Entity entity, double fallDistance, CallbackInfo ci) {
		if (FeatherFalling.has(entity)) {
			entity.causeFallDamage(fallDistance, 1.0F, entity.damageSources().fall());
			ci.cancel();
		}
	}
}
