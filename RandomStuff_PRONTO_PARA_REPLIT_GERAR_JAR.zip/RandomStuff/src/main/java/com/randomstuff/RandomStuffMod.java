package com.randomstuff;

import com.randomstuff.feature.AnvilRepair;
import com.randomstuff.feature.BeaconEffects;
import com.randomstuff.feature.TridentDispenser;
import com.randomstuff.feature.BrushPainting;
import com.randomstuff.feature.ColoredWater;
import com.randomstuff.feature.BucketCapture;
import com.randomstuff.feature.GoldSwordBuff;
import com.randomstuff.feature.MinecartChains;
import com.randomstuff.feature.SleepAcceleration;
import com.randomstuff.feature.WanderingTraderTrades;
import com.randomstuff.registry.ModBlocks;
import com.randomstuff.registry.ModBrushes;
import com.randomstuff.registry.ModCopperHoppers;
import com.randomstuff.registry.ModCopperHopperMinecart;
import com.randomstuff.registry.ModColoredFrames;
import com.randomstuff.registry.ModCreativeTabs;
import com.randomstuff.registry.ModDiscs;
import com.randomstuff.registry.ModItems;
import com.randomstuff.registry.ModEntities;
import com.randomstuff.world.ModLootTables;
import com.randomstuff.world.ModWorldgen;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Ponto de entrada do Random Stuff (lado comum: cliente + servidor).
 * Cada sistema fica em seu proprio pacote (registry, block, item, entity, world...).
 */
public class RandomStuffMod implements ModInitializer {
	public static final String MOD_ID = "randomstuff";
	public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

	@Override
	public void onInitialize() {
		// Efeitos de Beacon antes de qualquer bloco/GUI que possa carregar o registro vanilla.
		BeaconEffects.init();
		TridentDispenser.init();
		// Entidades primeiro porque os ovos de invocacao referenciam seus EntityTypes.
		// A aba criativa e registrada por ultimo.
		ModEntities.init();
		ModWorldgen.init();
		ModCopperHopperMinecart.init();
		ModItems.init();
		com.randomstuff.item.ContextualBlackFoxSpawnEggItem.init();
		ModDiscs.init();
		ModBrushes.init();
		ModBlocks.init();
		ModColoredFrames.init();
		ModCopperHoppers.init();
		ModCreativeTabs.init();
		ModLootTables.init();
		GoldSwordBuff.init();
		AnvilRepair.init();
		BucketCapture.init();
		com.randomstuff.feature.SlimeDyeing.init();
		WanderingTraderTrades.init();
		ColoredWater.init();
		BrushPainting.init();
		com.randomstuff.feature.SlimeBlockDyeing.init();
		SleepAcceleration.init();
		MinecartChains.init();
		LOGGER.info("Random Stuff carregado: entidades-base e sistemas existentes inicializados.");
	}

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}
}
