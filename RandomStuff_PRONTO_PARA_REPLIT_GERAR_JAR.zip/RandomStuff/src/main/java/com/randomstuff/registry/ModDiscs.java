package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.JukeboxSong;
import net.minecraft.world.item.Rarity;

/**
 * Discos musicais: Aria Math, Biome Fest, Blind Spots, Dreiton, Haunt Muskie e Taswell.
 * O audio NAO e distribuido pelo mod: assets/randomstuff/sounds.json aponta cada disco para a musica Criativo que o proprio
 * Minecraft ja contem (minecraft:music/game/creative/&lt;nome&gt;). A duracao/saida do comparador ficam em
 * data/randomstuff/jukebox_song/&lt;nome&gt;.json. Obtidos no Survival em vilas e strongholds (world/ModLootTables).
 */
public final class ModDiscs {
	public static final Map<String, Item> DISCS = new LinkedHashMap<>();

	static {
		for (String name : new String[] {"aria_math", "biome_fest", "blind_spots", "dreiton", "haunt_muskie", "taswell"}) {
			Identifier soundId = RandomStuffMod.id("music_disc." + name);
			Registry.register(BuiltInRegistries.SOUND_EVENT, soundId, SoundEvent.createVariableRangeEvent(soundId));
			ResourceKey<JukeboxSong> song = ResourceKey.create(Registries.JUKEBOX_SONG, RandomStuffMod.id(name));
			DISCS.put(name, ModItems.register("music_disc_" + name,
					p -> new Item(p.stacksTo(1).rarity(Rarity.RARE).jukeboxPlayable(song))));
		}
	}

	private ModDiscs() {}

	public static void init() {
		RandomStuffMod.LOGGER.info("Random Stuff: {} discos registrados.", DISCS.size());
	}
}
