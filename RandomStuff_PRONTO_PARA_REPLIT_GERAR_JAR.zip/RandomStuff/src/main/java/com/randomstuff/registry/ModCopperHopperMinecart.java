package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.entity.vehicle.CopperHopperMinecart;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;

/** Registro da entidade própria do Funil de Cobre em Carrinho de Mina. */
public final class ModCopperHopperMinecart {
	public static final ResourceKey<EntityType<?>> KEY = ResourceKey.create(Registries.ENTITY_TYPE, RandomStuffMod.id("copper_hopper_minecart"));
	public static final EntityType<CopperHopperMinecart> TYPE = Registry.register(BuiltInRegistries.ENTITY_TYPE, KEY,
			EntityType.Builder.<CopperHopperMinecart>of(CopperHopperMinecart::new, MobCategory.MISC)
					.noLootTable().sized(0.98F, 0.7F).passengerAttachments(0.1875F).clientTrackingRange(8).build(KEY));

	private ModCopperHopperMinecart() {}

	public static void init() {
		RandomStuffMod.LOGGER.info("Random Stuff: Funil de Cobre em Carrinho de Mina registrado.");
	}
}
