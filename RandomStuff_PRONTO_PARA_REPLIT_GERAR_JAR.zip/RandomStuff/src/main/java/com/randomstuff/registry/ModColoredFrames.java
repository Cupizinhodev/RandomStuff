package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.entity.decoration.ModdedItemFrame;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.InteractionResult;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemFrameItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Tipos de moldura e blocos auxiliares usados apenas pelo renderizador da entidade. */
public final class ModColoredFrames {
	public static final List<String> COLORS = List.of("black", "blue", "brown", "cyan", "gray", "green",
			"light_blue", "light_gray", "lime", "magenta", "orange", "pink", "purple", "red", "white", "yellow");
	private static final Map<String, EntityType<ItemFrame>> TYPES = new LinkedHashMap<>();
	private static final Map<String, BlockState> FRAME_STATES = new LinkedHashMap<>();
	private static final Map<String, BlockState> FRAME_MAP_STATES = new LinkedHashMap<>();
	public static EntityType<ItemFrame> INVISIBLE_TYPE;

	private ModColoredFrames() {}

	public static EntityType<ItemFrame> type(String color) {
		return TYPES.get(color);
	}

	public static BlockState frameState(String color, boolean map) {
		return (map ? FRAME_MAP_STATES : FRAME_STATES).get(color);
	}

	private static EntityType<ItemFrame> registerFrameType(String name) {
		ResourceKey<EntityType<?>> key = ResourceKey.create(Registries.ENTITY_TYPE, RandomStuffMod.id(name));
		return Registry.register(BuiltInRegistries.ENTITY_TYPE, key,
				EntityType.Builder.<ItemFrame>of(ModdedItemFrame::new, MobCategory.MISC)
						.noLootTable().sized(0.5F, 0.5F).clientTrackingRange(10).build(key));
	}

	public static void init() {
		for (String color : COLORS) {
			Block renderBlock = ModBlocks.registerNoItem("render_item_frame_" + color,
					Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.GLASS).noCollission().noOcclusion().strength(0.0F));
			FRAME_STATES.put(color, renderBlock.defaultBlockState());
			Block mapRenderBlock = ModBlocks.registerNoItem("render_item_frame_map_" + color,
					Block::new, BlockBehaviour.Properties.ofFullCopy(Blocks.GLASS).noCollission().noOcclusion().strength(0.0F));
			FRAME_MAP_STATES.put(color, mapRenderBlock.defaultBlockState());
			EntityType<ItemFrame> type = registerFrameType("colored_item_frame_" + color);
			TYPES.put(color, type);
			ModItems.register(color + "_item_frame", properties -> new ItemFrameItem(type, properties));
		}
		INVISIBLE_TYPE = registerFrameType("invisible_item_frame");
		ModItems.register("invisible_item_frame", properties -> new ItemFrameItem(INVISIBLE_TYPE, properties));

		// A especificacao tambem permite mudar a cor: agachar + usar o corante na moldura.
		UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
			if (!(entity instanceof ItemFrame frame) || !player.isShiftKeyDown()) return InteractionResult.PASS;
			String currentId = BuiltInRegistries.ENTITY_TYPE.getKey(frame.getType()).getPath();
			if (!currentId.startsWith("colored_item_frame_")) return InteractionResult.PASS;
			ItemStack held = player.getItemInHand(hand);
			String dyeId = BuiltInRegistries.ITEM.getKey(held.getItem()).getPath();
			if (!dyeId.endsWith("_dye")) return InteractionResult.PASS;
			String color = dyeId.substring(0, dyeId.length() - 4);
			EntityType<ItemFrame> targetType = TYPES.get(color);
			if (targetType == null) return InteractionResult.PASS;
			if (currentId.equals("colored_item_frame_" + color)) return InteractionResult.SUCCESS;
			if (level.isClientSide() || !(player instanceof ServerPlayer) || !(level instanceof ServerLevel serverLevel)) return InteractionResult.SUCCESS;
			ItemFrame replacement = new ModdedItemFrame(targetType, level, frame.getPos(), frame.getDirection());
			replacement.setItem(frame.getItem().copy(), false);
			replacement.setRotation(frame.getRotation());
			if (frame.getCustomName() != null) replacement.setCustomName(frame.getCustomName());
			if (serverLevel.addFreshEntity(replacement)) {
				frame.kill(serverLevel); // remove corretamente a decoracao de mapa da entidade antiga
				held.consume(1, player);
				replacement.playPlacementSound();
				return InteractionResult.SUCCESS;
			}
			return InteractionResult.FAIL;
		});
		RandomStuffMod.LOGGER.info("Random Stuff: 16 molduras coloridas, recoloracao por corante e moldura invisivel registradas.");
	}
}
