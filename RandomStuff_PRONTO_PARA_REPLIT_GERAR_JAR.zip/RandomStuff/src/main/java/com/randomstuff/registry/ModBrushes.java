package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.item.ColoredBrushItem;
import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;

/** 16 pinceis coloridos (um por corante). Registrados pelo mesmo caminho dos demais itens (aparecem na aba criativa via ModItems.ALL). */
public final class ModBrushes {
	public static final Map<DyeColor, Item> BRUSHES = new LinkedHashMap<>();

	static {
		for (DyeColor color : DyeColor.values()) {
			BRUSHES.put(color, ModItems.register(color.getSerializedName() + "_brush",
					p -> new ColoredBrushItem(color, p.stacksTo(1).durability(64))));
		}
	}

	private ModBrushes() {}

	public static void init() {
		RandomStuffMod.LOGGER.info("Random Stuff: {} pinceis coloridos registrados.", BRUSHES.size());
	}
}
