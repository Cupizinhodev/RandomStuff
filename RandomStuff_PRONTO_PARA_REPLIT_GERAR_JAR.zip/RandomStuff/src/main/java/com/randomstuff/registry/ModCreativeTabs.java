package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;

/** Aba criativa propria do mod, com todos os itens e blocos registrados. */
public final class ModCreativeTabs {
	public static final ResourceKey<CreativeModeTab> MAIN_KEY =
			ResourceKey.create(Registries.CREATIVE_MODE_TAB, RandomStuffMod.id("main"));

	private ModCreativeTabs() {}

	public static void init() {
		CreativeModeTab tab = FabricItemGroup.builder()
				.title(Component.translatable("itemGroup.randomstuff.main"))
				.icon(() -> new ItemStack(ModItems.RAW_ROSE_GOLD))
				.displayItems((params, output) -> {
					ModItems.ALL.values().forEach(output::accept);
					ModBlocks.ALL_ITEMS.values().forEach(output::accept);
				})
				.build();
		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, MAIN_KEY, tab);
	}
}
