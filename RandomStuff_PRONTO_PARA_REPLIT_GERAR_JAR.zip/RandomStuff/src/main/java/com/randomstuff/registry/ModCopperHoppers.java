package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.block.CopperHopperBlock;
import com.randomstuff.block.CopperHopperBlock.Age;
import com.randomstuff.block.entity.CopperHopperBlockEntity;
import java.util.EnumMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Registro dos 8 funis de cobre (4 oxidacoes x encerado) e do BlockEntityType compartilhado. */
public final class ModCopperHoppers {
	private static final Map<Age, Block> NORMAL = new EnumMap<>(Age.class);
	private static final Map<Age, Block> WAXED = new EnumMap<>(Age.class);
	public static BlockEntityType<CopperHopperBlockEntity> BLOCK_ENTITY;

	private ModCopperHoppers() {}

	public static Block get(Age age, boolean waxed) {
		return (waxed ? WAXED : NORMAL).get(age);
	}

	private static String name(Age age, boolean waxed) {
		String base = age == Age.NORMAL ? "copper_hopper" : age.name().toLowerCase() + "_copper_hopper";
		return waxed ? "waxed_" + base : base;
	}

	public static void init() {
		Set<Block> all = new HashSet<>();
		for (Age age : Age.values()) {
			for (boolean waxed : new boolean[] {false, true}) {
				BlockBehaviour.Properties props = BlockBehaviour.Properties.ofFullCopy(Blocks.HOPPER).sound(SoundType.COPPER);
				if (!waxed && age != Age.OXIDIZED) props = props.randomTicks();
				Block b = ModBlocks.register(name(age, waxed), p -> new CopperHopperBlock(p, age, waxed), props, null);
				(waxed ? WAXED : NORMAL).put(age, b);
				all.add(b);
			}
		}
		// Construtor publico de BlockEntityType (MC 1.21.9+/26.x). Se o compilador reclamar, usar FabricBlockEntityTypeBuilder.
		BLOCK_ENTITY = Registry.register(BuiltInRegistries.BLOCK_ENTITY_TYPE, RandomStuffMod.id("copper_hopper"),
				new BlockEntityType<>(CopperHopperBlockEntity::new, all));
	}
}
