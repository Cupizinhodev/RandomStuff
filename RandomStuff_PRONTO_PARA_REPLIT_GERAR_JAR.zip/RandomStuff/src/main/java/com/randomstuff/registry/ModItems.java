package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.item.CapturedSlimeBucketItem;
import com.randomstuff.item.ContextualBlackFoxSpawnEggItem;
import com.randomstuff.registry.ModCopperHopperMinecart;
import net.minecraft.world.item.SpawnEggItem;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.MinecartItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.Equippable;

/** Registro dos itens que nao sao BlockItems. Etapa 1. */
public final class ModItems {
	public static final Map<String, Item> ALL = new LinkedHashMap<>();

	public static final Item RAW_ROSE_GOLD = register("raw_rose_gold");
	public static final Item ROSE_GOLD_INGOT = register("rose_gold_ingot");
	public static final Item WITHER_BONE = register("wither_bone");
	public static final Item WITHER_BONE_MEAL = register("wither_bone_meal");
	public static final Item ROSE_GOLD_UPGRADE_SMITHING_TEMPLATE = register("rose_gold_upgrade_smithing_template");
	public static final Item COPPER_HOPPER_MINECART = register("copper_hopper_minecart", p -> new MinecartItem(ModCopperHopperMinecart.TYPE, p.stacksTo(1)));

	// Ouro Rosa: so por ferraria (molde + equipamento de ouro + lingote de ouro rosa)
	// Sword/Pickaxe usam os metodos de Item.Properties; Axe/Hoe/Shovel mantem suas classes (decapar, arar, caminho).
	public static final Item ROSE_GOLD_SWORD = register("rose_gold_sword", p -> new Item(p.sword(ModEquipment.ROSE_GOLD_TOOLS, 3.0F, -2.4F)));
	public static final Item ROSE_GOLD_PICKAXE = register("rose_gold_pickaxe", p -> new Item(p.pickaxe(ModEquipment.ROSE_GOLD_TOOLS, 1.0F, -2.8F)));
	public static final Item ROSE_GOLD_AXE = register("rose_gold_axe", p -> new AxeItem(ModEquipment.ROSE_GOLD_TOOLS, 6.0F, -3.1F, p));
	public static final Item ROSE_GOLD_SHOVEL = register("rose_gold_shovel", p -> new ShovelItem(ModEquipment.ROSE_GOLD_TOOLS, 1.5F, -3.0F, p));
	public static final Item ROSE_GOLD_HOE = register("rose_gold_hoe", p -> new HoeItem(ModEquipment.ROSE_GOLD_TOOLS, 0.0F, -3.0F, p));
	public static final Item ROSE_GOLD_HELMET = register("rose_gold_helmet", p -> new Item(p.humanoidArmor(ModEquipment.ROSE_GOLD_ARMOR, ArmorType.HELMET)));
	public static final Item ROSE_GOLD_CHESTPLATE = register("rose_gold_chestplate", p -> new Item(p.humanoidArmor(ModEquipment.ROSE_GOLD_ARMOR, ArmorType.CHESTPLATE)));
	public static final Item ROSE_GOLD_LEGGINGS = register("rose_gold_leggings", p -> new Item(p.humanoidArmor(ModEquipment.ROSE_GOLD_ARMOR, ArmorType.LEGGINGS)));
	public static final Item ROSE_GOLD_BOOTS = register("rose_gold_boots", p -> new Item(p.humanoidArmor(ModEquipment.ROSE_GOLD_ARMOR, ArmorType.BOOTS)));
	public static final Item ROSE_GOLD_HORSE_ARMOR = register("rose_gold_horse_armor", p -> new Item(p.horseArmor(ModEquipment.ROSE_GOLD_ARMOR)));

	// Baldes: guardam tamanho, nome e vida do mob (nao ha tingimento para Magma Cube)
	public static final Item SLIME_BUCKET = register("slime_bucket", p -> new CapturedSlimeBucketItem(net.minecraft.world.entity.EntityTypes.SLIME, p.stacksTo(1)));
	public static final Item MAGMA_CUBE_BUCKET = register("magma_cube_bucket", p -> new CapturedSlimeBucketItem(net.minecraft.world.entity.EntityTypes.MAGMA_CUBE, p.stacksTo(1)));

    public static final Item MOOBLOOM_SPAWN_EGG = register("moobloom_spawn_egg",
            p -> new SpawnEggItem(p.spawnEgg(ModEntities.MOOBLOOM)));
    public static final Item MOONLIP_SPAWN_EGG = register("moonlip_spawn_egg",
            p -> new SpawnEggItem(p.spawnEgg(ModEntities.MOONLIP)));
    public static final Item BLACK_FOX_SPAWN_EGG = register("black_fox_spawn_egg",
            p -> new ContextualBlackFoxSpawnEggItem(p.spawnEgg(ModEntities.BLACK_FOX)));

	private ModItems() {}

	private static Item register(String name) {
		return register(name, Item::new);
	}

	static Item register(String name, Function<Item.Properties, Item> factory) {
		ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, RandomStuffMod.id(name));
		Item item = Registry.register(BuiltInRegistries.ITEM, key, factory.apply(new Item.Properties().setId(key)));
		ALL.put(name, item);
		return item;
	}

	/** Abobora entalhada pode ser usada na cabeca, com o mesmo efeito visual escuro da vanilla. */
	public static Item.Properties carvedPumpkinHeadProperties(Item.Properties properties) {
		return properties.component(DataComponents.EQUIPPABLE,
				Equippable.builder(EquipmentSlot.HEAD)
						.setSwappable(false)
						.setCameraOverlay(Identifier.withDefaultNamespace("misc/pumpkinblur"))
						.build());
	}

	public static void init() {
		RandomStuffMod.LOGGER.info("Random Stuff: {} itens registrados.", ALL.size());
	}
}
