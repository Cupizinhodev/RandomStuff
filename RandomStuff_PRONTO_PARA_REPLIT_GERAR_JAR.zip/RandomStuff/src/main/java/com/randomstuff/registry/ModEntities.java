package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.mixin.SpawnPlacementsInvoker;
import com.randomstuff.entity.FlowerCowEntity;
import com.randomstuff.entity.BlackFoxEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.animal.Animal;
import net.minecraft.world.entity.SpawnPlacementTypes;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.entity.animal.fox.Fox;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;

/** Entidades florais com variantes sincronizadas, tesoura e regeneracao das flores. */
public final class ModEntities {
    public static final ResourceKey<EntityType<?>> MOOBLOOM_KEY = key("moobloom");
    public static final ResourceKey<EntityType<?>> MOONLIP_KEY = key("moonlip");
    public static final EntityType<Cow> MOOBLOOM = registerFlowerCow(MOOBLOOM_KEY, false);
    public static final EntityType<Cow> MOONLIP = registerFlowerCow(MOONLIP_KEY, true);
    public static final ResourceKey<EntityType<?>> BLACK_FOX_KEY = key("black_fox");
    public static final EntityType<Fox> BLACK_FOX = registerBlackFox();
    // A Floresta Salpicada do briefing corresponde ao bioma vanilla Dappled Forest do Minecraft 26.3.
    public static final ResourceKey<Biome> DAPPLED_FOREST_KEY = ResourceKey.create(Registries.BIOME, Identifier.withDefaultNamespace("dappled_forest"));
    // Bioma adicional do mod: variante de Cherry Grove com bambus altos em grupos.
    public static final ResourceKey<Biome> CHERRY_BAMBOO_GROVE_KEY = ResourceKey.create(Registries.BIOME, RandomStuffMod.id("cherry_bamboo_grove"));

    private ModEntities() {}
    private static ResourceKey<EntityType<?>> key(String name) {
        return ResourceKey.create(Registries.ENTITY_TYPE, RandomStuffMod.id(name));
    }
    private static <T extends Animal> void registerGroundSpawn(EntityType<T> type) {
        SpawnPlacementsInvoker.randomstuff$register(type, SpawnPlacementTypes.ON_GROUND,
                Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,
                (entityType, level, reason, pos, random) -> Animal.checkAnimalSpawnRules(entityType, level, reason, pos, random));
    }

    private static EntityType<Cow> registerFlowerCow(ResourceKey<EntityType<?>> key, boolean moonlip) {
        EntityType<Cow> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, key,
                EntityType.Builder.<Cow>of((entityType, level) -> new FlowerCowEntity(entityType, level, moonlip), MobCategory.CREATURE)
                        .sized(0.9F, 1.4F).build(key));
        FabricDefaultAttributeRegistry.register(type, Cow.createAttributes());
        return type;
    }
    private static EntityType<Fox> registerBlackFox() {
        EntityType<Fox> type = Registry.register(BuiltInRegistries.ENTITY_TYPE, BLACK_FOX_KEY,
                EntityType.Builder.<Fox>of(BlackFoxEntity::new, MobCategory.CREATURE)
                        .sized(0.6F, 0.7F).build(BLACK_FOX_KEY));
        FabricDefaultAttributeRegistry.register(type, Fox.createAttributes());
        return type;
    }

    public static void init() {
        // Sem placement registrado, BiomeModifications.addSpawn sozinho nao habilita o spawn natural.
        registerGroundSpawn(MOOBLOOM);
        registerGroundSpawn(MOONLIP);
        registerGroundSpawn(BLACK_FOX);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.FOREST),
                MobCategory.CREATURE, MOOBLOOM, 4, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(Biomes.CHERRY_GROVE),
                MobCategory.CREATURE, MOONLIP, 4, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(DAPPLED_FOREST_KEY),
                MobCategory.CREATURE, BLACK_FOX, 6, 1, 2);
        BiomeModifications.addSpawn(BiomeSelectors.includeByKey(CHERRY_BAMBOO_GROVE_KEY),
                MobCategory.CREATURE, MOONLIP, 5, 1, 2);
        RandomStuffMod.LOGGER.info("Random Stuff: Moobloom, Moonlip e Raposa Negra registrados.");
    }
}
