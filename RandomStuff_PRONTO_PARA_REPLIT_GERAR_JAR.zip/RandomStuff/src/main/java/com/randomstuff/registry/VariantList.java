package com.randomstuff.registry;

import java.util.List;

/** GERADO por scripts/gerar_dados.py - nao edite a mao. Variantes de laje/escada/muro baseadas em blocos vanilla. */
public final class VariantList {
	public enum Kind { SLAB, STAIRS, WALL }

	public record Entry(String name, String baseBlock, Kind kind) {}

	public static final List<Entry> ENTRIES = List.of(
		new Entry("basalt_slab", "basalt", Kind.SLAB),
		new Entry("polished_basalt_slab", "polished_basalt", Kind.SLAB),
		new Entry("end_stone_slab", "end_stone", Kind.SLAB),
		new Entry("smooth_stone_stairs", "smooth_stone", Kind.STAIRS),
		new Entry("cut_sandstone_stairs", "cut_sandstone", Kind.STAIRS),
		new Entry("cut_red_sandstone_stairs", "cut_red_sandstone", Kind.STAIRS),
		new Entry("quartz_bricks_slab", "quartz_bricks", Kind.SLAB),
		new Entry("quartz_bricks_stairs", "quartz_bricks", Kind.STAIRS),
		new Entry("moss_slab", "moss_block", Kind.SLAB),
		new Entry("moss_stairs", "moss_block", Kind.STAIRS),
		new Entry("magma_slab", "magma_block", Kind.SLAB),
		new Entry("magma_stairs", "magma_block", Kind.STAIRS),
		new Entry("amethyst_slab", "amethyst_block", Kind.SLAB),
		new Entry("amethyst_stairs", "amethyst_block", Kind.STAIRS),
		new Entry("amethyst_wall", "amethyst_block", Kind.WALL),
		new Entry("quartz_wall", "quartz_block", Kind.WALL),
		new Entry("dark_prismarine_wall", "dark_prismarine", Kind.WALL),
		new Entry("prismarine_bricks_wall", "prismarine_bricks", Kind.WALL),
		new Entry("terracotta_wall", "terracotta", Kind.WALL),
		new Entry("white_terracotta_wall", "white_terracotta", Kind.WALL),
		new Entry("orange_terracotta_wall", "orange_terracotta", Kind.WALL),
		new Entry("magenta_terracotta_wall", "magenta_terracotta", Kind.WALL),
		new Entry("light_blue_terracotta_wall", "light_blue_terracotta", Kind.WALL),
		new Entry("yellow_terracotta_wall", "yellow_terracotta", Kind.WALL),
		new Entry("lime_terracotta_wall", "lime_terracotta", Kind.WALL),
		new Entry("pink_terracotta_wall", "pink_terracotta", Kind.WALL),
		new Entry("gray_terracotta_wall", "gray_terracotta", Kind.WALL),
		new Entry("light_gray_terracotta_wall", "light_gray_terracotta", Kind.WALL),
		new Entry("cyan_terracotta_wall", "cyan_terracotta", Kind.WALL),
		new Entry("purple_terracotta_wall", "purple_terracotta", Kind.WALL),
		new Entry("blue_terracotta_wall", "blue_terracotta", Kind.WALL),
		new Entry("brown_terracotta_wall", "brown_terracotta", Kind.WALL),
		new Entry("green_terracotta_wall", "green_terracotta", Kind.WALL),
		new Entry("red_terracotta_wall", "red_terracotta", Kind.WALL),
		new Entry("black_terracotta_wall", "black_terracotta", Kind.WALL),
		new Entry("white_concrete_wall", "white_concrete", Kind.WALL),
		new Entry("orange_concrete_wall", "orange_concrete", Kind.WALL),
		new Entry("magenta_concrete_wall", "magenta_concrete", Kind.WALL),
		new Entry("light_blue_concrete_wall", "light_blue_concrete", Kind.WALL),
		new Entry("yellow_concrete_wall", "yellow_concrete", Kind.WALL),
		new Entry("lime_concrete_wall", "lime_concrete", Kind.WALL),
		new Entry("pink_concrete_wall", "pink_concrete", Kind.WALL),
		new Entry("gray_concrete_wall", "gray_concrete", Kind.WALL),
		new Entry("light_gray_concrete_wall", "light_gray_concrete", Kind.WALL),
		new Entry("cyan_concrete_wall", "cyan_concrete", Kind.WALL),
		new Entry("purple_concrete_wall", "purple_concrete", Kind.WALL),
		new Entry("blue_concrete_wall", "blue_concrete", Kind.WALL),
		new Entry("brown_concrete_wall", "brown_concrete", Kind.WALL),
		new Entry("green_concrete_wall", "green_concrete", Kind.WALL),
		new Entry("red_concrete_wall", "red_concrete", Kind.WALL),
		new Entry("black_concrete_wall", "black_concrete", Kind.WALL)
	);

	private VariantList() {}
}
