package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import java.util.Map;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

/**
 * Materiais do Ouro Rosa.
 * Especificacao: durabilidade igual a do COBRE; velocidade/eficiencia de mineracao igual a do OURO.
 * Valores: durabilidade de ferramenta 190 (cobre), velocidade 12 (ouro), encantabilidade 22 (ouro);
 * armadura com multiplicador 11 (cobre). Pontos de defesa NAO estavam no briefing: usei 2/4/3/1 (ajuste abaixo).
 */
public final class ModEquipment {
	public static final TagKey<Item> ROSE_GOLD_REPAIR = TagKey.create(Registries.ITEM, RandomStuffMod.id("rose_gold_repair"));

	public static final ToolMaterial ROSE_GOLD_TOOLS = new ToolMaterial(
			BlockTags.INCORRECT_FOR_STONE_TOOL, 190, 12.0F, 1.0F, 22, ROSE_GOLD_REPAIR);

	public static final ResourceKey<EquipmentAsset> ROSE_GOLD_ASSET =
			ResourceKey.create(EquipmentAssets.ROOT_ID, RandomStuffMod.id("rose_gold"));

	public static final ArmorMaterial ROSE_GOLD_ARMOR = new ArmorMaterial(
			11,
			Map.of(ArmorType.HELMET, 2, ArmorType.CHESTPLATE, 4, ArmorType.LEGGINGS, 3, ArmorType.BOOTS, 1,
					ArmorType.BODY, 4),
			22,
			SoundEvents.ARMOR_EQUIP_GOLD,
			0.0F,
			0.0F,
			ROSE_GOLD_REPAIR,
			ROSE_GOLD_ASSET);

	private ModEquipment() {}
}
