package com.randomstuff.registry;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.block.CarvedWhitePumpkinBlock;
import com.randomstuff.block.ColoredWaterCauldronBlock;
import com.randomstuff.block.GoldenCarrotsBlock;
import com.randomstuff.block.WhitePumpkinBlock;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.FlowerBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.SlimeBlock;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;

/** Registro de todos os blocos (e seus BlockItems). Etapa 1. */
public final class ModBlocks {
	/** Todos os blocos do mod, na ordem de registro (usado pela aba criativa). */
	public static final Map<String, Block> ALL = new LinkedHashMap<>();
	public static final Map<String, Item> ALL_ITEMS = new LinkedHashMap<>();

	// Ouro Rosa: copia explicitamente som e propriedades de mineração dos blocos vanilla correspondentes.
	public static final Block ROSE_GOLD_BLOCK = register("rose_gold_block", Block::new,
			copyBlockProperties(Blocks.GOLD_BLOCK), null);
	public static final Block RAW_ROSE_GOLD_BLOCK = register("raw_rose_gold_block", Block::new,
			copyBlockProperties(Blocks.RAW_GOLD_BLOCK), null);

	// Osso de Wither: som igual ao Bloco de Ossos
	public static final Block WITHER_BONE_BLOCK = register("wither_bone_block", RotatedPillarBlock::new, copyBlockProperties(Blocks.BONE_BLOCK), null);

	// Abobora Branca: som da abobora normal; Jack o'Lantern emite luz de fogo das almas (10)
	public static final Block WHITE_PUMPKIN = register("white_pumpkin", WhitePumpkinBlock::new, copyBlockProperties(Blocks.PUMPKIN), null);
	public static final Block CARVED_WHITE_PUMPKIN = register("carved_white_pumpkin", CarvedWhitePumpkinBlock::new, copyBlockProperties(Blocks.CARVED_PUMPKIN), ModItems::carvedPumpkinHeadProperties);
	public static final Block WHITE_JACK_O_LANTERN = register("white_jack_o_lantern", CarvedWhitePumpkinBlock::new, copyBlockProperties(Blocks.JACK_O_LANTERN).lightLevel(state -> 10), null);

	// Flores naturais novas (dao corante: botao-de-ouro=amarelo, margarida rosa=rosa, tulipa magenta=magenta)
	public static final Block BUTTERCUP = register("buttercup", p -> new FlowerBlock(MobEffects.SATURATION, 0.35F, p), BlockBehaviour.Properties.ofFullCopy(Blocks.DANDELION), null);
	public static final Block PINK_DAISY = register("pink_daisy", p -> new FlowerBlock(MobEffects.SATURATION, 0.35F, p), BlockBehaviour.Properties.ofFullCopy(Blocks.DANDELION), null);
	public static final Block MAGENTA_TULIP = register("magenta_tulip", p -> new FlowerBlock(MobEffects.SATURATION, 0.35F, p), BlockBehaviour.Properties.ofFullCopy(Blocks.DANDELION), null);

	// Caldeirão de água colorida: mantém níveis vanilla e armazena a última cor aplicada.
	// SEM BlockItem: ele nasce de um caldeirão vanilla + corante e, quebrado, solta o caldeirão vanilla (loot_table/blocks).
	public static final Block COLORED_WATER_CAULDRON = registerNoItem("colored_water_cauldron", ColoredWaterCauldronBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.WATER_CAULDRON));

	// Plantacao de cenoura dourada: so existe na natureza (cenoura normal madura pode virar dourada), sem item de bloco
	public static final Block GOLDEN_CARROTS = registerNoItem("golden_carrots", GoldenCarrotsBlock::new, BlockBehaviour.Properties.ofFullCopy(Blocks.CARROTS));

	// Blocos de slime coloridos: cada variante mantém a física vanilla do SlimeBlock.
	public static final Map<DyeColor, Block> COLORED_SLIME_BLOCKS = registerColoredSlimeBlocks();

	private static Map<DyeColor, Block> registerColoredSlimeBlocks() {
		Map<DyeColor, Block> blocks = new LinkedHashMap<>();
		for (DyeColor color : DyeColor.values()) {
			String name = color.getSerializedName() + "_slime_block";
			blocks.put(color, register(name, SlimeBlock::new,
					BlockBehaviour.Properties.ofFullCopy(Blocks.SLIME_BLOCK), null));
		}
		return blocks;
	}


	private ModBlocks() {}

	/** Registra so o bloco (sem BlockItem). */
	public static <T extends Block> T registerNoItem(String name, Function<BlockBehaviour.Properties, T> factory, BlockBehaviour.Properties properties) {
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, RandomStuffMod.id(name));
		return Registry.register(BuiltInRegistries.BLOCK, blockKey, factory.apply(properties.setId(blockKey)));
	}

	/** Registra o bloco e o item correspondente. itemCustomizer pode ser null. */
	public static <T extends Block> T register(String name, Function<BlockBehaviour.Properties, T> factory,
			BlockBehaviour.Properties properties, Function<Item.Properties, Item.Properties> itemCustomizer) {
		Identifier id = RandomStuffMod.id(name);
		ResourceKey<Block> blockKey = ResourceKey.create(Registries.BLOCK, id);
		T block = Registry.register(BuiltInRegistries.BLOCK, blockKey, factory.apply(properties.setId(blockKey)));

		ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, id);
		Item.Properties itemProps = new Item.Properties().setId(itemKey).useBlockDescriptionPrefix();
		if (itemCustomizer != null) {
			itemProps = itemCustomizer.apply(itemProps);
		}
		Item item = Registry.register(BuiltInRegistries.ITEM, itemKey, new BlockItem(block, itemProps));
		ALL.put(name, block);
		ALL_ITEMS.put(name, item);
		return block;
	}

	/**
	 * Copia integralmente as propriedades físicas do bloco de referência.
	 * ofFullCopy preserva tempo de quebra (mining speed/dureza), resistência,
	 * ferramenta correta para drops e demais propriedades; sound(...) deixa
	 * explícito que os sons vêm do bloco original.
	 */
	private static BlockBehaviour.Properties copyBlockProperties(Block base) {
		return BlockBehaviour.Properties.ofFullCopy(base)
				.sound(base.defaultBlockState().getSoundType());
	}

	/** Todas as lajes, escadas e paredes copiam som e propriedades de mineração do bloco-base. */
	public static void init() {
		for (VariantList.Entry entry : VariantList.ENTRIES) {
			Block base = BuiltInRegistries.BLOCK.getValue(Identifier.withDefaultNamespace(entry.baseBlock()));
			BlockBehaviour.Properties props = copyBlockProperties(base);
			switch (entry.kind()) {
				case SLAB -> register(entry.name(), SlabBlock::new, props, null);
				case STAIRS -> register(entry.name(), p -> new StairBlock(base.defaultBlockState(), p), props, null);
				case WALL -> register(entry.name(), WallBlock::new, props, null);
			}
		}
		RandomStuffMod.LOGGER.info("Random Stuff: {} blocos registrados.", ALL.size());
	}
}
