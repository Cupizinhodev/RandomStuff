package com.randomstuff.feature;

import net.minecraft.core.dispenser.DefaultDispenseItemBehavior;
import net.minecraft.core.dispenser.BlockSource;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.TridentItem;
import net.minecraft.world.item.ProjectileItem;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ProjectileItem.DispenseConfig;
import net.minecraft.world.entity.projectile.arrow.ThrownTrident;
import com.randomstuff.mixin.DispenserTridentAccess;

/** Faz o ejetor disparar tridentes usando a configuracao padrao de projeteis do Minecraft. */
public final class TridentDispenser {
    private TridentDispenser() {}

    public static void init() {
        DispenserBlock.registerBehavior(Items.TRIDENT, new DefaultDispenseItemBehavior() {
            @Override
            protected ItemStack execute(BlockSource source, ItemStack stack) {
                if (stack.isEmpty()) return stack;

                Direction direction = source.state().getValue(DispenserBlock.FACING);
                ProjectileItem item = (ProjectileItem) stack.getItem();
                DispenseConfig defaults = item.createDispenseConfig();
                DispenseConfig config = new DispenseConfig(defaults.positionFunction(), 1.0F,
                        TridentItem.PROJECTILE_SHOOT_POWER, defaults.overrideDispenseEvent());
                Projectile projectile = item.asProjectile(
                        source.level(),
                        config.positionFunction().getDispensePosition(source, direction),
                        stack,
                        direction
                );
                item.shoot(projectile, direction.getStepX(), direction.getStepY(), direction.getStepZ(),
                        config.power(), config.uncertainty());

                if (projectile instanceof ThrownTrident trident) {
                    trident.setBaseDamage(TridentItem.BASE_DAMAGE);
                    ((DispenserTridentAccess) trident).randomstuff$setDispenserPos(source.pos());
                }

                source.level().addFreshEntity(projectile);
                stack.shrink(1);
                return stack;
            }
        });
    }
}
