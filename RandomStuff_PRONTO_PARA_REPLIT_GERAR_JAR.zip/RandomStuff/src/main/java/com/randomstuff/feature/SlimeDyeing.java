package com.randomstuff.feature;

import com.randomstuff.entity.SlimeColorAccess;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.monster.cubemob.Slime;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.DyeColor;

/** Tingimento persistente/sincronizado do Slime. Magma Cubes nao sao Slime e nunca aceitam corante. */
public final class SlimeDyeing {
    private SlimeDyeing() {}

    public static void init() {
        UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
            ItemStack held = player.getItemInHand(hand);
            DyeColor color = DyeColorItems.getColor(held);
            if (!(entity instanceof Slime slime) || color == null || player.isSpectator()) {
                return InteractionResult.PASS;
            }
            if (level.isClientSide) return InteractionResult.SUCCESS;

            int colorId = color.getId();
            SlimeColorAccess access = (SlimeColorAccess) slime;
            if (access.randomstuff$getColor() == colorId) return InteractionResult.CONSUME;
            access.randomstuff$setColor(colorId);
            if (!player.getAbilities().instabuild) held.shrink(1);
            level.playSound(null, slime.blockPosition(), SoundEvents.DYE_USE, SoundSource.NEUTRAL, 1.0F, 1.0F);
            return InteractionResult.SUCCESS;
        });
    }
}
