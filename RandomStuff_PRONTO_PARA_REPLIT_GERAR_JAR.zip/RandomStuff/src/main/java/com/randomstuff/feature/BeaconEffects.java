package com.randomstuff.feature;

import com.randomstuff.RandomStuffMod;
import com.randomstuff.effect.BeaconMarkerEffect;
import net.minecraft.core.Holder;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.effect.MobEffect;

/** Registro dos dois efeitos selecionaveis no Beacon. */
public final class BeaconEffects {
    public static Holder<MobEffect> GLOWING;
    public static Holder<MobEffect> BREATHING;

    private BeaconEffects() {}

    public static void init() {
        if (GLOWING == null) {
            GLOWING = Registry.registerForHolder(
                    BuiltInRegistries.MOB_EFFECT,
                    RandomStuffMod.id("beacon_glowing"),
                    new BeaconMarkerEffect(0xE7E7E7)
            );
        }
        if (BREATHING == null) {
            BREATHING = Registry.registerForHolder(
                    BuiltInRegistries.MOB_EFFECT,
                    RandomStuffMod.id("beacon_breathing"),
                    new BeaconMarkerEffect(0x3C9EDB)
            );
        }
    }
}
