package com.randomstuff.feature;

import com.randomstuff.item.CapturedSlimeBucketItem;
import com.randomstuff.registry.ModItems;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.monster.cubemob.AbstractCubeMob;
import net.minecraft.world.entity.monster.cubemob.MagmaCube;
import net.minecraft.world.entity.monster.cubemob.Slime;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.ItemUtils;
import net.minecraft.world.item.Items;

/** Captura atomica de Slimes e Cubos de Magma com balde vazio. */
public final class BucketCapture {
    private BucketCapture() {}

    public static void init() {
        UseEntityCallback.EVENT.register((player, level, hand, entity, hitResult) -> {
            ItemStack held = player.getItemInHand(hand);
            if (!held.is(Items.BUCKET) || player.isSpectator()
                    || !(entity instanceof AbstractCubeMob cube)
                    || (!(cube instanceof Slime) && !(cube instanceof MagmaCube)) || !cube.isAlive()) {
                return InteractionResult.PASS;
            }
            if (!(level instanceof ServerLevel serverLevel)) return InteractionResult.SUCCESS;

            ItemStack filled = new ItemStack(cube instanceof MagmaCube
                    ? ModItems.MAGMA_CUBE_BUCKET : ModItems.SLIME_BUCKET);
            CapturedSlimeBucketItem.storeMob(filled, cube);

            // Cria/entrega o balde cheio antes de remover a entidade. ItemUtils trata
            // mao, inventario e drop no chao quando o inventario esta cheio.
            ItemStack result = ItemUtils.createFilledResult(held, player, filled);
            player.setItemInHand(hand, result);
            serverLevel.playSound(null, cube.blockPosition(), SoundEvents.BUCKET_FILL_FISH,
                    SoundSource.NEUTRAL, 1.0F, 1.0F);
            cube.discard();
            return InteractionResult.SUCCESS;
        });
    }
}
