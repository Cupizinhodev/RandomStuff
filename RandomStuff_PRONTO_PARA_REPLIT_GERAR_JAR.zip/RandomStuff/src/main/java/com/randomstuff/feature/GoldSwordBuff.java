package com.randomstuff.feature;

import net.fabricmc.fabric.api.item.v1.DefaultItemComponentEvents;
import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.ItemAttributeModifiers;

/** Espada de ouro: mesmo dano da espada de Netherite (3 + 4), durabilidade do ouro inalterada. */
public final class GoldSwordBuff {
	private GoldSwordBuff() {}

	public static void init() {
		DefaultItemComponentEvents.MODIFY.register(context ->
				context.modify(Items.GOLDEN_SWORD, builder -> builder.set(DataComponents.ATTRIBUTE_MODIFIERS,
						ItemAttributeModifiers.builder()
								.add(Attributes.ATTACK_DAMAGE,
										new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 7.0, AttributeModifier.Operation.ADD_VALUE),
										EquipmentSlotGroup.MAINHAND)
								.add(Attributes.ATTACK_SPEED,
										new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -2.4, AttributeModifier.Operation.ADD_VALUE),
										EquipmentSlotGroup.MAINHAND)
								.build())));
	}
}
