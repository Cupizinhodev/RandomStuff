package com.randomstuff.feature;

import net.fabricmc.fabric.api.object.builder.v1.trade.TradeOfferHelper;
import net.minecraft.resources.Identifier;
import net.minecraft.world.entity.npc.villager.VillagerTrades;
import net.minecraft.world.item.Items;

/**
 * Mercador Ambulante. VENDE (itens por esmeraldas) e COMPRA (esmeraldas por itens), conforme o briefing.
 * Escamas de tartaruga NAO sao compradas. ItemsForEmeralds(item, esmeraldas, quantidade, usosMax, xp).
 * "folhas" = folha de carvalho e "flores" = dente-de-leao (o briefing nao especifica o tipo).
 */
public final class WanderingTraderTrades {
	private static final Identifier SELL_POOL = Identifier.withDefaultNamespace("sell_special_items");
	private static final Identifier BUY_POOL = Identifier.withDefaultNamespace("buy_items");
	private static final int USES = 8;
	private static final int XP = 1;

	private WanderingTraderTrades() {}

	private static VillagerTrades.ItemListing sell(net.minecraft.world.level.ItemLike item, int count, int emeralds) {
		return new VillagerTrades.ItemsForEmeralds(item, emeralds, count, USES, XP);
	}

	private static VillagerTrades.ItemListing buy(net.minecraft.world.level.ItemLike item, int count) {
		return new VillagerTrades.EmeraldForItems(item, count, USES, XP);
	}

	public static void init() {
		TradeOfferHelper.registerWanderingTraderOffers(builder -> {
			builder.addOffersToPool(SELL_POOL,
					sell(Items.BAMBOO, 8, 2), sell(Items.PUMPKIN_SEEDS, 4, 1), sell(Items.GOLDEN_CARROT, 1, 5),
					sell(Items.CHERRY_SAPLING, 1, 2), sell(Items.MOSS_BLOCK, 4, 1), sell(Items.SLIME_BALL, 4, 3),
					sell(Items.NAME_TAG, 1, 6), sell(Items.SPONGE, 1, 8), sell(Items.NAUTILUS_SHELL, 1, 4),
					sell(Items.PHANTOM_MEMBRANE, 2, 3), sell(Items.HONEYCOMB, 4, 2), sell(Items.GLOW_BERRIES, 4, 2),
					sell(Items.PITCHER_PLANT, 1, 3), sell(Items.PINK_PETALS, 4, 2), sell(Items.SPORE_BLOSSOM, 1, 4),
					sell(Items.POINTED_DRIPSTONE, 4, 1), sell(Items.TUBE_CORAL_FAN, 1, 2), sell(Items.ECHO_SHARD, 1, 8),
					sell(Items.BREEZE_ROD, 1, 5), sell(Items.SEA_PICKLE, 4, 2), sell(Items.LILY_PAD, 2, 1),
					sell(Items.LARGE_FERN, 1, 2), sell(Items.DEAD_BUSH, 2, 1), sell(Items.COCOA_BEANS, 4, 2));
			builder.addOffersToPool(BUY_POOL,
					buy(Items.PUMPKIN, 8), buy(Items.SNOWBALL, 4), buy(Items.RED_MUSHROOM, 4), buy(Items.BROWN_MUSHROOM, 4),
					buy(Items.OAK_LEAVES, 8), buy(Items.DANDELION, 4), buy(Items.CACTUS, 4));
		});
	}
}
