package com.randomstuff.feature;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.enchantment.EnchantmentHelper;
import net.minecraft.world.item.enchantment.Enchantments;

/** Queda de Penas tambem protege ovos de tartaruga e plantacoes (farmland) de serem pisoteados. */
public final class FeatherFalling {
	private FeatherFalling() {}

	public static boolean has(Entity entity) {
		if (!(entity instanceof LivingEntity living)) return false;
		var enchantments = entity.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		return EnchantmentHelper.getEnchantmentLevel(enchantments.getOrThrow(Enchantments.FEATHER_FALLING), living) > 0;
	}
}
