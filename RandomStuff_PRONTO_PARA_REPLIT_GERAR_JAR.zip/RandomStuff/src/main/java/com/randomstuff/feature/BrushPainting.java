package com.randomstuff.feature;

import com.randomstuff.item.ColoredBrushItem;
import java.util.Map;
import java.util.Set;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.Property;

/**
 * Pincel colorido pinta blocos que existem em varias cores (la, tapete, terracota, vidro, concreto, pó de concreto,
 * terracota vidrada, vela e os muros de terracota/concreto do mod). Blocos com dados internos (cama, shulker, estandarte)
 * NAO sao pintados. Cada bloco gasta 1 de tinta; com a tinta no zero o pincel volta a ser um pincel comum.
 */
public final class BrushPainting {
	private static final String[] COLORS = {"light_blue", "light_gray", "white", "orange", "magenta", "yellow", "lime",
			"pink", "gray", "cyan", "purple", "blue", "brown", "green", "red", "black"};
	private static final Set<String> SUFFIXES = Set.of("wool", "carpet", "terracotta", "concrete", "concrete_powder",
			"stained_glass", "stained_glass_pane", "glazed_terracotta", "candle", "concrete_wall", "terracotta_wall", "slime_block");
	/** Blocos sem cor que viram a versao colorida. */
	private static final Map<String, String> UNCOLORED = Map.of("terracotta", "terracotta", "glass", "stained_glass",
			"glass_pane", "stained_glass_pane", "candle", "candle", "terracotta_wall", "terracotta_wall", "slime_block", "slime_block");

	private BrushPainting() {}

	private static <T extends Comparable<T>> BlockState copyProperty(BlockState from, BlockState to, Property<T> property) {
		return to.hasProperty(property) ? to.setValue(property, from.getValue(property)) : to;
	}

	/** Retorna o estado na nova cor, ou null se o bloco nao e pintavel (ou ja tem essa cor). */
	static BlockState recolor(BlockState state, DyeColor color) {
		Identifier id = BuiltInRegistries.BLOCK.getKey(state.getBlock());
		String path = id.getPath();
		String rest = null;
		for (String c : COLORS) {
			if (path.startsWith(c + "_") && SUFFIXES.contains(path.substring(c.length() + 1))) {
				rest = path.substring(c.length() + 1);
				break;
			}
		}
		if (rest == null && UNCOLORED.containsKey(path)) {
			rest = UNCOLORED.get(path);
		}
		if (rest == null) {
			return null;
		}
		String targetNamespace = id.getNamespace();
		// O bloco base e vanilla, mas as variantes coloridas pertencem ao namespace do mod.
		if ("minecraft".equals(targetNamespace) && "slime_block".equals(path)) {
			targetNamespace = "randomstuff";
		}
		Identifier target = Identifier.fromNamespaceAndPath(targetNamespace, color.getSerializedName() + "_" + rest);
		if (!BuiltInRegistries.BLOCK.containsKey(target)) {
			return null;
		}
		Block block = BuiltInRegistries.BLOCK.getValue(target);
		if (block == state.getBlock()) {
			return null;
		}
		BlockState result = block.defaultBlockState();
		for (Property<?> property : state.getProperties()) {
			result = copyProperty(state, result, property);
		}
		return result;
	}

	public static void init() {
		UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
			ItemStack stack = player.getItemInHand(hand);
			if (!(stack.getItem() instanceof ColoredBrushItem brush) || player.isSpectator()) {
				return InteractionResult.PASS;
			}
			BlockPos pos = hit.getBlockPos();
			BlockState state = level.getBlockState(pos);
			BlockState painted = recolor(state, brush.getColor());
			if (painted == null) {
				return InteractionResult.PASS; // deixa o pincel funcionar normalmente (areia suspeita etc.)
			}
			if (level instanceof ServerLevel serverLevel) {
				serverLevel.setBlock(pos, painted, Block.UPDATE_ALL);
				serverLevel.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
				if (!player.getAbilities().instabuild) {
					int paint = ColoredBrushItem.getPaint(stack) - 1;
					if (paint <= 0) {
						ItemStack plain = new ItemStack(Items.BRUSH);
						plain.setDamageValue(stack.getDamageValue());
						player.setItemInHand(hand, plain);
					} else {
						ColoredBrushItem.setPaint(stack, paint);
					}
				}
			}
			return InteractionResult.SUCCESS;
		});
	}
}
