package com.randomstuff.feature;

import com.randomstuff.RandomStuffMod;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;
import net.fabricmc.fabric.api.entity.event.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.core.UUIDUtil;
import com.mojang.math.Transformation;
import net.minecraft.world.entity.Display.BlockDisplay;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.level.block.Blocks;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.vehicle.minecart.AbstractMinecart;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Correntes de carrinho (implementacao propria, sem codigo de terceiros).
 * - Agachar + usar corrente em dois carrinhos conecta; repetir nos mesmos dois desconecta. Maximo 8 por composicao.
 * - Espacamento fixo: o seguidor acompanha a velocidade do lider e corrige a distancia para GAP.
 * - Aceleracao progressiva: o jogador no carrinho da frente acelera ao andar (frente) e freia (tras).
 * - Barra de aceleracao na action bar. Persistencia via data attachment do Fabric.
 * A corrente e representada por BlockDisplays sincronizados pelo servidor, usando o modelo vanilla de corrente.
 * A validacao de novas ligacoes tambem impede fechar um ciclo dentro da mesma composicao.
 */
public final class MinecartChains {
	public static final int MAX_CARTS = 8;
	private static final double GAP = 1.7;
	private static final double ACCEL_PER_TICK = 0.006;
	private static final double BRAKE_FACTOR = 0.90;

	public static final AttachmentType<UUID> LEADER = AttachmentRegistry.create(RandomStuffMod.id("chain_leader"),
			builder -> builder.persistent(UUIDUtil.CODEC));

	/** seguidor -> lider (somente carrinhos carregados). */
	private static final Map<UUID, UUID> LEADER_OF = new HashMap<>();
	private static final Map<UUID, UUID> PENDING = new HashMap<>();
	private static final Map<UUID, Double> ACCEL = new HashMap<>();
	/** UUID do display fisico associado a cada carrinho seguidor. */
	private static final Map<UUID, List<UUID>> CHAIN_VISUALS = new HashMap<>();
	private static final int VISUAL_SEGMENTS = 3;

	private MinecartChains() {}

	public static void init() {
		UseEntityCallback.EVENT.register((player, level, hand, entity, hit) -> {
			if (!(entity instanceof AbstractMinecart cart) || !player.isShiftKeyDown()) return InteractionResult.PASS;
			ItemStack held = player.getItemInHand(hand);
			if (!isChain(held)) return InteractionResult.PASS;
			if (level.isClientSide() || !(player instanceof ServerPlayer sp)) return InteractionResult.SUCCESS;
			handleUse(sp, cart);
			return InteractionResult.SUCCESS;
		});
		ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
			if (entity instanceof AbstractMinecart) {
				UUID leader = entity.getAttached(LEADER);
				if (leader != null) LEADER_OF.put(entity.getUUID(), leader);
			}
		});
		ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
			if (entity instanceof AbstractMinecart) {
				UUID unloadedId = entity.getUUID();
				removeChainVisual(world, unloadedId);
				LEADER_OF.remove(unloadedId);
				ACCEL.remove(unloadedId);
				PENDING.values().removeIf(unloadedId::equals);
				if (entity.isRemoved() && entity.getRemovalReason() != null && entity.getRemovalReason().shouldDestroy()) {
					List<UUID> followers = LEADER_OF.entrySet().stream()
							.filter(entry -> entry.getValue().equals(unloadedId))
							.map(Map.Entry::getKey).toList();
					for (UUID followerId : followers) {
						removeChainVisual(world, followerId);
						Entity followerEntity = world.getEntity(followerId);
						if (followerEntity instanceof AbstractMinecart follower) follower.removeAttached(LEADER);
					}
					unlinkAll(unloadedId);
				}
			}
		});
		ServerTickEvents.END_WORLD_TICK.register(MinecartChains::tick);
	}

	private static boolean isChain(ItemStack stack) {
		var key = BuiltInRegistries.ITEM.getKey(stack.getItem());
		return key.getNamespace().equals("minecraft") && key.getPath().endsWith("chain");
	}

	// ---- Conexao ----

	private static void handleUse(ServerPlayer player, AbstractMinecart cart) {
		UUID first = PENDING.get(player.getUUID());
		if (first == null || first.equals(cart.getUUID())) {
			PENDING.put(player.getUUID(), cart.getUUID());
			player.displayClientMessage(Component.translatable("message.randomstuff.chain_select"), true);
			return;
		}
		PENDING.remove(player.getUUID());
		Entity other = ((ServerLevel) cart.level()).getEntity(first);
		if (!(other instanceof AbstractMinecart a)) return;
		// Ja ligados (em qualquer direcao)? Desconecta.
		if (first.equals(LEADER_OF.get(cart.getUUID()))) {
			unlink(cart);
			player.displayClientMessage(Component.translatable("message.randomstuff.chain_unlinked"), true);
			return;
		}
		if (cart.getUUID().equals(LEADER_OF.get(first))) {
			unlink(a);
			player.displayClientMessage(Component.translatable("message.randomstuff.chain_unlinked"), true);
			return;
		}
		// Novo vinculo: a (primeiro clique) e o lider, cart (segundo clique) e o seguidor.
		// A conexao deve unir a ponta de uma composicao a raiz de outra.
		// Sem esta verificacao, ligar a ponta de um trem de volta a sua raiz criaria um ciclo.
		if (LEADER_OF.containsKey(cart.getUUID()) || followerOf(a.getUUID()) != null
				|| sameComposition(a.getUUID(), cart.getUUID()) || a.distanceTo(cart) > 6.0F
				|| compositionSize(a.getUUID()) + compositionSize(cart.getUUID()) > MAX_CARTS) {
			player.displayClientMessage(Component.translatable("message.randomstuff.chain_fail"), true);
			return;
		}
		cart.setAttached(LEADER, a.getUUID());
		LEADER_OF.put(cart.getUUID(), a.getUUID());
		player.displayClientMessage(Component.translatable("message.randomstuff.chain_linked"), true);
	}

	private static void unlink(AbstractMinecart follower) {
		follower.removeAttached(LEADER);
		LEADER_OF.remove(follower.getUUID());
	}

	private static void unlinkAll(UUID dead) {
		LEADER_OF.remove(dead);
		LEADER_OF.values().removeIf(dead::equals);
	}

	private static UUID followerOf(UUID leader) {
		for (Map.Entry<UUID, UUID> e : LEADER_OF.entrySet()) if (e.getValue().equals(leader)) return e.getKey();
		return null;
	}

	/** Percorre os vinculos nos dois sentidos; o conjunto visitado evita loops em dados inconsistentes. */
	private static Set<UUID> compositionOf(UUID start) {
		Set<UUID> visited = new HashSet<>();
		List<UUID> pending = new ArrayList<>();
		pending.add(start);
		for (int i = 0; i < pending.size(); i++) {
			UUID current = pending.get(i);
			if (!visited.add(current)) continue;
			UUID leader = LEADER_OF.get(current);
			if (leader != null && !visited.contains(leader)) pending.add(leader);
			for (Map.Entry<UUID, UUID> link : LEADER_OF.entrySet()) {
				if (link.getValue().equals(current) && !visited.contains(link.getKey())) pending.add(link.getKey());
			}
		}
		return visited;
	}

	private static boolean sameComposition(UUID first, UUID second) {
		Set<UUID> firstTrain = compositionOf(first);
		for (UUID cart : compositionOf(second)) if (firstTrain.contains(cart)) return true;
		return false;
	}

	private static int compositionSize(UUID any) {
		// Usa a mesma travessia protegida contra ciclos empregada na validação de vínculo.
		// Isso evita contagens divergentes caso dados antigos estejam inconsistentes.
		return compositionOf(any).size();
	}

	// ---- Fisica ----

	private static void tick(ServerLevel level) {
		// 1) aceleracao do carrinho da frente (sem lider) com jogador dentro
		for (ServerPlayer player : level.players()) {
			if (!(player.getVehicle() instanceof AbstractMinecart cart) || LEADER_OF.containsKey(cart.getUUID())) continue;
			var input = player.getLastClientInput();
			double level01 = ACCEL.getOrDefault(cart.getUUID(), 0.0);
			Vec3 v = cart.getDeltaMovement();
			if (input.forward() && !input.backward()) {
				level01 = Math.min(1.0, level01 + ACCEL_PER_TICK * 4);
				Vec3 dir = v.horizontalDistanceSqr() > 1.0E-4 ? v.normalize() : player.getLookAngle().multiply(1, 0, 1).normalize();
				cart.setDeltaMovement(v.add(dir.scale(ACCEL_PER_TICK)));
			} else if (input.backward()) {
				level01 = Math.max(0.0, level01 - 0.05);
				cart.setDeltaMovement(v.scale(BRAKE_FACTOR));
			}
			ACCEL.put(cart.getUUID(), level01);
			if (level.getGameTime() % 4 == 0) player.displayClientMessage(bar(level01), true);
		}

		// 2) seguidores e suas correntes visuais. BlockDisplay e uma entidade vanilla
		// sincronizada pelo servidor: todos os clientes recebem posicao, orientacao e escala.
		Set<UUID> activeVisuals = new HashSet<>();
		List<Map.Entry<UUID, UUID>> links = new ArrayList<>(LEADER_OF.entrySet());
		for (Map.Entry<UUID, UUID> link : links) {
			Entity f = level.getEntity(link.getKey());
			Entity l = level.getEntity(link.getValue());
			if (!(f instanceof AbstractMinecart follower)) continue;
			if (l == null) continue; // lider descarregado: a conexao persistida espera seu retorno
			if (l.isRemoved()) {
				unlink(follower);
				continue;
			}
			Vec3 delta = l.position().subtract(follower.position());
			double dist = delta.length();
			if (dist < 1.0E-4) continue;
			double correction = (dist - GAP) * 0.45;
			Vec3 vel = l.getDeltaMovement().add(delta.scale(correction / dist));
			double max = Math.max(l.getDeltaMovement().length() + 0.35, 0.1);
			if (vel.length() > max) vel = vel.normalize().scale(max);
			follower.setDeltaMovement(vel);
			activeVisuals.add(follower.getUUID());
			Vec3 linkDirection = delta.normalize();
			Vec3 chainStart = follower.position().add(linkDirection.scale(0.48)).add(0, 0.35, 0);
			Vec3 chainEnd = l.position().subtract(linkDirection.scale(0.48)).add(0, 0.35, 0);
			updateChainVisual(level, follower.getUUID(), chainStart, chainEnd);
		}

		// Remove imediatamente os visuais de ligacoes desfeitas, carrinhos removidos
		// ou pares que deixaram de estar carregados neste mundo.
		for (UUID followerId : new ArrayList<>(CHAIN_VISUALS.keySet())) {
			// Nao limpe entradas pertencentes a outro ServerLevel: os UUIDs sao globais
			// ao servidor, enquanto cada END_WORLD_TICK enxerga apenas um mundo.
			if (level.getEntity(followerId) != null && !activeVisuals.contains(followerId)) {
				removeChainVisual(level, followerId);
			}
		}
	}

	private static void updateChainVisual(ServerLevel level, UUID followerId, Vec3 start, Vec3 end) {
		List<UUID> ids = CHAIN_VISUALS.get(followerId);
		if (ids == null) {
			// Tags persistem no NBT dos displays. Isso permite recuperar os mesmos visuais
			// apos reinicio do servidor, em vez de criar correntes duplicadas.
			String ownerTag = visualTag(followerId);
			AABB search = new AABB(start, end).inflate(1.0);
			List<BlockDisplay> recovered = level.getEntitiesOfClass(BlockDisplay.class, search,
					display -> display.entityTags().contains(ownerTag));
			if (recovered.size() == VISUAL_SEGMENTS) {
				ids = recovered.stream().map(Entity::getUUID).toList();
				CHAIN_VISUALS.put(followerId, ids);
			} else {
				for (BlockDisplay display : recovered) display.discard();
			}
		}
		if (ids != null && ids.stream().anyMatch(id -> !(level.getEntity(id) instanceof BlockDisplay))) {
			removeChainVisual(level, followerId);
			ids = null;
		}
		if (ids == null || ids.size() != VISUAL_SEGMENTS) {
			removeChainVisual(level, followerId);
			ids = new ArrayList<>(VISUAL_SEGMENTS);
			for (int i = 0; i < VISUAL_SEGMENTS; i++) {
				BlockDisplay display = new BlockDisplay(EntityTypes.BLOCK_DISPLAY, level);
				display.setBlockState(Blocks.CHAIN.defaultBlockState());
				display.setNoGravity(true);
				display.setInvulnerable(true);
				display.setSilent(true);
				display.setViewRange(2.0F);
				display.setPosRotInterpolationDuration(2);
				display.setTransformationInterpolationDuration(2);
				display.addTag(visualTag(followerId));
				if (level.addFreshEntity(display)) ids.add(display.getUUID());
			}
			if (ids.size() != VISUAL_SEGMENTS) {
				for (UUID id : ids) {
					Entity entity = level.getEntity(id);
					if (entity != null) entity.discard();
				}
				return;
			}
			CHAIN_VISUALS.put(followerId, ids);
		}

		// Curva suavemente suspensa entre os engates. Tres segmentos curtos evitam
		// o efeito de uma barra reta e acompanham subidas, descidas e curvas.
		Vec3 delta = end.subtract(start);
		double sag = Math.min(0.18, delta.length() * 0.08);
		for (int i = 0; i < VISUAL_SEGMENTS; i++) {
			double t0 = (double) i / VISUAL_SEGMENTS;
			double t1 = (double) (i + 1) / VISUAL_SEGMENTS;
			Vec3 a = chainCurvePoint(start, delta, sag, t0);
			Vec3 b = chainCurvePoint(start, delta, sag, t1);
			Vec3 segment = b.subtract(a);
			double length = segment.length();
			if (length < 1.0E-4) continue;
			Entity entity = level.getEntity(ids.get(i));
			if (!(entity instanceof BlockDisplay display)) continue;
			Vec3 middle = a.add(b).scale(0.5);
			Vec3 direction = segment.scale(1.0 / length);
			Quaternionf rotation = new Quaternionf().rotationTo(0.0F, 1.0F, 0.0F,
					(float) direction.x, (float) direction.y, (float) direction.z);
			display.setPos(middle.x, middle.y, middle.z);
			display.setTransformation(new Transformation(new Vector3f(), rotation,
					new Vector3f(0.72F, (float) length, 0.72F), new Quaternionf()));
		}
	}

	private static String visualTag(UUID followerId) {
		return "randomstuff_chain_" + followerId;
	}

	private static Vec3 chainCurvePoint(Vec3 start, Vec3 delta, double sag, double t) {
		return start.add(delta.scale(t)).add(0.0, -4.0 * sag * t * (1.0 - t), 0.0);
	}

	private static void removeChainVisual(ServerLevel level, UUID followerId) {
		List<UUID> ids = CHAIN_VISUALS.remove(followerId);
		if (ids == null) return;
		for (UUID id : ids) {
			Entity entity = level.getEntity(id);
			if (entity != null) entity.discard();
		}
	}

	private static Component bar(double level01) {
		int filled = (int) Math.round(level01 * 10);
		return Component.literal("\u25AE".repeat(filled) + "\u25AF".repeat(10 - filled));
	}
}
