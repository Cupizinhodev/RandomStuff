package com.randomstuff.feature;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/**
 * Cabecas de mobs: quem usa a cabeca de uma especie nao e escolhido como alvo por mobs DAQUELA mesma especie.
 * O Dragao do End fica de fora de proposito (briefing). A logica de "nao atacar" fica em mixin/MobTargetMixin.
 * Os filtros visuais sao selecionados no cliente por RandomStuffClient; ainda precisam de teste em jogo.
 */
public final class MobHeads {
	private MobHeads() {}

	public static boolean protects(Mob mob, ItemStack head) {
		if (head.isEmpty()) {
			return false;
		}
		EntityType<?> type = mob.getType();
		return (type == EntityTypes.ZOMBIE && head.is(Items.ZOMBIE_HEAD))
				|| (type == EntityTypes.SKELETON && head.is(Items.SKELETON_SKULL))
				|| (type == EntityTypes.CREEPER && head.is(Items.CREEPER_HEAD))
				|| (type == EntityTypes.PIGLIN && head.is(Items.PIGLIN_HEAD))
				|| (type == EntityTypes.WITHER_SKELETON && head.is(Items.WITHER_SKELETON_SKULL));
	}
}
