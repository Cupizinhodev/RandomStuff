package com.randomstuff.feature;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/** Permite tingir o Slime Block vanilla e repintar blocos de slime coloridos com corante direto. */
public final class SlimeBlockDyeing {
    private SlimeBlockDyeing() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack held = player.getItemInHand(hand);
            net.minecraft.world.item.DyeColor color = DyeColorItems.getColor(held);
            if (color == null || player.isSpectator()) return InteractionResult.PASS;
            BlockState current = level.getBlockState(hit.getBlockPos());
            BlockState painted = BrushPainting.recolor(current, color);
            if (painted == null) return InteractionResult.PASS;
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.setBlock(hit.getBlockPos(), painted, Block.UPDATE_ALL);
                serverLevel.playSound(null, hit.getBlockPos(), SoundEvents.DYE_USE,
                        SoundSource.BLOCKS, 1.0F, 1.0F);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.SUCCESS;
        });
    }
}
