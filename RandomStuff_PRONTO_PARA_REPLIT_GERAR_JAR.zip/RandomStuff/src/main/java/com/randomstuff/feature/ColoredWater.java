package com.randomstuff.feature;

import com.randomstuff.block.ColoredWaterCauldronBlock;
import com.randomstuff.item.ColoredBrushItem;
import com.randomstuff.registry.ModBlocks;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.LayeredCauldronBlock;
import net.minecraft.world.level.block.state.BlockState;

/** Conversão de caldeirões vanilla e recarga de pincéis usando água da mesma cor. */
public final class ColoredWater {
    private ColoredWater() {}

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            if (player.isSpectator()) return InteractionResult.PASS;
            BlockPos pos = hit.getBlockPos();
            BlockState state = level.getBlockState(pos);
            ItemStack held = player.getItemInHand(hand);

            // Corante em um caldeirão de água vanilla: cria o caldeirão colorido sem perder o nível.
            DyeColor dyeColor = DyeColorItems.getColor(held);
            if (state.is(Blocks.WATER_CAULDRON) && dyeColor != null) {
                if (!level.isClientSide()) {
                    int fill = state.getValue(LayeredCauldronBlock.LEVEL);
                    BlockState colored = ModBlocks.COLORED_WATER_CAULDRON.defaultBlockState()
                            .setValue(LayeredCauldronBlock.LEVEL, fill)
                            .setValue(ColoredWaterCauldronBlock.COLOR, dyeColor);
                    level.setBlock(pos, colored, 3);
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    level.playSound(null, pos, SoundEvents.DYE_USE, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.SUCCESS;
            }

            // Água normal lava a tinta do pincel e devolve um pincel comum,
            // preservando a durabilidade da ferramenta de escavação.
            if (state.is(Blocks.WATER_CAULDRON) && held.getItem() instanceof ColoredBrushItem) {
                if (!level.isClientSide()) {
                    ItemStack plainBrush = new ItemStack(net.minecraft.world.item.Items.BRUSH);
                    plainBrush.setDamageValue(held.getDamageValue());
                    player.setItemInHand(hand, plainBrush);
                    LayeredCauldronBlock.lowerFillLevel(state, level, pos);
                    level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.SUCCESS;
            }

            // Água colorida restaura a tinta apenas no pincel da mesma cor e consome um nível.
            if (state.getBlock() instanceof ColoredWaterCauldronBlock cauldron
                    && held.getItem() instanceof ColoredBrushItem brush
                    && brush.getColor() == state.getValue(ColoredWaterCauldronBlock.COLOR)
                    && state.getValue(LayeredCauldronBlock.LEVEL) > 0
                    && ColoredBrushItem.getPaint(held) < ColoredBrushItem.MAX_PAINT) {
                if (!level.isClientSide()) {
                    ColoredBrushItem.setPaint(held, ColoredBrushItem.MAX_PAINT);
                    LayeredCauldronBlock.lowerFillLevel(state, level, pos);
                    level.playSound(null, pos, SoundEvents.BOTTLE_FILL, SoundSource.BLOCKS, 1.0F, 1.0F);
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        });
    }
}
