package com.randomstuff.feature;

import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.enchantment.EnchantmentHelper;

/** Verifica o encantamento Resistência à Lava em qualquer peça de armadura equipada. */
public final class LavaResistance {
	private LavaResistance() {}

	public static boolean protects(LivingEntity entity) {
		var enchantments = entity.level().registryAccess().lookupOrThrow(Registries.ENCHANTMENT);
		var resistance = enchantments.get(net.minecraft.resources.Identifier.fromNamespaceAndPath("randomstuff", "lava_resistance"));
		if (resistance.isEmpty()) return false;
		for (ItemStack armor : entity.getArmorSlots()) {
			if (!armor.isEmpty() && EnchantmentHelper.getItemEnchantmentLevel(resistance.get(), armor) > 0) return true;
		}
		return false;
	}
}
