package com.randomstuff.feature;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.StainedGlassPaneBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BooleanProperty;

/** Estado persistente que marca painéis de vidro colocados enquanto o jogador agacha. */
public final class PaneSeparation {
    public static final BooleanProperty SEPARATED = BooleanProperty.create("separated");

    private PaneSeparation() {
    }

    /** Inclui o vidro transparente e todas as cores de painéis de vidro vanilla. */
    public static boolean isGlassPane(BlockState state) {
        return state.is(Blocks.GLASS_PANE) || state.getBlock() instanceof StainedGlassPaneBlock;
    }
}
