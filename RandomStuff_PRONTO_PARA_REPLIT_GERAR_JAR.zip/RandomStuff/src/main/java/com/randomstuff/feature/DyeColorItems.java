package com.randomstuff.feature;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;

/** Minecraft 26.3 DyeItem nao expoe mais uma cor; resolve a cor pelo ID vanilla *_dye. */
public final class DyeColorItems {
    private DyeColorItems() {}

    public static DyeColor getColor(ItemStack stack) {
        Identifier id = BuiltInRegistries.ITEM.getKey(stack.getItem());
        if (id == null || !"minecraft".equals(id.getNamespace()) || !id.getPath().endsWith("_dye")) {
            return null;
        }
        String name = id.getPath().substring(0, id.getPath().length() - "_dye".length());
        for (DyeColor color : DyeColor.values()) {
            if (color.getSerializedName().equals(name)) return color;
        }
        return null;
    }
}
