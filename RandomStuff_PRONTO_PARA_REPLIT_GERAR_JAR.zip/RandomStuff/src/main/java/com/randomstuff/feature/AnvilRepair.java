package com.randomstuff.feature;

import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.AnvilBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;

/** Bigornas sao reparadas com blocos de ferro: danificada -> rachada -> normal (um bloco por estagio). */
public final class AnvilRepair {
	private AnvilRepair() {}

	public static void init() {
		UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
			ItemStack stack = player.getItemInHand(hand);
			if (!stack.is(Items.IRON_BLOCK) || player.isSpectator()) {
				return InteractionResult.PASS;
			}
			BlockPos pos = hit.getBlockPos();
			BlockState state = level.getBlockState(pos);
			Block repaired = state.is(Blocks.DAMAGED_ANVIL) ? Blocks.CHIPPED_ANVIL
					: state.is(Blocks.CHIPPED_ANVIL) ? Blocks.ANVIL : null;
			if (repaired == null) {
				return InteractionResult.PASS;
			}
			if (level instanceof ServerLevel serverLevel) {
				serverLevel.setBlock(pos, repaired.defaultBlockState().setValue(AnvilBlock.FACING, state.getValue(AnvilBlock.FACING)), Block.UPDATE_ALL);
				serverLevel.playSound(null, pos, SoundEvents.ANVIL_PLACE, SoundSource.BLOCKS, 1.0F, 1.2F);
				if (!player.getAbilities().instabuild) {
					stack.shrink(1);
				}
			}
			return InteractionResult.SUCCESS;
		});
	}
}
