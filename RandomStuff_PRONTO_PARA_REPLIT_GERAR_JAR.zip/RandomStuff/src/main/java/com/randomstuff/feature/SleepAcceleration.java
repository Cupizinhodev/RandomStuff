package com.randomstuff.feature;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.level.block.entity.AbstractFurnaceBlockEntity;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.LevelChunk;
import net.minecraft.world.phys.AABB;

/**
 * Dormir acelera plantas/mudas, filhotes e fornalhas nas proximidades dos jogadores dormindo.
 * Cada bloco/animal e processado no maximo uma vez por tick do mundo, mesmo com varios dormindo.
 */
public final class SleepAcceleration {
    private static final int RADIUS = 24;
    private static final int VERTICAL = 10;
    /** Posicoes extras sorteadas por tick, por jogador dormindo, para plantas/mudas. */
    private static final int RANDOM_TICKS_PER_PLAYER = 48;
    /** Ticks extras de fornalha por tick real (5x no total enquanto dorme). */
    private static final int FURNACE_EXTRA_TICKS = 4;
    /** A cada 5 ticks, filhotes ganham este numero de segundos de idade. */
    private static final int ANIMAL_SECONDS = 1;

    private SleepAcceleration() {}

    public static void init() {
        ServerTickEvents.END_WORLD_TICK.register(SleepAcceleration::tick);
    }

    private static void tick(ServerLevel level) {
        List<BlockPos> sleepingCenters = new ArrayList<>();
        for (ServerPlayer player : level.players()) {
            if (player.isSleeping()) sleepingCenters.add(player.blockPosition());
        }
        if (sleepingCenters.isEmpty()) return;

        Set<BlockPos> randomTicked = new HashSet<>();
        Set<BlockPos> furnacePositions = new HashSet<>();
        Set<UUID> agedAnimals = new HashSet<>();
        for (BlockPos center : sleepingCenters) {
            randomTicks(level, center, randomTicked);
            furnaces(level, center, furnacePositions);
        }

        for (BlockPos center : sleepingCenters) {
            if (level.getGameTime() % 5 == 0) animals(level, center, agedAnimals);
        }
    }

    private static void randomTicks(ServerLevel level, BlockPos center, Set<BlockPos> alreadyTicked) {
        for (int i = 0; i < RANDOM_TICKS_PER_PLAYER; i++) {
            BlockPos pos = center.offset(
                    level.random.nextInt(RADIUS * 2 + 1) - RADIUS,
                    level.random.nextInt(VERTICAL * 2 + 1) - VERTICAL,
                    level.random.nextInt(RADIUS * 2 + 1) - RADIUS);
            if (!alreadyTicked.add(pos) || !level.isLoaded(pos)) continue;
            BlockState state = level.getBlockState(pos);
            if (state.isRandomlyTicking()) state.randomTick(level, pos, level.random);
        }
    }

    private static void furnaces(ServerLevel level, BlockPos center, Set<BlockPos> alreadyTicked) {
        int cx = center.getX() >> 4, cz = center.getZ() >> 4;
        int chunkRadius = (RADIUS >> 4) + 1;
        List<AbstractFurnaceBlockEntity> found = new ArrayList<>();
        for (int dx = -chunkRadius; dx <= chunkRadius; dx++) {
            for (int dz = -chunkRadius; dz <= chunkRadius; dz++) {
                LevelChunk chunk = level.getChunkSource().getChunkNow(cx + dx, cz + dz);
                if (chunk == null) continue;
                for (BlockEntity be : new ArrayList<>(chunk.getBlockEntities().values())) {
                    if (be instanceof AbstractFurnaceBlockEntity furnace
                            && furnace.getBlockPos().distSqr(center) <= (double) RADIUS * RADIUS
                            && alreadyTicked.add(furnace.getBlockPos().immutable())) {
                        found.add(furnace);
                    }
                }
            }
        }
        for (AbstractFurnaceBlockEntity furnace : found) {
            for (int i = 0; i < FURNACE_EXTRA_TICKS; i++) {
                AbstractFurnaceBlockEntity.serverTick(level, furnace.getBlockPos(), furnace.getBlockState(), furnace);
            }
        }
    }

    private static void animals(ServerLevel level, BlockPos center, Set<UUID> alreadyAged) {
        AABB box = new AABB(center).inflate(RADIUS, VERTICAL, RADIUS);
        for (AgeableMob mob : level.getEntitiesOfClass(AgeableMob.class, box)) {
            if (mob.getAge() < 0 && alreadyAged.add(mob.getUUID())) mob.ageUp(ANIMAL_SECONDS);
        }
    }
}
