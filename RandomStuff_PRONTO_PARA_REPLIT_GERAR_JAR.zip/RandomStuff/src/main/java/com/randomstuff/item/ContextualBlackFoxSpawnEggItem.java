package com.randomstuff.item;

import com.randomstuff.registry.ModEntities;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EntityTypes;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.animal.fox.Fox;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.core.Holder;

/**
 * Ovo contextual: invoca Raposa Negra dentro da Floresta Salpicada e raposa vanilla
 * fora dela. A Floresta Salpicada corresponde ao bioma vanilla dappled_forest do Minecraft 26.3.
 * A interacao e interceptada no servidor e consome o item somente apos inserir a raposa.
 */
public final class ContextualBlackFoxSpawnEggItem extends Item {
    public ContextualBlackFoxSpawnEggItem(Properties properties) {
        super(properties);
    }

    public static void init() {
        UseBlockCallback.EVENT.register((player, level, hand, hit) -> {
            ItemStack stack = player.getItemInHand(hand);
            if (!stack.is(com.randomstuff.registry.ModItems.BLACK_FOX_SPAWN_EGG)) {
                return InteractionResult.PASS;
            }
            if (player.isSpectator()) return InteractionResult.PASS;
            if (!(level instanceof ServerLevel serverLevel)) return InteractionResult.SUCCESS;

            BlockPos spawnPos = hit.getBlockPos().relative(hit.getDirection());
            return spawnFox(player, stack, serverLevel, spawnPos);
        });

        // O item customizado tambem precisa cobrir o uso sobre entidades; ao contrario
        // de SpawnEggItem, ele nao herda automaticamente a interacao vanilla.
        UseEntityCallback.EVENT.register((player, level, hand, target, hit) -> {
            ItemStack stack = player.getItemInHand(hand);
            if (!stack.is(com.randomstuff.registry.ModItems.BLACK_FOX_SPAWN_EGG)) {
                return InteractionResult.PASS;
            }
            if (player.isSpectator()) return InteractionResult.PASS;
            if (!(level instanceof ServerLevel serverLevel)) return InteractionResult.SUCCESS;
            return spawnFox(player, stack, serverLevel, target.blockPosition().above());
        });
    }

    private static InteractionResult spawnFox(net.minecraft.world.entity.player.Player player,
                                               ItemStack stack, ServerLevel level, BlockPos spawnPos) {
        Holder<Biome> biome = level.getBiome(spawnPos);
        EntityType<? extends Fox> type = biome.is(ModEntities.DAPPLED_FOREST_KEY)
                ? ModEntities.BLACK_FOX : EntityTypes.FOX;
        Fox fox = type.create(level, EntitySpawnReason.SPAWN_ITEM_USE);
        if (fox == null) return InteractionResult.FAIL;

        fox.setPos(spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D);
        if (!level.addFreshEntity(fox)) return InteractionResult.FAIL;
        if (!player.getAbilities().instabuild) stack.shrink(1);
        return InteractionResult.SUCCESS;
    }
}
