package com.randomstuff.item;

import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.item.BrushItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;

/**
 * Pincel colorido. Continua funcionando como pincel de escavacao (herda de BrushItem).
 * A "tinta" e separada da durabilidade do pincel e fica no componente CUSTOM_DATA (chave "Paint").
 * Pincel sem a chave = tinta cheia. A recarga pela agua colorida e a lavagem em agua normal
 * sao tratadas pela feature ColoredWater.
 */
public class ColoredBrushItem extends BrushItem {
	public static final int MAX_PAINT = 64;
	private static final String TAG_PAINT = "Paint";

	private final DyeColor color;

	public ColoredBrushItem(DyeColor color, Properties properties) {
		super(properties);
		this.color = color;
	}

	public DyeColor getColor() {
		return color;
	}

	public static int getPaint(ItemStack stack) {
		CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
		return tag.getIntOr(TAG_PAINT, MAX_PAINT);
	}

	public static void setPaint(ItemStack stack, int paint) {
		CompoundTag tag = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
		tag.putInt(TAG_PAINT, Math.max(0, Math.min(MAX_PAINT, paint)));
		stack.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
	}
}
