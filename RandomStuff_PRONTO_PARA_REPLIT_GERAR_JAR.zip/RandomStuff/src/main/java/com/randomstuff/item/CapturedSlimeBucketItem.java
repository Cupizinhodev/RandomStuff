package com.randomstuff.item;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.cubemob.AbstractCubeMob;
import net.minecraft.world.entity.monster.cubemob.Slime;
import com.randomstuff.entity.SlimeColorAccess;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.context.UseOnContext;

/**
 * Balde persistente de Slime/Cubo de Magma. Somente campos explicitamente permitidos
 * sao copiados; nunca serializa NBT arbitrario fornecido pelo jogador.
 */
public class CapturedSlimeBucketItem extends Item {
    private static final String TAG_SIZE = "Size";
    private static final String TAG_NAME = "Name";
    private static final String TAG_HEALTH_RATIO = "HealthRatio";
    private static final String TAG_NO_AI = "NoAI";
    private static final String TAG_INVULNERABLE = "Invulnerable";
    private static final String TAG_PERSISTENT = "Persistent";
    private static final String TAG_COLOR = "SlimeColor";
    private static final int MAX_STORED_SIZE = 127;
    private static final int MAX_NAME_LENGTH = 128;

    private final EntityType<? extends AbstractCubeMob> mobType;

    public CapturedSlimeBucketItem(EntityType<? extends AbstractCubeMob> mobType, Properties properties) {
        super(properties);
        this.mobType = mobType;
    }

    /** Copia uma lista fechada de dados relevantes para o componente persistente do item. */
    public static void storeMob(ItemStack bucket, AbstractCubeMob slime) {
        CompoundTag tag = new CompoundTag();
        tag.putInt(TAG_SIZE, clamp(slime.getSize(), 1, MAX_STORED_SIZE));
        float maxHealth = Math.max(1.0F, slime.getMaxHealth());
        tag.putFloat(TAG_HEALTH_RATIO, clamp(slime.getHealth() / maxHealth, 0.0F, 1.0F));
        if (slime.hasCustomName()) {
            String name = slime.getCustomName().getString();
            if (name.length() > MAX_NAME_LENGTH) name = name.substring(0, MAX_NAME_LENGTH);
            tag.putString(TAG_NAME, name);
        }
        tag.putBoolean(TAG_NO_AI, slime.isNoAi());
        tag.putBoolean(TAG_INVULNERABLE, slime.isInvulnerable());
        tag.putBoolean(TAG_PERSISTENT, slime.isPersistenceRequired());
        if (slime instanceof Slime) tag.putInt(TAG_COLOR, ((SlimeColorAccess) slime).randomstuff$getColor());
        bucket.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        if (!(context.getLevel() instanceof ServerLevel level)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack held = context.getItemInHand();
        BlockPos pos = context.getClickedPos().relative(context.getClickedFace());
        AbstractCubeMob slime = mobType.create(level, EntitySpawnReason.BUCKET);
        if (slime == null) return InteractionResult.FAIL;

        CompoundTag tag = held.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY).copyTag();
        slime.setSize(clamp(tag.getIntOr(TAG_SIZE, 1), 1, MAX_STORED_SIZE), true);
        if (slime instanceof Slime) ((SlimeColorAccess) slime).randomstuff$setColor(tag.getIntOr(TAG_COLOR, -1));
        slime.setNoAi(tag.getBooleanOr(TAG_NO_AI, false));
        slime.setInvulnerable(tag.getBooleanOr(TAG_INVULNERABLE, false));
        if (tag.getBooleanOr(TAG_PERSISTENT, false)) slime.setPersistenceRequired();

        String name = tag.getStringOr(TAG_NAME, "");
        if (!name.isEmpty()) slime.setCustomName(Component.literal(name));

        float ratio = clamp(tag.getFloatOr(TAG_HEALTH_RATIO, 1.0F), 0.0F, 1.0F);
        slime.setHealth(Math.max(0.1F, slime.getMaxHealth() * ratio));
        slime.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);

        // O item so e consumido depois que o servidor aceita a entidade no mundo.
        if (!level.addFreshEntity(slime)) return InteractionResult.FAIL;

        level.playSound(null, pos, SoundEvents.BUCKET_EMPTY_FISH, SoundSource.NEUTRAL, 1.0F, 1.0F);
        Player player = context.getPlayer();
        if (player != null && !player.getAbilities().instabuild) {
            player.setItemInHand(context.getHand(), new ItemStack(Items.BUCKET));
        }
        return InteractionResult.SUCCESS;
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(max, value));
    }

    private static float clamp(float value, float min, float max) {
        if (!Float.isFinite(value)) return min;
        return Math.max(min, Math.min(max, value));
    }
}
