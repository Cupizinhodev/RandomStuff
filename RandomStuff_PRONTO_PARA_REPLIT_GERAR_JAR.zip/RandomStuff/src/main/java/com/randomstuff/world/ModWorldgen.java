package com.randomstuff.world;

import com.randomstuff.RandomStuffMod;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.fabricmc.fabric.api.biome.v1.BiomeModification;
import net.fabricmc.fabric.api.biome.v1.BiomeModificationContext;
import net.fabricmc.fabric.api.biome.v1.ModificationPhase;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.attribute.EnvironmentAttributes;
import net.minecraft.util.ARGB;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

/**
 * Liga recursos de worldgen em biomas vanilla existentes. Os biomas Pale Garden e
 * Dappled Forest ja existem no Minecraft 26.3; nao duplicamos esses registros.
 */
public final class ModWorldgen {
    private static final ResourceKey<Biome> PALE_GARDEN = ResourceKey.create(
            Registries.BIOME, Identifier.withDefaultNamespace("pale_garden"));
    private static final ResourceKey<Biome> DAPPLED_FOREST = ResourceKey.create(
            Registries.BIOME, Identifier.withDefaultNamespace("dappled_forest"));

    private static final ResourceKey<PlacedFeature> PALE_WHITE_PUMPKINS = placed("pale_white_pumpkins");
    private static final ResourceKey<PlacedFeature> DAPPLED_PUMPKINS = placed("dappled_pumpkins");
    private static final ResourceKey<PlacedFeature> DAPPLED_CARVED_PUMPKINS = placed("dappled_carved_pumpkins");
    private static final ResourceKey<PlacedFeature> DAPPLED_JACK_O_LANTERNS = placed("dappled_jack_o_lanterns");

    private ModWorldgen() {}

    private static ResourceKey<PlacedFeature> placed(String path) {
        return ResourceKey.create(Registries.PLACED_FEATURE, RandomStuffMod.id(path));
    }

    public static void init() {
        // Aboboras brancas aparecem somente no Jardim Palido.
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(PALE_GARDEN),
                GenerationStep.Decoration.VEGETAL_DECORATION, PALE_WHITE_PUMPKINS);

        // A Floresta Salpicada (Dappled Forest vanilla) recebe grupos de aboboras.
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(DAPPLED_FOREST),
                GenerationStep.Decoration.VEGETAL_DECORATION, DAPPLED_PUMPKINS);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(DAPPLED_FOREST),
                GenerationStep.Decoration.VEGETAL_DECORATION, DAPPLED_CARVED_PUMPKINS);
        BiomeModifications.addFeature(BiomeSelectors.includeByKey(DAPPLED_FOREST),
                GenerationStep.Decoration.VEGETAL_DECORATION, DAPPLED_JACK_O_LANTERNS);

        // Ajustes ambientais por bioma usando o sistema de atributos introduzido antes de 26.3.
        // A fase POST_PROCESSING faz os ajustes depois das adicoes/remocoes/replacements de biomas.
        BiomeModification atmosphere = BiomeModifications.create(RandomStuffMod.id("biome_atmosphere"));
        atmosphere.add(ModificationPhase.POST_PROCESSING,
                BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP),
                context -> applyAtmosphere(context, 0x899B78, 0xA6B28C, 0x657B55, 0x82935F, 0x718B58));
        atmosphere.add(ModificationPhase.POST_PROCESSING,
                BiomeSelectors.includeByKey(Biomes.DESERT),
                context -> applyAtmosphere(context, 0xD6B27D, 0xE8C58A, 0xAFA06A, 0xC1A66B, 0xD4B77A));
        atmosphere.add(ModificationPhase.POST_PROCESSING,
                BiomeSelectors.includeByKey(Biomes.BADLANDS, Biomes.ERODED_BADLANDS, Biomes.WOODED_BADLANDS),
                context -> applyAtmosphere(context, 0xC58A59, 0xD9A66C, 0xA17A4F, 0xB68A55, 0xC69A62));
        // Floresta Salpicada: luz e neblina quentes, mantendo a paleta outonal vanilla.
        atmosphere.add(ModificationPhase.POST_PROCESSING,
                BiomeSelectors.includeByKey(DAPPLED_FOREST),
                context -> applyAtmosphere(context, 0xB98558, 0xE2A96D, 0xA97843, 0xC18A4E, 0x9A8060));
        // Jardim Pálido: atmosfera fria/cinzenta e mais sombria, sem remover fontes de luz.
        atmosphere.add(ModificationPhase.POST_PROCESSING,
                BiomeSelectors.includeByKey(PALE_GARDEN),
                context -> applyAtmosphere(context, 0x555B60, 0x777D82, 0x777D78, 0x85877F, 0x667078));
    }

    private static void applyAtmosphere(BiomeModificationContext context, int fog, int sky,
                                        int foliage, int grass, int water) {
        context.getAttributes().set(EnvironmentAttributes.FOG_COLOR, ARGB.vector3fFromRGB24(fog));
        context.getAttributes().set(EnvironmentAttributes.SKY_COLOR, ARGB.vector3fFromRGB24(sky));
        context.getAttributes().set(EnvironmentAttributes.WATER_FOG_COLOR, ARGB.vector3fFromRGB24(fog));
        context.getEffects().setFoliageColorOverride(foliage);
        context.getEffects().setGrassColorOverride(grass);
        context.getEffects().setWaterColor(water);
    }
}
