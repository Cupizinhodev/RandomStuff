package com.randomstuff.world;

import com.randomstuff.registry.ModDiscs;
import com.randomstuff.registry.ModItems;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import net.fabricmc.fabric.api.loot.v3.LootTableEvents;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.storage.loot.functions.EnchantWithLevelsFunction;
import net.minecraft.world.level.storage.loot.functions.SetItemDamageFunction;
import net.minecraft.world.level.storage.loot.providers.number.ints.ContextIntProviders;
import net.minecraft.world.level.storage.loot.providers.number.floats.ContextFloatProviders;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.predicates.LootItemRandomChanceCondition;

/**
 * Loot de estruturas. O Molde de Ferraria de Ouro Rosa e ADICIONADO aos baus vanilla
 * (sem substituir as tabelas): chance baixa em fortalezas do Nether, um pouco maior em bastioes.
 *
 * Chances: ajuste as constantes abaixo se quiser mais ou menos raridade.
 */
public final class ModLootTables {
	private static final float FORTRESS_CHANCE = 0.05F;
	private static final float BASTION_CHANCE = 0.10F;

	private static final Map<String, Float> TEMPLATE_CHESTS = Map.of(
			"minecraft:chests/nether_bridge", FORTRESS_CHANCE,
			"minecraft:chests/bastion_treasure", BASTION_CHANCE,
			"minecraft:chests/bastion_other", BASTION_CHANCE,
			"minecraft:chests/bastion_bridge", BASTION_CHANCE,
			"minecraft:chests/bastion_hoglin_stable", BASTION_CHANCE);

	private record Extra(Item item, float chance) {}

	/** Discos disponiveis no Survival (vilas e strongholds): Aria Math, Biome Fest, Blind Spots, Dreiton, Haunt Muskie, Taswell. */
	private static List<Extra> withDiscs(List<Extra> base) {
		List<Extra> all = new ArrayList<>(base);
		ModDiscs.DISCS.values().forEach(disc -> all.add(new Extra(disc, 0.04F)));
		return all;
	}

	/**
	 * Itens extras nas vilas. As probabilidades sao pesos adicionais escolhidos para esta implementacao;
	 * o briefing lista os tipos de item, mas nao define chances. O loot vanilla permanece intacto.
	 */
	private static final List<Extra> VILLAGE_EXTRAS = withDiscs(List.of(
			new Extra(Items.IRON_NUGGET, 0.35F), new Extra(Items.GOLD_NUGGET, 0.20F),
			new Extra(Items.EMERALD, 0.20F), new Extra(Items.NAME_TAG, 0.15F), new Extra(Items.LEAD, 0.15F),
			new Extra(Items.SADDLE, 0.08F), new Extra(Items.BEETROOT_SEEDS, 0.18F),
			new Extra(Items.PUMPKIN_SEEDS, 0.18F), new Extra(Items.MELON_SEEDS, 0.18F),
			new Extra(Items.GOLDEN_CARROT, 0.20F), new Extra(Items.HONEY_BOTTLE, 0.15F),
			new Extra(Items.BONE_MEAL, 0.30F), new Extra(Items.COPPER_INGOT, 0.30F),
			new Extra(Items.AMETHYST_SHARD, 0.20F), new Extra(Items.STRING, 0.20F),
			new Extra(Items.LEATHER, 0.15F), new Extra(Items.FLINT, 0.15F), new Extra(Items.LANTERN, 0.15F),
			new Extra(Items.GOLDEN_APPLE, 0.04F), new Extra(Items.IRON_HORSE_ARMOR, 0.05F),
			new Extra(Items.GOLDEN_HORSE_ARMOR, 0.025F), new Extra(Items.FLOWER_BANNER_PATTERN, 0.025F),
			new Extra(Items.ANGLER_POTTERY_SHERD, 0.025F), new Extra(Items.ARCHER_POTTERY_SHERD, 0.025F),
			new Extra(Items.ARMS_UP_POTTERY_SHERD, 0.025F), new Extra(Items.BLADE_POTTERY_SHERD, 0.025F)));

	private static final List<String> VILLAGE_CHESTS = List.of(
			"village_plains_house", "village_desert_house", "village_savanna_house", "village_snowy_house",
			"village_taiga_house", "village_weaponsmith", "village_toolsmith", "village_armorer",
			"village_cartographer", "village_butcher", "village_fletcher", "village_mason", "village_shepherd",
			"village_tannery", "village_temple");

	/**
	 * Itens extras em strongholds. O briefing nao define chances; os pesos abaixo sao ajustes iniciais.
	 * Nao inclui cristal do End, cabeca de Creeper, sementes, fragmento de eco nem tridente.
	 */
	private static final List<Extra> STRONGHOLD_EXTRAS = withDiscs(List.of(
			new Extra(Items.AMETHYST_SHARD, 0.30F), new Extra(Items.IRON_INGOT, 0.20F),
			new Extra(Items.GOLD_INGOT, 0.15F), new Extra(Items.GOLDEN_APPLE, 0.15F),
			new Extra(Items.ENDER_PEARL, 0.15F), new Extra(Items.NAME_TAG, 0.15F),
			new Extra(Items.SADDLE, 0.15F), new Extra(Items.IRON_HORSE_ARMOR, 0.08F),
			new Extra(Items.GOLDEN_HORSE_ARMOR, 0.06F), new Extra(Items.DIAMOND_HORSE_ARMOR, 0.025F),
			new Extra(Items.DIAMOND, 0.08F), new Extra(Items.OBSIDIAN, 0.10F),
			new Extra(Items.FIRE_CHARGE, 0.20F), new Extra(Items.HEART_OF_THE_SEA, 0.05F),
			new Extra(Items.NAUTILUS_SHELL, 0.10F), new Extra(Items.PHANTOM_MEMBRANE, 0.15F),
			new Extra(Items.TOTEM_OF_UNDYING, 0.005F), new Extra(Items.EXPERIENCE_BOTTLE, 0.20F),
			new Extra(Items.ENDER_EYE, 0.10F), new Extra(ModItems.ROSE_GOLD_UPGRADE_SMITHING_TEMPLATE, 0.02F)));

	private static final List<String> STRONGHOLD_CHESTS = List.of("stronghold_corridor", "stronghold_crossing", "stronghold_library");

	private ModLootTables() {}

	private static void addExtras(net.minecraft.world.level.storage.loot.LootTable.Builder table, List<Extra> extras) {
		for (Extra extra : extras) {
			table.withPool(LootPool.lootPool()
					.when(LootItemRandomChanceCondition.randomChance(extra.chance()))
					.add(LootItem.lootTableItem(extra.item())));
		}
	}

	private static void addEnchantedBook(net.minecraft.world.level.storage.loot.LootTable.Builder table,
	                                     net.minecraft.core.HolderLookup.Provider registries,
	                                     float chance, int minLevel, int maxLevel) {
		var enchantments = registries.lookupOrThrow(Registries.ENCHANTMENT);
		table.withPool(LootPool.lootPool()
				.when(LootItemRandomChanceCondition.randomChance(chance))
				.add(LootItem.lootTableItem(Items.BOOK)
						.apply(EnchantWithLevelsFunction.enchantWithLevels(
								enchantments, ContextIntProviders.between(minLevel, maxLevel)))));
	}

	private static void addDamagedDiamondEquipment(net.minecraft.world.level.storage.loot.LootTable.Builder table) {
		Item[] equipment = {
				Items.DIAMOND_HELMET, Items.DIAMOND_CHESTPLATE, Items.DIAMOND_LEGGINGS, Items.DIAMOND_BOOTS,
				Items.DIAMOND_SWORD, Items.DIAMOND_PICKAXE, Items.DIAMOND_AXE, Items.DIAMOND_SHOVEL, Items.DIAMOND_HOE
		};
		for (Item item : equipment) {
			table.withPool(LootPool.lootPool()
					.when(LootItemRandomChanceCondition.randomChance(0.025F))
					.add(LootItem.lootTableItem(item)
							.apply(SetItemDamageFunction.setDamage(ContextFloatProviders.between(0.20F, 0.75F)))));
		}
	}

	public static void init() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			String id = key.identifier().toString();
			if (id.startsWith("minecraft:chests/")) {
				String chest = id.substring("minecraft:chests/".length());
				if (VILLAGE_CHESTS.contains(chest)) {
					addExtras(tableBuilder, VILLAGE_EXTRAS);
					addEnchantedBook(tableBuilder, registries, 0.045F, 2, 7);
				} else if (STRONGHOLD_CHESTS.contains(chest)) {
					addExtras(tableBuilder, STRONGHOLD_EXTRAS);
					addEnchantedBook(tableBuilder, registries, 0.10F, 3, 9);
					addDamagedDiamondEquipment(tableBuilder);
				}
			}
			Float chance = TEMPLATE_CHESTS.get(id);
			if (chance == null) {
				return;
			}
			tableBuilder.withPool(LootPool.lootPool()
					.when(LootItemRandomChanceCondition.randomChance(chance))
					.add(LootItem.lootTableItem(ModItems.ROSE_GOLD_UPGRADE_SMITHING_TEMPLATE)));
		});
	}
}
