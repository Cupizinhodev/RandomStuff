package com.randomstuff.entity.vehicle;

import com.randomstuff.block.CopperHopperBlock;
import com.randomstuff.registry.ModCopperHoppers;
import com.randomstuff.registry.ModItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.minecart.MinecartHopper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

/** Carrinho-funil de cobre: inventario de cinco slots, filtro por tipo e velocidade por oxidação. */
public final class CopperHopperMinecart extends MinecartHopper {
	private static final int TRANSFER_TICKS = CopperHopperBlock.Age.NORMAL.transferTicks;

	public CopperHopperMinecart(EntityType<? extends CopperHopperMinecart> type, Level level) {
		super(type, level);
	}

	@Override
	public BlockState getDefaultDisplayBlockState() {
		return ModCopperHoppers.get(com.randomstuff.block.CopperHopperBlock.Age.NORMAL, false).defaultBlockState();
	}

	@Override
	public boolean canPlaceItem(int slot, ItemStack stack) {
		if (stack.isEmpty()) return true;
		ItemStack filter = filterStack();
		return filter.isEmpty() || ItemStack.isSameItemSameComponents(filter, stack);
	}

	private ItemStack filterStack() {
		for (int i = 0; i < getContainerSize(); i++) {
			ItemStack stack = getItem(i);
			if (!stack.isEmpty()) return stack;
		}
		return ItemStack.EMPTY;
	}

	private int totalItems() {
		int total = 0;
		for (int i = 0; i < getContainerSize(); i++) total += getItem(i).getCount();
		return total;
	}

	@Override
	public ItemStack removeItem(int slot, int amount) {
		if (slot < 0 || slot >= getContainerSize() || amount <= 0) return ItemStack.EMPTY;
		ItemStack current = getItem(slot);
		int removable = Math.min(amount, Math.max(0, totalItems() - 1));
		if (current.isEmpty() || removable == 0) return ItemStack.EMPTY;
		ItemStack removed = current.split(removable);
		if (current.isEmpty()) setItem(slot, ItemStack.EMPTY);
		setChanged();
		return removed;
	}

	@Override
	public ItemStack removeItemNoUpdate(int slot) {
		if (slot < 0 || slot >= getContainerSize()) return ItemStack.EMPTY;
		ItemStack current = getItem(slot);
		int removable = Math.min(current.getCount(), Math.max(0, totalItems() - 1));
		if (current.isEmpty() || removable == 0) return ItemStack.EMPTY;
		ItemStack removed = current.copyWithCount(removable);
		current.shrink(removable);
		if (current.isEmpty()) setItem(slot, ItemStack.EMPTY);
		return removed;
	}

	@Override
	public boolean suckInItems() {
		if (level().getGameTime() % TRANSFER_TICKS != 0L) return false;
		return super.suckInItems();
	}

	@Override
	protected Item getDropItem() {
		return ModItems.COPPER_HOPPER_MINECART;
	}

	@Override
	public ItemStack getPickResult() {
		return new ItemStack(ModItems.COPPER_HOPPER_MINECART);
	}
}
