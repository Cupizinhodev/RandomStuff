package com.randomstuff.entity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.animal.fox.Fox;
import net.minecraft.world.level.Level;

/** Variante de raposa que herda integralmente IA, atributos e comportamento vanilla. */
public final class BlackFoxEntity extends Fox {
    public BlackFoxEntity(EntityType<? extends Fox> type, Level level) {
        super(type, level);
    }
}
