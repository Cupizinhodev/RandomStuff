package com.randomstuff.entity.decoration;

import com.randomstuff.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/** ItemFrame vanilla com drop/pick-result correspondente ao item colorido que a criou. */
public final class ModdedItemFrame extends ItemFrame {
	public ModdedItemFrame(EntityType<? extends ItemFrame> type, Level level) {
		super(type, level);
	}

	public ModdedItemFrame(EntityType<? extends ItemFrame> type, Level level, BlockPos pos, Direction direction) {
		super(type, level, pos, direction);
	}

	@Override
	protected ItemStack getFrameItemStack() {
		String entityId = BuiltInRegistries.ENTITY_TYPE.getKey(getType()).getPath();
		String itemId;
		if (entityId.equals("invisible_item_frame")) {
			itemId = "invisible_item_frame";
		} else if (entityId.startsWith("colored_item_frame_")) {
			itemId = entityId.substring("colored_item_frame_".length()) + "_item_frame";
		} else {
			return super.getFrameItemStack();
		}
		Item item = ModItems.ALL.get(itemId);
		return item == null ? super.getFrameItemStack() : new ItemStack(item);
	}
}
