package com.randomstuff.entity;

/** Acesso ao corante sincronizado/persistido do Slime vanilla. -1 representa sem cor. */
public interface SlimeColorAccess {
    int randomstuff$getColor();
    void randomstuff$setColor(int colorId);
}
