package com.randomstuff.entity;

import com.randomstuff.registry.ModBlocks;
import com.randomstuff.registry.ModEntities;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Shearable;
import net.minecraft.world.entity.animal.cow.Cow;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;

/**
 * Base de comportamento das vacas florais. A variante e o estado de floracao sao
 * sincronizados e persistidos. A camada visual deve ler getFlowerVariant()/hasFlowers().
 */
public class FlowerCowEntity extends Cow implements Shearable {
    private static final EntityDataAccessor<Integer> FLOWER_VARIANT =
            SynchedEntityData.defineId(FlowerCowEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> HAS_FLOWERS =
            SynchedEntityData.defineId(FlowerCowEntity.class, EntityDataSerializers.BOOLEAN);
    private static final String TAG_VARIANT = "RandomStuffFlowerVariant";
    private static final String TAG_HAS_FLOWERS = "RandomStuffHasFlowers";
    private static final String TAG_REGROW = "RandomStuffFlowerRegrowTicks";
    public static final int REGROW_TICKS = 20 * 60 * 2; // 2 minutos de jogo (2.400 ticks)

    private final boolean moonlip;
    private int regrowTicks;

    public FlowerCowEntity(EntityType<? extends Cow> type, Level level, boolean moonlip) {
        super(type, level);
        this.moonlip = moonlip;
        int count = moonlip ? 7 : 9;
        this.entityData.set(FLOWER_VARIANT, this.random.nextInt(count));
        this.entityData.set(HAS_FLOWERS, true);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(FLOWER_VARIANT, 0);
        builder.define(HAS_FLOWERS, true);
    }

    public int getFlowerVariant() { return this.entityData.get(FLOWER_VARIANT); }
    public void setFlowerVariant(int variant) {
        int count = this.moonlip ? 7 : 9;
        this.entityData.set(FLOWER_VARIANT, Math.floorMod(variant, count));
    }
    public boolean hasFlowers() { return this.entityData.get(HAS_FLOWERS); }
    public boolean isMoonlip() { return this.moonlip; }

    /** Eye-of-Wax follows the same day/night boundary as the world clock. */
    public boolean isEyeOfWaxOpen() {
        if (this.moonlip || this.getFlowerVariant() != 8) return false;
        long time = Math.floorMod(this.level().getDayTime(), 24000L);
        return time >= 13000L && time < 23000L;
    }

    /**
     * Filhote da mesma especie floral (Moobloom -> Moobloom, Moonlip -> Moonlip).
     * Sem este override o Cow vanilla gera uma vaca comum. A variante vem de um dos pais (50% cada)
     * quando o parceiro e da mesma especie floral; caso contrario herda desta vaca.
     */
    @Override
    public Cow getBreedOffspring(ServerLevel level, AgeableMob partner) {
        Cow baby = (this.moonlip ? ModEntities.MOONLIP : ModEntities.MOOBLOOM).create(level, EntitySpawnReason.BREEDING);
        if (baby instanceof FlowerCowEntity flowerBaby) {
            int variant = this.getFlowerVariant();
            if (partner instanceof FlowerCowEntity other && other.moonlip == this.moonlip && this.random.nextBoolean()) {
                variant = other.getFlowerVariant();
            }
            flowerBaby.setFlowerVariant(variant);
        }
        return baby;
    }

    @Override
    public boolean readyForShearing() {
        return this.isAlive() && this.hasFlowers();
    }

    @Override
    public void shear(ServerLevel level, SoundSource soundSource, ItemStack tool) {
        if (!this.readyForShearing()) return;
        ItemStack flower = this.getFlowerDrop();
        if (!flower.isEmpty()) this.spawnAtLocation(level, flower);
        this.entityData.set(HAS_FLOWERS, false);
        this.regrowTicks = REGROW_TICKS;
        level.playSound(null, this.blockPosition(), SoundEvents.SHEEP_SHEAR, soundSource, 1.0F, 1.0F);
    }

    private ItemStack getFlowerDrop() {
        if (this.moonlip) {
            return switch (this.getFlowerVariant()) {
                case 0 -> new ItemStack(ModBlocks.PINK_DAISY);
                case 1 -> new ItemStack(Items.ORANGE_TULIP);
                case 2 -> new ItemStack(Items.RED_TULIP);
                case 3 -> new ItemStack(Items.PINK_TULIP);
                case 4 -> new ItemStack(Items.WHITE_TULIP);
                case 5 -> new ItemStack(Items.OXEYE_DAISY);
                default -> new ItemStack(ModBlocks.MAGENTA_TULIP);
            };
        }
        return switch (this.getFlowerVariant()) {
            case 0 -> new ItemStack(ModBlocks.BUTTERCUP);
            case 1 -> new ItemStack(Items.POPPY);
            case 2 -> new ItemStack(Items.DANDELION);
            case 3 -> new ItemStack(Items.BLUE_ORCHID);
            case 4 -> new ItemStack(Items.ALLIUM);
            case 5 -> new ItemStack(Items.AZURE_BLUET);
            case 6 -> new ItemStack(Items.LILY_OF_THE_VALLEY);
            case 7 -> new ItemStack(Items.CORNFLOWER);
            default -> new ItemStack(Items.CLOSED_EYEBLOSSOM);
        };
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        if (held.is(Items.SHEARS) && this.readyForShearing()) {
            if (!this.level().isClientSide && this.level() instanceof ServerLevel serverLevel) {
                this.shear(serverLevel, SoundSource.PLAYERS, held);
                held.hurtAndBreak(1, player, hand);
            }
            return InteractionResult.SUCCESS;
        }
        return super.mobInteract(player, hand);
    }

    @Override
    public void tick() {
        super.tick();
        if (!this.level().isClientSide && !this.hasFlowers() && this.regrowTicks > 0) {
            --this.regrowTicks;
            if (this.regrowTicks == 0) {
                this.entityData.set(HAS_FLOWERS, true);
            }
        }
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput output) {
        super.addAdditionalSaveData(output);
        output.putInt(TAG_VARIANT, this.getFlowerVariant());
        output.putBoolean(TAG_HAS_FLOWERS, this.hasFlowers());
        output.putInt(TAG_REGROW, this.regrowTicks);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput input) {
        super.readAdditionalSaveData(input);
        this.setFlowerVariant(input.getIntOr(TAG_VARIANT, 0));
        this.entityData.set(HAS_FLOWERS, input.getBooleanOr(TAG_HAS_FLOWERS, true));
        this.regrowTicks = Math.max(0, input.getIntOr(TAG_REGROW, 0));
    }
}
