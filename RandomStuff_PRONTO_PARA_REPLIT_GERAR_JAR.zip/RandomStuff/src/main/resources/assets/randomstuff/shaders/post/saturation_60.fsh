#version 150
// Saturacao visual configuravel (60/100; 50 = neutro). Gerado: fator = valor/50.
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 source = texture(InSampler, texCoord);
    float luma = dot(source.rgb, vec3(0.2126, 0.7152, 0.0722));
    vec3 c = mix(vec3(luma), source.rgb, 1.20);
    fragColor = vec4(clamp(c, 0.0, 1.0), source.a);
}
