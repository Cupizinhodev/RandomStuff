# Random Stuff — fechamento das etapas não complexas

Data: 08/11/2026  
Alvo declarado: Minecraft Java 26.3 · Fabric · Java 25

## Resultado desta rodada

A revisão foi feita sobre o ZIP `RandomStuff_Recursos_Faceis_Conjunto_Sem_Compilar_2026-11-08.zip` e os briefings originais. Os recursos pequenos e independentes já previstos foram conferidos e preservados. Não foram criadas mecânicas novas fora do briefing nem duplicadas funções que já existiam.

### Recursos simples cobertos no projeto

- 20 receitas de cortador de pedras para troncos/madeiras vanilla descascados (10 espécies, aceitando tronco e madeira).
- Farinha de osso acelera cana-de-açúcar.
- Bigorna danificada pode ser reparada com bloco de ferro, um estágio por bloco.
- Espada de ouro usa dano-base equivalente ao da espada de Netherite, preservando durabilidade de ouro.
- Itens de Netherite flutuam na lava.
- Ofertas de compra e venda do Mercador Ambulante conforme lista do briefing; não compra escama de tartaruga.
- Cabeças protegem contra mobs da mesma espécie; Piglin tem tratamento separado.
- Bloco de Osso de Wither copia propriedades/som do Bloco de Ossos vanilla.
- Lajes, escadas e muros registrados copiam propriedades do bloco-base; a lista contém 51 variantes e as receitas de cortador de pedras correspondentes estão presentes.
- Água Colorida, pincéis e recarga pela interface da bigorna estão preservados como implementações ainda não verificadas em runtime.

## Correção adicional de integridade dos assets

O ZIP de entrada tinha oito caminhos de assets originais com caracteres acentuados corrompidos no nome: quatro estágios da plantação de cenoura dourada e quatro arquivos do equipamento de Ouro Rosa. Os arquivos estavam presentes, mas os nomes não correspondiam ao manifesto UTF-8. Os nomes foram corrigidos sem reprocessar ou alterar os bytes dos PNGs. A auditoria SHA-256/dimensões voltou a passar para os 181 assets originais.

## Itens não classificados como simples / ainda pendentes

- Folhas ressecadas flutuando: a referência visual existe, mas o briefing não define o bloco/item exato nem a regra completa de posicionamento; não inventar o alvo.
- Configuração de saturação visual (padrão 50): exige tela/configuração persistente e integração ao pipeline de renderização do cliente; fica para etapa intermediária própria.
- Filtros visuais das cabeças: JSON/shaders e seleção de filtro já existem; falta validar o pipeline de post effects do 26.3 em compilação e jogo.
- Portal do Nether horizontal: exige alterar validação/forma/posicionamento do portal vanilla e não é uma simples receita ou dado.
- Funil de Cobre, Painel de Exposição, Molduras, entidades, biomas, encantamentos, beacon, tridente, carrinhos/correntes e sono: reservados para etapas próprias conforme matriz de implementação.

## Verificações

- `scripts/validar_projeto.py`: 739 JSON, 170 PNGs de recursos, 181 assets originais no manifesto, 34 classes Java; 0 erros e 1 aviso (não há suíte em `src/test`).
- `scripts/validar_assets.py`: 181 PNGs originais; 0 erros.
- 51 variantes de lajes/escadas/muros: receitas de cortador de pedras correspondentes encontradas.
- Nenhuma compilação Gradle, `javac`, geração de JAR ou teste no Minecraft foi executado.

## Critério de conclusão

Esta rodada fecha a revisão dos recursos simples e corrige a integridade dos nomes dos assets. Não significa que o mod esteja completo: os itens pendentes acima continuam abertos, e todo comportamento runtime precisa de compilação e teste em Minecraft 26.3.
