# Cubo de Enxofre — o que já é do jogo (fonte: Mojang, 26.2 "Chaos Cubed" e snapshot 6)

O Cubo de Enxofre JÁ EXISTE no Minecraft vanilla desde a 26.2 (responde a dúvida 1 do PLANO_ETAPAS.md).
- Jogador interage segurando um bloco: o cubo absorve o bloco, a IA dele é desligada e ele vira objeto físico.
- Os efeitos vêm de ARQUÉTIPOS, que são DADOS (registro `minecraft:sulfur_cube_archetype`; itens/blocos que definem o arquétipo ficam em tags `#sulfur_cube_archetype/<nome>`).
- Arquétipos citados pela Mojang: regular, explosivo (TNT), hot (bloco de magma: dano de contato), slow_bouncy (pedra).
- Campos de um arquétipo: `explosion {fuse, power, causes_fire}`, `contact_damage {amount, damage_type, attribute_to_source}`,
  `knockback_modifiers {horizontal_power, vertical_power}` e outros de física (velocidade, quicar, atrito, arrasto, boiar) cujo formato exato ainda NÃO foi visto.

## Das absorções aprovadas no briefing
| Absorção | Situação |
|---|---|
| TNT (explode) | já é do jogo |
| Bloco de magma (dano de contato) | já é do jogo (arquétipo hot) |
| Mel (gruda em paredes), Fornalha, Bancada, Glowstone (luz), Bloco de redstone (sinal), Esponja, Bloco de ossos (cães) | NÃO existem no jogo; exigem comportamento novo em código. Não escritas: o formato completo de um arquétipo ainda não foi conferido. |

Para escrever as demais com segurança: rode `bash scripts/extrair_referencias.sh` e envie o `referencias_minecraft.zip` (traz os arquivos reais de arquétipo).
