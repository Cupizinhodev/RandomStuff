# Auditoria técnica — Random Stuff
**Data:** 08/11/2026  
**Alvo declarado:** Minecraft Java 26.3, Fabric Loader 0.19.5, Fabric API 0.163.0+26.3, Java 25  
**Estado:** preparação e auditoria estática; **NÃO COMPILADO e NÃO TESTADO DENTRO DO MINECRAFT**.

## 1. Resultado executivo

O ZIP contém um projeto Fabric real, com Gradle Wrapper, fontes comuns e de cliente, metadados Fabric, mixins, dados e assets. A estrutura e as versões declaradas correspondem ao projeto de exemplo 26.3 fornecido junto.

A base existente foi preservada. Não houve reconstrução do mod, publicação ou geração de JAR. Foi feita uma correção pontual na soltura dos Slimes/Cubos de Magma e uma correção de nomes de caminhos de assets que estavam corrompidos pela codificação dos nomes no ZIP. Os bytes dos PNGs não foram alterados.

**A auditoria estática passou:** 670 arquivos JSON lidos sem erro, 150 PNGs de recursos com cabeçalho válido, 181 assets originais conferidos contra SHA-256/dimensões do manifesto, 25 classes Java encontradas, entrypoints/mixins presentes e referências verificadas de modelos/texturas sem ausências. O validador terminou com 0 erros e 1 aviso: não há suíte de testes em `src/test`.

Isso NÃO comprova compilação, inicialização ou funcionamento das mecânicas.

## 2. Correções realizadas nesta preparação

1. **Balde de Slime/Cubo de Magma:** `CapturedSlimeBucketItem` agora verifica o retorno de `ServerLevel.addFreshEntity`. Se o mob não puder ser inserido no mundo, a interação falha e o balde não é consumido. Antes, o código consumia o balde mesmo sem confirmar que a entidade foi adicionada.
2. **Nomes dos assets originais:** cinco caminhos estavam com caracteres corrompidos (por exemplo, `planta├º├úo`, `lan├ºa` e `p├í`) devido à codificação dos nomes dentro do ZIP. Os caminhos foram normalizados para os nomes UTF-8 previstos no manifesto. Os 181 arquivos PNG continuam com os mesmos hashes do manifesto.
3. **Validador estático:** adicionado `scripts/validar_projeto.py` para verificar JSON, PNGs, manifesto, entrypoints, mixins, modelos e texturas sem executar Gradle ou compilar.
4. **Compatibilidade 26.3:** removidos os codecs de blocos obsoletos das três classes de blocos customizados; corrigido o caminho padrão do validador de assets.

## 2.1 Correções adicionais desta revisão técnica

4. **Minecraft 26.3 — remoção dos codecs de blocos:** removidos `MapCodec`, campos `CODEC` e sobrescritas de `codec()` de `WhitePumpkinBlock`, `CarvedWhitePumpkinBlock` e `GoldenCarrotsBlock`. A documentação oficial do Fabric para 26.3 registra a remoção dos codecs de blocos e do registry `block_type`; manter essas declarações antigas poderia impedir a compilação contra as APIs 26.3. Esta correção foi feita por inspeção da documentação e do código, ainda sem compilador.
5. **Validador de assets:** corrigido o caminho padrão em `scripts/validar_assets.py`. Antes, executá-lo a partir da raiz do projeto procurava uma pasta `01_ASSETS_ORIGINAIS` inexistente; agora resolve a pasta `assets_originais/random stuff sprites` a partir da localização do próprio script.

## 3. Estrutura e compatibilidade declarada

- `fabric.mod.json`: modid `randomstuff`, Minecraft `~26.3`, Java `>=25`, Fabric Loader `>=0.19.5`.
- `gradle.properties`: Minecraft `26.3`, Loader `0.19.5`, Loom `1.18-SNAPSHOT`, Fabric API `0.163.0+26.3`.
- Gradle Wrapper presente (`gradlew`, `gradlew.bat`, JAR e properties).
- `build.gradle` usa source sets separados `main` e `client`, como o exemplo 26.3 fornecido.
- Entrypoints `RandomStuffMod` e `RandomStuffClient` existem.
- Quatro mixins declarados no `randomstuff.mixins.json` têm classes correspondentes.
- Todos os JSONs foram analisados sintaticamente; os modelos referenciados por blockstates e as texturas referenciadas por modelos foram encontrados. Uma checagem de cobertura separada confirmou os 61 blockstates/loot tables, os 60 modelos de item de blocos, os 17 itens comuns, 16 pincéis e 6 discos, além das traduções pt_br/en_us esperadas.
- As três texturas de equipamento de Ouro Rosa (humanoid, humanoid_leggings e horse_body) existem nos caminhos esperados.
- Os seis discos apontam para sons vanilla externos; a existência e o caminho desses sons na instalação real 26.3 ainda precisam ser testados no jogo.

**Limite importante:** as versões declaradas batem com o exemplo fornecido, mas nenhuma dependência foi baixada e nenhuma API Java foi validada pelo compilador. Portanto, compatibilidade real ainda não está comprovada.

## 4. Funcionalidades escritas no código atual

- Registros de blocos, itens, ferramentas/armaduras de Ouro Rosa, discos, pincéis e aba criativa.
- Blocos/variantes de lajes, escadas e muros descritos em `VariantList`.
- Abóbora Branca, Abóbora Branca Entalhada e Jack o'Lantern Branca.
- Bloco/farinha/osso de Wither.
- Plantação de cenoura dourada e conversão aleatória de cenouras maduras.
- Espada de ouro vanilla com alteração de atributos.
- Reparo de bigornas com blocos de ferro.
- Farinha de osso na cana-de-açúcar via mixin.
- Troncos descascados no cortador de pedra via receitas.
- Captura e soltura básica de Slime/Cubo de Magma, guardando tamanho, nome e vida.
- Proteção parcial de cabeças de mobs contra seleção de alvo.
- Pincéis coloridos e pintura de um conjunto de blocos.
- Ofertas do Mercador Ambulante.
- Loot adicional parcial em vilas/strongholds e molde de ferraria de Ouro Rosa.

Esses itens são classificados como **implementação escrita, não comprovada**. A existência de JSONs ou classes não comprova que o jogo os carregue ou que o comportamento esteja correto.

## 5. Incompleto em relação às especificações aprovadas

### Sistemas inteiros ainda ausentes ou parciais
- Funil de Cobre: bloco, filtro, oxidação, enceramento, inventário e variante em carrinho.
- Painel de Exposição com renderização própria e materiais vanilla.
- Molduras coloridas e Moldura Invisível.
- Água Colorida e tingimento por caldeirão.
- Moobloom e Moonlip: entidades, variantes, flores removíveis/regeneráveis, ovos e ciclo dia/noite do Olho-de-Cera.
- Raposa Negra e regras de spawn/ovo.
- Comportamentos adicionais de Slime/Magma Cube: quicar, flutuar, interagir/atacar, tingimento de Slime e efeitos de pouso.
- Absorções adicionais do Cubo de Enxofre (mel, fornalha, bancada, glowstone, redstone, esponja e bloco de ossos). TNT e magma são comportamento vanilla conforme as notas do projeto.
- Biomas Jardim Pálido ampliado, Floresta Salpicada, Cerejeira Bambuzal, atmosferas, spawns e geração natural.
- Encantamentos Lava Walker, Resistência à Lava e Queda de Penas.
- Ajustes de tridente, projéteis rebatíveis e pesca de criatura em barco.
- Beacon: Brilho e Respiração.
- Villager reparando/melhorando Golem de Ferro.
- Filtros de visão das cabeças no cliente.
- Correntes escaláveis, ligações de carrinhos (até 8), aceleração progressiva e barra.
- Suporte de blocos em lajes.
- Sono acelerando plantas, animais e fornalhas.
- Configuração de saturação (padrão 50).
- Lança de Ouro Rosa.

### Implementações parciais / lacunas conhecidas
- **Cabeças:** o mixin de `setTarget` não cobre a IA baseada em Brain dos Piglins; isso já é reconhecido no próprio código. Os filtros visuais ainda não existem.
- **Balde:** grava tamanho, nome e vida, mas não serializa todos os dados adicionais possíveis da entidade. Testar entidades nomeadas, tamanhos, vida, reload de mundo e multiplayer.
- **Loot:** as listas implementadas em `ModLootTables` cobrem apenas parte dos itens aprovados no briefing. Não marcar loot de vila/stronghold como concluído.
- **Pincéis:** não pintam entidades e ainda não usam Água Colorida. A recarga simplifica a durabilidade do pincel; precisa validar contra a regra aprovada.
- **Abóbora Branca:** a geração exclusiva no Jardim Pálido e a interação correta com golems ainda não estão implementadas.
- **Discos:** caminhos de áudio referenciam músicas vanilla e não foram testados na instalação 26.3.
- **Mercador:** os tipos escolhidos para “folhas” e “flores” foram assumidos no código (folhas de carvalho e dente-de-leão); a especificação original não fixa quais tipos.
- **Cenoura dourada:** o código usa 3% por random tick, valor escolhido na implementação; o briefing só define “pequena chance”.
- **Loot e molde:** chances 4%, 5%, 10% e probabilidades individuais foram escolhidas pelo implementador; precisam de aprovação/balanceamento.
- **Ouro Rosa:** valores de armadura 2/4/3/1 e alguns atributos de ferramentas foram escolhas do implementador, não especificações expressas. Não os trate como decisões aprovadas sem confirmação.

## 6. Pontos técnicos que exigem compilação/teste posterior

1. Confirmar nomes, assinaturas e visibilidade das APIs usadas em todas as classes Java contra os artefatos exatos do Minecraft 26.3/Fabric API.
2. Validar mixins: alvo, descritor, ponto de injeção e comportamento com `defaultRequire: 1`.
3. Executar cliente e servidor dedicado, abrir mundo novo e existente, abrir aba criativa, verificar receitas/loot/spawns e sair/reentrar com entidades/itens customizados.
4. Testar multiplayer para sincronização e autoridade do servidor.
5. Testar sons dos discos e renderização de equipamento.
6. Testar persistência do balde e falhas de spawn.
7. Adicionar testes automatizados onde as APIs permitirem; atualmente não existe `src/test`.
8. Testar desempenho com muitas entidades e operações de inventário.

## 7. O que foi efetivamente testado nesta rodada

| Verificação | Resultado |
|---|---|
| Extração dos três ZIPs | Concluída |
| JSON do projeto | 670 arquivos lidos, sem erro |
| PNGs de recursos | 150 cabeçalhos válidos |
| PNGs totais do projeto e cópias originais | 331 decodificados/verificados localmente, sem corrupção |
| Manifesto dos assets originais | 181/181 hashes e dimensões conferidos |
| Referências blockstate → modelo | Sem ausências encontradas |
| Referências modelo → textura | Sem ausências encontradas |
| Cobertura de blockstates, loot tables, modelos de item e traduções | Sem ausências encontradas nos IDs registrados |
| `scripts/validar_assets.py` (caminho padrão) | 181 PNGs, 0 erros |
| Entrypoints e mixins declarados | Classes encontradas |
| Script `validar_projeto.py` | Executado; 0 erros, 1 aviso |
| Compilação Gradle | **Não executada por solicitação** |
| Inicialização do Minecraft | Não testada |
| Mecânicas em singleplayer/multiplayer | Não testadas |

## 8. Estado para a próxima etapa

O projeto está organizado e passou pelas verificações estáticas disponíveis, mas **ainda não está pronto para ser declarado funcional**. O principal bloqueio técnico é a ausência de validação de compilação/API e de testes dentro do Minecraft. Além disso, diversos sistemas aprovados ainda não foram implementados.

A próxima etapa deve ser correção de incompatibilidades identificadas por compilador/runtime quando o usuário autorizar a compilação de diagnóstico. Até lá, manter este pacote sem JAR e sem publicação.


---

## Adendo de reconciliação — 08/11/2026

Na reexecução do validador nesta rodada, foram encontrados 8 caminhos de assets originais ausentes no ZIP do projeto (nomes com acentuação corrompida durante a extração). Os oito arquivos foram recuperados do pacote original `RandomStuff_Pacote_Claude_Replit.zip`, conferidos por SHA-256 e dimensões conforme o manifesto, e copiados para seus caminhos UTF-8 corretos. Os oito caminhos corrompidos/duplicados foram removidos.

Resultados após a correção:
- `scripts/validar_projeto.py`: 670 JSON, 150 PNGs de recursos, 181 assets no manifesto, 25 classes Java, 0 erros e 1 aviso (sem suíte `src/test`).
- `scripts/validar_assets.py`: 181 PNGs, 0 erros.

**Nota de escopo:** esta rodada corrigiu somente a reconciliação dos assets e atualizou a documentação. Não implementou novas mecânicas nem alterou fontes Java. Consulte `docs/RELATORIO_RODADA_2026-11-08.md` para o estado real dos nove grupos. Nenhuma compilação/JAR/publicação foi executada.
