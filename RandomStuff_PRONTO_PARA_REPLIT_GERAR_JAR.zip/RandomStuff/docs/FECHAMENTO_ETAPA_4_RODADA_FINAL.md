# Etapa 4 — rodada de implementação adicional

Data: 09/11/2026

## O que foi acrescentado nesta rodada (código-fonte, sem Java 25 e sem Minecraft)

- 16 blocos de Slime coloridos, um por `DyeColor`, registrados como `SlimeBlock` para herdar a física vanilla de bloco de slime.
- Modelos de bloco, estados, definições de item, loot tables, traduções pt_BR/en_US e 16 texturas próprias derivadas proceduralmente. Nenhum sprite original recebido foi sobrescrito.
- O sistema de pincéis coloridos agora reconhece `*_slime_block`, permitindo repintar um bloco de Slime com outra cor.
- Mixin de prevenção de dano de queda para Slime e Cubo de Magma, limitado a essas entidades e sem cancelar outras fontes de dano.

## Funcionalidades já presentes na base e preservadas

- Moobloom/Moonlip: entidade com variantes aleatórias, dados sincronizados, tosquia/drop, regeneração de 2.400 ticks, Eye-of-Wax dia/noite, reprodução mantendo espécie e renderer/camada floral dedicados.
- Raposa Negra: entidade baseada em Fox, registro/atributos, renderer e ovo contextual com callback para bloco e entidade; seleciona a entidade negra apenas na chave `minecraft:dappled_forest`.
- Baldes de Slime/Magma Cube: captura e soltura com tamanho, proporção de vida, nome simples e flags permitidas; entrega do balde antes de remover a entidade.
- Armor Trim de Ouro Rosa e assets existentes foram preservados.

## O que continua pendente — Etapa 4 NÃO declarada concluída

Não foi possível fechar honestamente todos os requisitos sem as assinaturas reais do Minecraft 26.3 e sem executar os testes que o usuário reservou para si:

1. Física completa de Slime/Magma Cube: quique de pouso, flutuação em água/lava, dano de água ao Magma Cube e interação com estalactites.
2. Combate recíproco Slime/Magma Cube, seleção de alvos, knockback variável por tamanho e empurrões/aterrissagem em outras entidades.
3. Tingimento dos próprios Slimes com persistência/sincronização e renderização por cor. Nesta rodada foram feitos os blocos coloridos, não o tingimento da entidade.
4. SpawnPlacements/validação de spawn terrestre e ajuste fino das frequências de Moobloom/Moonlip; biomas Eucalipto e Floresta Salpicada continuam sendo dependências da Etapa 5 e não foram simulados.
5. Conferência de API/renderer de Moobloom, Moonlip, Raposa Negra, Slime e Magma Cube contra o JAR real 26.3.
6. Testes de jogo, servidor dedicado e multiplayer — deliberadamente não executados conforme pedido.

## Verificações executadas

- `python3 scripts/validar_projeto.py`: 1.027 JSON lidos, 189 PNG de recursos, 73 classes Java, 0 erros e 1 aviso informativo (sem `src/test`).
- `python3 scripts/validar_assets.py`: 205 PNGs originais, 0 erros.
- Não foi executado Java/JDK 25, Gradle, compilação, `javap`, geração de JAR ou Minecraft.

**Conclusão:** entrega de código ampliada e checada estaticamente, mas a Etapa 4 permanece aberta pelos itens acima. Não avançar para a Etapa 5.

---

## ATUALIZAÇÃO POSTERIOR — fechamento da implementação de código (09/11/2026)

A lista de pendências acima descreve o estado anterior e foi superada pelas alterações desta rodada. A implementação de código agora inclui:

1. `AbstractCubeMobMixin`: seleção recíproca de alvos Slime/Magma Cube, ataque entre as espécies, empurrões por tamanho, quique de entidades que pousam no cubo, dano térmico leve ao pousar no Magma Cube, flutuação do Slime na água, flutuação do Magma Cube na lava e dano de água ao Magma Cube.
2. `SlimeFallDamageMixin`: cancela somente a fonte `DamageTypes.FALL`; fontes de estalagmite, estalactite e outros impactos não são canceladas.
3. `SlimeDyeing` + `SlimeColorAccess`: tingimento dos Slimes com os 16 corantes, estado sincronizado e persistente, herança de cor ao dividir, tint do renderer e preservação da cor nos baldes. Magma Cube não aceita corante.
4. `SlimeBlockDyeing` + `BrushPainting`: corante direto e pincéis podem tingir/repintar os 16 blocos SlimeBlock; o bloco vanilla também é origem válida.
5. `BucketCapture`/`CapturedSlimeBucketItem`: captura e soltura de Slime e Magma Cube pelo tipo base `AbstractCubeMob`, sem confundir as duas classes, preservando tamanho/vida/nome/flags e cor quando for Slime.
6. `SpawnPlacementsInvoker`: placements terrestres para Moobloom, Moonlip e Raposa Negra; pacotes vanilla de Slime/MagmaCube/Fox atualizados para 26.3.
7. Atualização dos validadores e do script de extração de referências 26.3.

### Estado final honesto

- **Implementação de código da Etapa 4:** concluída para os recursos descritos acima.
- **Integração de spawn na Floresta Salpicada:** preparada, mas depende do bioma da Etapa 5; a Etapa 5 não foi iniciada.
- **Validação de runtime:** não realizada por solicitação do usuário. Nenhum Java 25, Gradle, compilação, `javap` ou jogo foi executado.
- **Validação estática:** 0 erros nos dois validadores; mixins comuns/cliente parseados; 16 blocos coloridos com seus arquivos de dados completos.

Não marcar a etapa como testada ou compilada. O usuário fará a validação dentro do jogo.
