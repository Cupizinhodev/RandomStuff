# Relatório — Água Colorida (rodada final de implementação, 2026-11-08)

## Implementado
- Caldeirão próprio com 16 cores e níveis de água 1–3.
- Corante em caldeirão vanilla converte para água colorida sem perder o nível.
- O último corante aplicado substitui a cor anterior; não há mistura.
- Modelos e texturas próprios para as 48 combinações de cor e nível.
- Pincel colorido da mesma cor recarrega no caldeirão e consome um nível.
- Caldeirão de água normal remove a tinta do pincel e devolve um pincel comum, preservando a durabilidade de escavação.
- Itens com o componente vanilla `DYED_COLOR` podem ser tingidos diretamente no caldeirão colorido; cada item consome um nível. Isso cobre os itens vanilla preparados para receber cor por componente, como armaduras de couro.
- Caldeirão colorido possui loot de bloco para ser recuperado quando quebrado.
- Pintura de blocos compatíveis continua sendo feita pelo pincel colorido, com gasto de uma unidade de tinta por bloco e retorno ao pincel comum quando a tinta acaba.

## Regra de consumo
A pintura de um item consome um nível (um terço de um caldeirão cheio). A recarga ou lavagem de pincel também consome um nível.

## Único recurso de interação ainda pendente
- Restaurar a tinta com pincel colorido + corante correspondente na bancada/bigorna. Isso exige uma receita/interação dinâmica que preserve o componente `minecraft:damage` (durabilidade de escavação) e os dados de tinta do pincel. Uma receita JSON estática produz um item novo e zera a durabilidade; por isso, não foi adicionada uma receita que descarte o progresso da ferramenta. Também não foi usado o método de combinar itens nas mãos.

## Limites que exigem validação
- Não existe balde de água colorida no briefing; o caldeirão mantém as interações vanilla de baldes e frascos, que podem retirar/colocar água sem transportar a cor.
- A restauração de tinta com pincel + corante na bancada/bigorna ainda não foi implementada: uma receita estática reiniciaria também a durabilidade de escavação do pincel, e não vou introduzir essa perda ou um esquema alternativo de mãos sem confirmação. A recarga pela água colorida da mesma cor já funciona no código.
- Modelos, tintura de itens e interações precisam de teste dentro do cliente Minecraft 26.3.

## Restrições de execução
Nenhuma compilação Gradle, `javac`, `assemble` ou geração de JAR foi executada. Esta entrega passou apenas por verificações estáticas de arquivos, JSON, referências de recursos e integridade do ZIP.

## Atualização — recarga pela bigorna (08/11/2026)

Foi adicionada a recarga pela interface normal da bigorna: pincel colorido no slot esquerdo e corante correspondente no slot direito. O resultado é uma cópia do pincel com `Paint=64`; a cópia mantém os componentes originais, incluindo a durabilidade de escavação (`minecraft:damage`). Ao retirar o resultado, o jogo consome o pincel de entrada e uma unidade de corante, cobrando 1 nível de experiência. Não há interação com itens nas mãos.

Arquivos: `mixin/AnvilColoredBrushRefillMixin.java`, `mixin/ItemCombinerMenuAccessor.java`, `randomstuff.mixins.json`.

**Limite:** implementação estática, não compilada nem testada no jogo. O accessor dos inventários herdados e os campos internos do menu precisam ser confirmados contra os artefatos exatos do Minecraft 26.3. A alternativa de bancada não foi implementada porque o briefing permite bigorna OU bancada.
