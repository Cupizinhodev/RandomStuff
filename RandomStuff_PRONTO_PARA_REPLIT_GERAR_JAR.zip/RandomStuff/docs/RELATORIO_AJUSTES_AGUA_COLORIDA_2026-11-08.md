# Ajustes e limites — Água Colorida

A água colorida foi implementada como um bloco de caldeirão próprio, mantendo o caldeirão vanilla intacto. O bloco mantém o nível (1 a 3) e uma propriedade de cor (16 valores). Os modelos de cada nível usam texturas próprias por cor.

O uso de corante no caldeirão vanilla converte-o no caldeirão colorido; o uso de outro corante no caldeirão colorido substitui a cor atual. Um pincel colorido da mesma cor pode ser recarregado, consumindo um nível.

**Ainda não marcar como concluído:** não foi implementada a pintura direta de itens por imersão, pois a especificação original não define com precisão a lista de itens-alvo e a interação. A pintura de blocos continua usando o pincel já existente. Também falta validar os modelos no cliente Minecraft 26.3.
