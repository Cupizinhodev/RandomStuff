# Relatório técnico — Etapa 3 do Random Stuff

**Projeto:** Random Stuff  
**Alvo:** Minecraft Java 26.3 · Fabric Loader 0.19.5 · Fabric API 0.163.0+26.3 · Java 25  
**Mod ID:** `randomstuff`  
**Estado:** código-fonte consolidado e auditado estaticamente; ainda não compilado nem testado no Minecraft.

## Escopo da Etapa 3

A matriz `docs/PLANO_ETAPAS.md` define esta etapa como encantamentos, ajustes do tridente, Beacon e comportamento de Villager/Golem. A auditoria da base mais recente encontrou implementações para todos esses itens. Esta rodada não duplicou nem substituiu os sistemas já presentes; consolidou o estado e corrigiu os caminhos de oito assets originais cujos nomes estavam com codificação incorreta.

## Funcionalidades encontradas no código

### Encantamentos

- **Caminhante da Lava (`randomstuff:lava_walker`):** encantamento de botas, nível máximo 2, incompatível com Frost Walker. O efeito de dados `minecraft:location_changed` substitui a superfície de lava por blocos de magma ao caminhar.
- **Resistência à Lava (`randomstuff:lava_resistance`):** encantamento de armadura, nível máximo 2. `LavaResistance` procura o encantamento nas peças equipadas; os mixins evitam dano direto de lava e reutilizam a física de natação em água enquanto a entidade está na lava.
- **Queda de Penas:** usa o encantamento vanilla `minecraft:feather_falling`; não cria um encantamento duplicado. Os hooks evitam pisotear plantações, quebrar ovos de tartaruga e envelhecer/quebrar gelo frágil enquanto a entidade está apoiada nele. O dano de queda normal continua sendo aplicado ao pisar em plantações.

### Tridente e projéteis

- O ejetor dispara tridentes usando o dano-base e a potência de arremesso do tridente vanilla.
- Com Lealdade, o tridente retorna ao ejetor de origem e é reinserido no inventário; se não houver espaço, aguarda próximo ao ejetor. Se o ejetor tiver sido removido, o tridente cai no mundo.
- A colisão do tridente tem ajuste de raio.
- Espada, machado e pá podem rebater ovos, bolas de neve e cargas de vento.
- Pescar uma criatura que está como passageira de um barco desmonta a criatura sem destruir o barco.

### Beacon e Villager/Golem

- **Brilho:** aplica o efeito Glowing vanilla às criaturas vivas dentro do alcance do Beacon enquanto o efeito estiver ativo.
- **Respiração:** duplica a reserva de ar; não a renova infinitamente a cada pulso. Ao perder o efeito, a reserva é limitada ao máximo normal.
- Villagers adultos podem recolher e carregar um lingote de ferro, procurar um Golem de Ferro no último estágio de dano (até 25% de vida) e restaurar um estágio ao consumir o lingote.

## Correção de assets nesta rodada

O ZIP continha os bytes dos oito sprites, mas quatro caminhos da plantação de cenoura dourada e quatro caminhos do Ouro Rosa estavam com caracteres acentuados corrompidos. Foram criados os caminhos UTF-8 esperados pelo manifesto, copiando os PNGs originais sem reprocessar nem alterar seus pixels:

- `cenoura dourada plantação/estagio 1.png` a `estagio 4.png`
- `ouro rosa/armadura/ouro_rosa_calça_icon.png`
- `ouro rosa/ferramentas/lança_ouro_rosa_hotbar.png`
- `ouro rosa/ferramentas/lança_ouro_rosa_segurando.png`
- `ouro rosa/ferramentas/pá_ouro_rosa.png`

Assim, esses oito arquivos deixam de bloquear a validação de assets. As cópias com nomes corrompidos foram mantidas para preservar o conteúdo original do ZIP recebido.

## Arquivos/código relevantes já existentes

- `data/randomstuff/enchantment/lava_walker.json`
- `data/randomstuff/enchantment/lava_resistance.json`
- `feature/FeatherFalling.java`
- `feature/LavaResistance.java`
- `feature/TridentDispenser.java`
- `feature/BeaconEffects.java`
- `mixin/FarmBlockFeatherMixin.java`
- `mixin/TurtleEggFeatherMixin.java`
- `mixin/FrostedIceFeatherMixin.java`
- `mixin/LavaResistanceMixin.java`
- `mixin/LavaSwimMixin.java`
- `mixin/ThrownTridentDispenserMixin.java`
- `mixin/TridentCollisionMixin.java`
- `mixin/ProjectileReboundMixin.java`
- `mixin/FishingHookBoatMixin.java`
- `mixin/BeaconBlockEntityMixin.java`
- `mixin/EntityBeaconBreathingMixin.java`
- `mixin/LivingEntityBeaconBreathingMixin.java`
- `mixin/VillagerGolemRepairMixin.java`
- `mixin/VillagerIronIngotPickupMixin.java`

## Validação estática executada

- `python3 scripts/validar_projeto.py`: **943 JSONs**, **172 PNGs de recursos**, **181 assets do manifesto**, **69 classes Java**; **0 erros**, 1 aviso por ausência de suíte em `src/test`.
- `python3 scripts/validar_assets.py`: **197 PNGs encontrados**, **0 erros**.
- Os JSONs, PNGs e referências de mixin passaram pelas verificações estáticas do projeto.

## Testes ainda obrigatórios no Replit/Minecraft

Nenhum Gradle, compilação Java, JAR, `runClient`, servidor dedicado ou teste dentro do jogo foi executado nesta rodada. O Replit ainda precisa confirmar as assinaturas/API de 26.3 e executar os testes descritos em `TAREFAS_REPLIT.txt`. Em especial, conferir a assinatura do mixin de natação na lava, a persistência/retorno do tridente, o comportamento dos efeitos do Beacon, o tick do gelo frágil e a navegação/consumo de lingote dos Villagers.

**Conclusão:** a Etapa 3 está presente no código-fonte da base recebida e passou na auditoria estática, mas não pode ser declarada concluída/funcional até compilar e testar no Minecraft 26.3.
