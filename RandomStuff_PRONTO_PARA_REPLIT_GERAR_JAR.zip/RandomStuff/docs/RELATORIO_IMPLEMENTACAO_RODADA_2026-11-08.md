# Random Stuff — Relatório de implementação incremental

Data: 08/11/2026  
Alvo: Minecraft Java 26.3 · Java 25 · Fabric · modid `randomstuff`

## Escopo executado nesta rodada

Foi implementada a parte de **cabeças de criaturas** que estava tecnicamente bem definida e tinha protótipos visuais fornecidos:

1. **Piglin / Brain:** criado `PiglinAiMixin`, que intercepta o resultado da busca central de alvo do Piglin. Quando o alvo encontrado é um jogador usando `PIGLIN_HEAD`, a busca retorna vazia. Isso cobre a rota de aquisição por Brain, que não passa por `Mob#setTarget`, e também filtra um alvo que ainda esteja guardado como memória de raiva quando a IA recalcula o alvo.
2. **Filtros visuais:** os cinco protótipos GLSL foram copiados para os recursos ativos do mod: Esqueleto, Creeper, Zumbi, Piglin e Dragão do End.
3. **Formato 26.3:** os JSONs foram colocados em `assets/randomstuff/post_effect/` (singular), que é o caminho de recurso de post effects. O nome do sampler foi alinhado com `InSampler`, que é o uniforme utilizado pelos fragment shaders fornecidos.
4. **Ativação local:** `RandomStuffClient` verifica o item equipado no slot da cabeça a cada tick e mantém apenas o post effect correspondente entre os cinco efeitos do mod. Os demais post effects de outros mods/pacotes não são removidos.
5. **Limpeza:** ao retirar a cabeça ou sair do mundo, o filtro do Random Stuff deixa de ser solicitado.

## Arquivos Java criados/modificados

- Criado `src/main/java/com/randomstuff/mixin/PiglinAiMixin.java`.
- Modificado `src/client/java/com/randomstuff/client/RandomStuffClient.java`.
- Modificado `src/main/resources/randomstuff.mixins.json` para registrar o mixin Piglin.
- Modificado `src/main/resources/fabric.mod.json` para declarar o arquivo de mixins do cliente.
- Criado `src/main/resources/randomstuff.client.mixins.json` (sem mixins client-side por enquanto).

## Recursos adicionados

- `assets/randomstuff/post_effect/esqueleto.json`
- `assets/randomstuff/post_effect/creeper.json`
- `assets/randomstuff/post_effect/zumbi.json`
- `assets/randomstuff/post_effect/piglin.json`
- `assets/randomstuff/post_effect/dragao_do_end.json`
- Cinco fragment shaders correspondentes em `assets/randomstuff/shaders/post/`.

Os arquivos de referência em `referencia/filtros_visuais_prototipo/` foram mantidos; os originais não foram apagados nem sobrescritos.

## Estado real dos sistemas solicitados

| Sistema | Estado nesta versão | Observação |
|---|---|---|
| Cabeças — proteção de espécie | Parcial | Zumbi, Esqueleto, Creeper, Piglin e Wither Skeleton já tinham o filtro por `setTarget`; agora há filtro adicional para aquisição por Brain do Piglin. Ainda faltam validação em jogo e revisão de outros caminhos de retaliação. |
| Cabeças — filtros visuais | Implementação escrita, não testada | Os cinco post effects estão integrados ao carregamento de recursos e a seleção é feita no cliente. GLSL e pipeline ainda precisam de teste real no 26.3. |
| Funil de Cobre | Pendente | Oxidação, cera, filtro, inventário, velocidade e variante de carrinho. |
| Água Colorida / caldeirões | Pendente | Estado de cor, interação com corantes, consumo e tingimento de objetos. |
| Painel de Exposição / molduras | Pendente | Block entities, renderização e persistência. |
| Moobloom / Moonlip | Pendente | Assets existem, mas mapeamento final de corpos/variantes e camada de flor requer confirmação; há uma dúvida explícita em `PLANO_ETAPAS.md`. |
| Raposa Negra | Pendente | Textura original existe; variante/spawn e renderer ainda não implementados. |
| Slime / Cubo de Magma | Parcial | Captura/soltura com tamanho, nome e vida já existia. Quicar, flutuar, ataques, tingimento do Slime e efeitos de pouso não foram implementados nesta rodada. |
| Absorções do Cubo de Enxofre | Pendente | TNT e magma são vanilla; absorções extras requerem verificar o formato real de arquétipo 26.3. |
| Biomas / atmosferas / geração | Pendente | Nenhum bioma customizado foi registrado nesta rodada. |
| Encantamentos / tridente / lança | Pendente | Não foram registrados nem implementados nesta rodada. |
| Beacon / Villager / Golem | Pendente | Não foram implementados nesta rodada. |
| Correntes / carrinhos | Pendente | Composições, limite 8, aceleração e HUD ainda sem código. |
| Sono / saturação | Pendente | Não há configuração implementada; padrão 50 ainda pendente. |

## Verificações estáticas realizadas

- `scripts/validar_projeto.py`: 676 JSON lidos; 150 PNGs de recursos; 181 assets originais; 26 classes Java; 0 erros e 1 aviso (sem `src/test`).
- `scripts/validar_assets.py`: 181 PNGs de assets originais; 0 erros.
- Parser JSON da biblioteca padrão: 675 JSON em `src/main/resources`; 0 erros.
- Verificação de presença: cada um dos cinco post effects tem JSON e shader correspondente; cada JSON aponta para `randomstuff:post/<id>` e usa `InSampler`.

## Compatibilidade / limitações conhecidas

- Minecraft 26.3 introduziu `/posteffect` e recursos de post effect no cliente. O servidor não pode garantir que o cliente tenha o recurso visual correspondente; os shaders precisam estar presentes no cliente. Referência: notas oficiais de Minecraft 26.3.
- `GameRenderer#getRequestedPostEffects()` é usado para adicionar/remover os IDs do mod no cliente. A compilação está proibida nesta tarefa, então assinatura/visibilidade e comportamento real ainda não foram confirmados pelo compilador do projeto.
- A busca central `PiglinAi.findNearestValidAttackTarget(ServerLevel, Piglin)` existe no source surface 26.3 consultado. O descriptor Mixin ainda precisa ser confirmado na execução do Mixin no jogo.
- A proteção por cabeça não foi ampliada para espécies além das previstas no código anterior; Dragão do End continua excluído da proteção, conforme briefing.

## Não executado

- Nenhuma compilação (`gradle build`, `assemble`, wrapper ou equivalente).
- Nenhuma geração de JAR.
- Nenhum teste dentro do Minecraft, singleplayer ou servidor dedicado.
- Nenhuma publicação.

## Próxima etapa sugerida

Começar pelo **Funil de Cobre** somente após conferir as assinaturas e os componentes de hopper do 26.3; em seguida, implementar Água Colorida. Não marcar nenhum desses sistemas como concluído até haver lógica funcional, persistência e teste real.
