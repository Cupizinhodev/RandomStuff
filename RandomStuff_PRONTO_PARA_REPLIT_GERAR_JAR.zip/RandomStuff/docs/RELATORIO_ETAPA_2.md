# Relatório técnico — Etapa 2 do Random Stuff

**Data:** 08/11/2026  
**Projeto:** Random Stuff  
**Minecraft:** 26.3  
**Fabric Loader:** 0.19.5  
**Fabric API:** 0.163.0+26.3  
**Java:** 25  
**Fabric Loom:** 1.18-SNAPSHOT  
**Mod ID:** `randomstuff`  
**Pacote:** `com.randomstuff`

## 1. Base preservada

A atualização foi aplicada sobre o projeto extraído de `RandomStuff_Etapa_2.zip`, sem iniciar outro projeto. Os arquivos existentes de código, dados, modelos, texturas, receitas, registros e documentação foram preservados. As alterações se concentram em novos mixins/funcionalidades, no registro de mixins, nas traduções dos efeitos e neste relatório.

## 2. Resultado por funcionalidade

### 2.1 Tridente e ejetores

Foi criado `TridentDispenser`, que registra um comportamento para o tridente no ejetor e usa a interface `ProjectileItem` do Minecraft para criar e disparar o projétil. O disparo usa `TridentItem.PROJECTILE_SHOOT_POWER`, incerteza 1 e `TridentItem.BASE_DAMAGE`, mantendo a potência e o dano-base do arremesso do jogador.

`TridentCollisionMixin` aumenta em 0,15 o raio de seleção de colisão somente para `ThrownTrident`. Quando o item possui Lealdade, `ThrownTridentDispenserMixin` detecta o impacto em entidade ou bloco, desativa a colisão física durante o retorno e conduz o tridente até o ejetor de origem. Ao chegar, o item é colocado no primeiro espaço vazio do inventário do ejetor. Se o ejetor tiver sido removido, o tridente é solto no mundo; se estiver cheio, o tridente aguarda ao lado dele até haver espaço. A posição do ejetor e o estado de retorno são gravados nos dados salvos do projétil.

### 2.2 Rebater ovos, bolas de neve e cargas de vento

`ProjectileReboundMixin` permite que o jogador rebata ovos, bolas de neve e cargas de vento ao atacar com espada, machado ou pá. A deflexão ocorre no servidor, inverte a trajetória e atribui o jogador como proprietário do projétil.

### 2.3 Pesca de criaturas em barcos

`FishingHookBoatMixin` detecta quando o anzol atinge uma entidade que está como passageira de um barco e desmonta a criatura para que ela possa ser puxada. O barco não é removido por essa lógica.

### 2.4 Beacon Brilho

`BeaconEffects` registra o efeito próprio `randomstuff:beacon_glowing`. `BeaconBlockEntityMixin` acrescenta o efeito à lista de opções válidas do Beacon e atualiza o conjunto de efeitos aceitos pelo bloco. O efeito é apresentado com o ícone `beacon_glowing.png` já existente. Enquanto o Beacon tem feixe ativo e Brilho está selecionado como efeito primário ou secundário, o servidor aplica `MobEffects.GLOWING` às entidades vivas dentro do alcance horizontal e vertical do Beacon. A duração é renovada periodicamente, sem depender de o alvo ser jogador.

### 2.5 Beacon Respiração

`BeaconEffects` também registra `randomstuff:beacon_breathing`, integrado às opções válidas do Beacon e à tela vanilla, usando o ícone `beacon_breathing.png` existente. `EntityBeaconBreathingMixin` duplica `getMaxAirSupply` enquanto o efeito está ativo. `LivingEntityBeaconBreathingMixin` preenche a reserva dobrada uma única vez na transição de ausência para presença do efeito; a renovação periódica do Beacon não restaura o ar, evitando respiração infinita. Ao terminar o efeito, a reserva é limitada ao máximo normal.

### 2.6 Villagers reparando Golems

`VillagerIronIngotPickupMixin` permite que Villagers recolham lingotes de ferro, respeitando o espaço disponível no inventário. `VillagerGolemRepairMixin` reserva um lingote e faz o Villager procurar um Golem de Ferro vivo com no máximo 25% da vida máxima, correspondente ao último estágio de dano. Ao chegar perto, o Villager consome o lingote e restaura 25% da vida máxima do Golem, avançando um estágio. O lingote é exibido na mão do Villager durante a tarefa e tem drop garantido caso ele morra antes de concluir o reparo.

### 2.7 Natação na lava

`LavaSwimMixin`, com apoio de `LivingEntityTravelInvoker`, redireciona a rotina de deslocamento na lava para a rotina vanilla de natação em água quando `LavaResistance.protects(entity)` retorna verdadeiro. Entidades sem a proteção continuam usando a rotina normal de lava. A proteção existente contra dano direto de lava foi mantida.

### 2.8 Queda de Penas e gelo frágil

`FrostedIceFeatherMixin` verifica se uma entidade viva com Queda de Penas está apoiada sobre o bloco de gelo frágil. Enquanto estiver sobre ele, o tick de envelhecimento é cancelado e reagendado para 20 ticks depois. Assim, a proteção permanece enquanto a entidade pisa no gelo, mas o bloco volta a envelhecer normalmente depois que ela sai. A quebra manual/mineração do bloco não é bloqueada.

## 3. Arquivos novos

- `src/main/java/com/randomstuff/effect/BeaconMarkerEffect.java`
- `src/main/java/com/randomstuff/feature/BeaconEffects.java`
- `src/main/java/com/randomstuff/feature/TridentDispenser.java`
- `src/main/java/com/randomstuff/mixin/BeaconBlockEntityAccessor.java`
- `src/main/java/com/randomstuff/mixin/BeaconBlockEntityMixin.java`
- `src/main/java/com/randomstuff/mixin/EntityBeaconBreathingMixin.java`
- `src/main/java/com/randomstuff/mixin/LivingEntityBeaconBreathingMixin.java`
- `src/main/java/com/randomstuff/mixin/DispenserTridentAccess.java`
- `src/main/java/com/randomstuff/mixin/AbstractArrowAccess.java`
- `src/main/java/com/randomstuff/mixin/ThrownTridentDispenserMixin.java`
- `src/main/java/com/randomstuff/mixin/TridentCollisionMixin.java`
- `src/main/java/com/randomstuff/mixin/VillagerGolemRepairMixin.java`
- `src/main/java/com/randomstuff/mixin/VillagerIronIngotPickupMixin.java`

## 4. Arquivos alterados

- `src/main/java/com/randomstuff/RandomStuffMod.java` — inicializa os efeitos de Beacon e o comportamento de tridente.
- `src/main/java/com/randomstuff/mixin/FrostedIceFeatherMixin.java` — protege o gelo enquanto a entidade está apoiada nele e reagenda o tick.
- `src/main/java/com/randomstuff/mixin/ProjectileReboundMixin.java` — removido import inválido que não era utilizado.
- `src/main/resources/randomstuff.mixins.json` — novas classes de mixin adicionadas; entradas anteriores preservadas.
- `src/main/resources/assets/randomstuff/lang/pt_br.json` e `en_us.json` — nomes dos efeitos Brilho e Respiração.
- `docs/PROGRESSO.md` e este relatório — atualizados para refletir o código atual.

## 5. Referências de API consultadas

Foram consultadas referências Java 26.3 para validar nomes e assinaturas de `BeaconBlockEntity`, `BeaconMenu`, `MobEffect`, `ProjectileItem`, `ProjectileItem.DispenseConfig`, `TridentItem`, `ThrownTrident`, `AbstractArrow`, `Entity`, `ValueInput`, `ValueOutput`, `Villager`, `Mob`, `IronGolem` e `FrostedIceBlock`.

As referências usadas são Javadocs da linha 26.3 e documentação de código-fonte de Minecraft 26.3. Como parte delas é publicada para NeoForge, ela confirma a API vanilla/Mojang mapeada, mas não comprova a compatibilidade de runtime com Fabric Loader 0.19.5.

## 6. Verificações realizadas

- JSON de `randomstuff.mixins.json`, `fabric.mod.json` e arquivos de idioma analisado sintaticamente.
- Ausência de nomes duplicados na lista de mixins.
- Todos os arquivos Java referenciados na lista de mixins estão presentes e possuem anotação `@Mixin`.
- Os dois ícones do Beacon estão presentes no caminho esperado.
- Chamadas de inicialização de `BeaconEffects` e `TridentDispenser` presentes no ponto de entrada do mod.
- Delimitadores básicos dos novos arquivos Java conferidos.
- Executado `scripts/validar_projeto.py`: 943 JSONs lidos, 172 PNGs de recursos verificados, 181 entradas no manifesto e 69 classes Java encontradas. O script apontou 8 assets ausentes da pasta `assets_originais`; os mesmos 8 caminhos também não existem no ZIP-base recebido, confirmando que são pendências preexistentes e não causadas por esta rodada. Não houve erros de JSON, PNG, entrypoint ou referência de mixin nesse relatório.

## 7. Testes não executados

Conforme a restrição definida para esta etapa, **não** foram executados Gradle, compilação Java, geração de JAR, inicialização do Minecraft nem testes dentro de mundo/servidor. Portanto, não afirmo que o código passou por build ou teste de runtime.

## 8. Conclusão

As oito funcionalidades da lista da Etapa 2 agora têm implementação de código-fonte na árvore do projeto, incluindo os quatro pontos que estavam pendentes e a correção da proteção de pisada no gelo frágil. O estado é **implementado estaticamente, ainda não validado por compilação ou teste no Minecraft**. A próxima validação real depende de executar o projeto no ambiente Fabric 26.3 e observar eventuais erros de mapeamento, mixin ou comportamento.
