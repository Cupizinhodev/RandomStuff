# Vacas florais — rodada de implementação (08/11/2026)

## Regra de assets

- Os arquivos de `assets_originais/random stuff sprites/vacas/` e `textures/entity/flower_cow/` são recursos visuais das entidades Moobloom/Moonlip.
- Somente os registros já presentes em `ModBlocks` (`buttercup`, `pink_daisy`, `magenta_tulip`) são flores reais do mundo nesta etapa.
- Os overlays em `textures/entity/flower_cow/overlay/` não são registrados como blocos nem itens de flor.

## Implementado nesta rodada

- Criada `FlowerCowEntity`, base comum para as duas espécies, mantendo o comportamento de vaca.
- Variante (9 Moobloom / 7 Moonlip) e estado de flores sincronizados pela `SynchedEntityData`.
- Variante e estado de flores gravados/carregados junto aos dados da entidade.
- Interação com tesoura: remove a flor correspondente, solta o item correspondente e causa desgaste na tesoura.
- Regeneração após 2.400 ticks (2 minutos de jogo), com contador persistido.
- `ModEntities` agora instancia `FlowerCowEntity` para Moobloom e Moonlip; ovos e geração natural existentes continuam apontando para esses tipos.

## Pendente — não declarar concluído

- **Renderização das flores 3D no corpo**, no estilo da Mooshroom: a matriz de texturas está pronta, mas o `CowRenderer` atual ainda não consome o estado de variante nem desenha a camada floral. A classe guarda e sincroniza os dados necessários, mas a camada visual ainda precisa ser implementada e validada.
- Seleção correta das texturas corporais para cada variante e alternância dia/noite do Eye-of-Wax.
- Revisar a tabela de drops para as variantes que usam itens de flor customizados e confirmar a representação final de Eye-of-Wax.
- Geração natural nos biomas customizados Eucalyptus/Speckled Forest quando esses biomas forem implementados.
- Teste real de tesoura, sincronização, persistência e regeneração dentro do Minecraft.

## Verificações

`validar_projeto.py` e `validar_vacas_florais.py` fazem verificações estáticas. Nenhuma compilação Gradle/Javac foi executada; nenhum JAR foi gerado. Portanto, não há confirmação de compilação ou funcionamento em jogo.


## Ajuste solicitado — tempo de regeneração

- O tempo de regeneração foi reduzido de 20 para **2 minutos de jogo** (2.400 ticks).
- A contagem continua persistida no NBT da entidade e só avança enquanto a entidade está sendo tickada no mundo.


## Complemento visual — 2026-11-08

Foi adicionado renderer dedicado com seleção das texturas corporais por variante/idade, flor 3D baseada no modelo do bloco da variante, ocultação ao tosquiar e abertura/fechamento diurno/noturno do Eye-of-Wax. A confirmação definitiva depende de compilação autorizada e teste no cliente 26.3; nenhuma compilação foi executada nesta rodada.
