# Inventário de assets (Etapa 0)

Total recebido: 181 PNGs. Copiados para `src/main/resources/assets/randomstuff/textures/`
(com nomes ASCII minúsculos exigidos pelo Minecraft): **149**. Todos conferidos byte a byte (0 divergências).
Mapa completo original → destino: `docs/MAPA_ASSETS.csv`. Originais intactos em `assets_originais/`.

Não copiados (32): `trilhos/` (10, descartados), `tijolos_coloridos/` (16, escopo NÃO consta no briefing),
`imagens para referencia/` (6, só referência visual).

## Presentes
Abóbora Branca (4), cenoura dourada (4 estágios), 6 discos, 3 flores, Funil de Cobre (4 estados x 3 faces),
Osso/Farinha/Bloco de Osso de Wither, Ouro Rosa (itens, bloco, bruto, ferramentas, armadura, cavalo, molde),
16 molduras (mundo) + 16 ícones, ícone Moldura Invisível, 16 pincéis, Raposa Negra (48x32), baldes de Slime/Magma,
textura da corrente, ovos Moobloom/Moonlip, corpos de vaca (adulto/bebê) em 10 cores + variante cinza aberta, 16 flores sobrepostas.

## Ausentes ou a confirmar
1. **Cubo de Enxofre / Sulfur Cube**: o briefing o cita (absorções), mas não há assets nem especificação de base. É mob de outra fonte; preciso saber se já existe em 26.3 vanilla ou se é do mod.
2. **Funil de Cobre em Carrinho**: sem sprite próprio (usar vanilla de carrinho + modelo do funil de cobre).
3. **Mapeamento variante → corpo de vaca**: há 10 cores de corpo para 9 + 7 variantes (ex.: Buttercup e Dente-de-leão = corpo amarelo; Azure Bluet e Lírio = branco). Não há corpo "papoula" separado do vermelho nem "tulipa" separada: proposta em `PLANO_ETAPAS.md`.
4. **Olho-de-Cera**: 4 corpos cinza (adulto/bebê, fechado/aberto) + 2 flores 16x16. Mapeado como `body_cinza_{adult,baby}[_open]`.
5. **Texturas vanilla** (Painel de Exposição, filtros, ícones do Beacon, etc.): não são do pacote; serão referenciadas, não criadas.
6. **Cenoura dourada**: faltam itens/ícones (usar vanilla ou novo sprite?).
7. **Nomes com erros de digitação** (whiter, ligote, pritoral, infocacao): corrigidos só nas cópias, via mapa.


## Correção de caminhos UTF-8 — Etapa 4 (2026-11-09)

Na auditoria do ZIP de sprites, foram encontrados 8 arquivos cujos nomes com acentos não estavam presentes em `assets_originais/` com a grafia UTF-8 esperada: quatro estágios da cenoura dourada e quatro sprites (calça, lança hotbar, lança em mão e pá) de Ouro Rosa. Os PNGs correspondentes já estavam no pacote `random stuff sprites.zip` e as texturas correspondentes já existiam em `src/main/resources`. Os arquivos-fonte foram restaurados em `assets_originais/` a partir do ZIP de sprites, sem reprocessamento. SHA-256 e dimensões foram conferidos; os bytes das oito texturas do mod são idênticos aos sprites originais. `scripts/validar_projeto.py` passou com 0 erros após a restauração.
