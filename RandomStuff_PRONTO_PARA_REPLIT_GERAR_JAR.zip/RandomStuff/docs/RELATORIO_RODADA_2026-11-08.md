# Relatório técnico da rodada — Random Stuff
**Data:** 08/11/2026  
**Base:** `RandomStuff_Auditado_Preparado_Sem_Compilar_Revisao.zip`  
**Referências comparadas:** `RandomStuff_Pacote_Claude_Replit.zip` e `fabric-example-mod-26.3.zip`  
**Alvo declarado:** Minecraft Java 26.3+, Java 25, Fabric Loader 0.19.5, Fabric API 0.163.0+26.3  
**Estado:** auditoria/reconciliação de assets e preparação. **NÃO COMPILADO, NÃO GERADO JAR, NÃO PUBLICADO e NÃO TESTADO NO JOGO.**

## 1. Resultado desta rodada

O projeto-base já era um projeto Fabric estruturado e continha código de etapas anteriores. Não foi refeito do zero. Os documentos de especificação e o manifesto de assets do pacote de referência foram comparados com os documentos presentes no projeto.

Foi encontrada uma divergência real no inventário de assets: 8 dos 181 arquivos originais estavam presentes com nomes de caminho corrompidos por decodificação de caracteres UTF-8. Os 8 arquivos corretos foram recuperados do pacote de assets fornecido, copiados para os caminhos previstos no manifesto e os 8 caminhos duplicados/corrompidos foram removidos. **Os bytes dos PNGs recuperados correspondem ao SHA-256 e às dimensões declaradas no manifesto.** Os outros 173 assets já correspondiam ao manifesto.

O template `fabric-example-mod-26.3.zip` foi usado apenas para comparar a configuração Gradle/Fabric. As versões declaradas no projeto Random Stuff coincidem com as do template: Minecraft 26.3, Loader 0.19.5, Loom 1.18-SNAPSHOT, Fabric API 0.163.0+26.3 e Java 25. Nenhuma tarefa Gradle foi executada.

## 2. Correção de assets

**Arquivos recuperados em `assets_originais/random stuff sprites/`:**
- `cenoura dourada plantação/estagio 1.png`
- `cenoura dourada plantação/estagio 2.png`
- `cenoura dourada plantação/estagio 3.png`
- `cenoura dourada plantação/estagio 4.png`
- `ouro rosa/armadura/ouro_rosa_calça_icon.png`
- `ouro rosa/ferramentas/lança_ouro_rosa_hotbar.png`
- `ouro rosa/ferramentas/lança_ouro_rosa_segurando.png`
- `ouro rosa/ferramentas/pá_ouro_rosa.png`

Os caminhos dos 8 arquivos no projeto de recursos (`src/main/resources/assets/randomstuff/textures/`) já estavam mapeados para nomes internos normalizados e os destinos estavam presentes. Esta correção restaura a cópia original arquivada e corrige a reconciliação do manifesto; não redesenha nem modifica os PNGs.

## 3. Estado real por grupo aprovado

A classificação abaixo descreve código/recursos encontrados, não funcionamento comprovado.

| Grupo | Estado | Implementação existente / pendências principais |
|---|---|---|
| 1. Blocos e utilidades | **Parcial** | Abóbora Branca, Ouro Rosa, Osso de Wither e variantes de lajes/escadas/muros estão escritos. Funil de Cobre (filtro, oxidação, cera e carrinho), Painel de Exposição e suporte em lajes continuam ausentes. |
| 2. Água Colorida, molduras e pincéis | **Parcial** | 16 pincéis e pintura de um conjunto de blocos estão escritos. Água Colorida, tingimento por caldeirão, recarga conforme especificação completa, pintura de entidades, molduras coloridas e Moldura Invisível colocada no mundo ainda não estão implementados. |
| 3. Entidades e criaturas | **Não implementado no código atual** | Há assets de vacas/floras e raposa negra, mas não há classes de Moobloom, Moonlip ou Raposa Negra nem renderização/ciclo de flor/spawns. A captura básica de Slime/Magma é classificada no grupo 4. |
| 4. Slimes e Cubos de Magma | **Parcial** | Captura/soltura básica com tamanho, nome e vida está escrita. A persistência de todos os dados relevantes, quique, flutuação, ataques, tingimento de Slime e efeitos de aterrissagem precisam de implementação/testes. O Cubo de Enxofre é vanilla desde 26.2; absorções adicionais aprovadas seguem ausentes. |
| 5. Biomas e geração natural | **Parcial** | Cenoura dourada, parte de loot e ofertas do Mercador Ambulante estão escritos. Jardim Pálido ampliado, Floresta Salpicada, Cerejeira Bambuzal, atmosferas, spawns e geração natural exclusiva ainda faltam. |
| 6. Encantamentos e equipamentos | **Parcial** | Ferramentas/armadura Ouro Rosa e molde estão escritos; a Lança de Ouro Rosa falta. Lava Walker, Resistência à Lava, Queda de Penas, ajustes de tridente, projéteis rebatíveis e pesca de criaturas em barcos faltam. |
| 7. Beacon, Villagers e Golems | **Ausente** | Brilho/Respiração do Beacon e reparo/melhoria de Golems por Villagers não foram encontrados implementados. |
| 8. Cabeças de criaturas | **Parcial** | Filtro de alvo por `setTarget` está escrito para parte das espécies. Piglins com IA Brain não estão cobertos e os filtros visuais de tela não existem. |
| 9. Correntes, carrinhos, sono e configurações | **Ausente/parcial** | Textura de corrente existe, mas correntes escaláveis, ligações de até 8 carrinhos, aceleração progressiva, barra e sincronização não estão implementadas. Farinha de osso na cana já está escrita; aceleração do sono e configuração de saturação padrão 50 faltam. |

**Conclusão:** nenhum dos nove grupos pode ser declarado completo com base no código atual. Não foi acrescentada implementação de mecânicas nesta rodada, porque a análise revelou lacunas grandes e pontos técnicos que exigem verificação das APIs exatas 26.3 antes de escrever código especulativo.

## 4. Java existente

25 arquivos Java encontrados. **Nenhum arquivo Java foi criado ou modificado nesta rodada.**

- `src/main/java/com/randomstuff/RandomStuffMod.java`
- `src/main/java/com/randomstuff/registry/ModBlocks.java`
- `src/main/java/com/randomstuff/registry/VariantList.java`
- `src/main/java/com/randomstuff/registry/ModBrushes.java`
- `src/main/java/com/randomstuff/registry/ModItems.java`
- `src/main/java/com/randomstuff/registry/ModCreativeTabs.java`
- `src/main/java/com/randomstuff/registry/ModDiscs.java`
- `src/main/java/com/randomstuff/registry/ModEquipment.java`
- `src/main/java/com/randomstuff/block/GoldenCarrotsBlock.java`
- `src/main/java/com/randomstuff/block/WhitePumpkinBlock.java`
- `src/main/java/com/randomstuff/block/CarvedWhitePumpkinBlock.java`
- `src/main/java/com/randomstuff/world/ModLootTables.java`
- `src/main/java/com/randomstuff/item/CapturedSlimeBucketItem.java`
- `src/main/java/com/randomstuff/item/ColoredBrushItem.java`
- `src/main/java/com/randomstuff/mixin/SugarCaneBlockMixin.java`
- `src/main/java/com/randomstuff/mixin/MobTargetMixin.java`
- `src/main/java/com/randomstuff/mixin/CropBlockMixin.java`
- `src/main/java/com/randomstuff/mixin/ItemEntityMixin.java`
- `src/main/java/com/randomstuff/feature/AnvilRepair.java`
- `src/main/java/com/randomstuff/feature/GoldSwordBuff.java`
- `src/main/java/com/randomstuff/feature/WanderingTraderTrades.java`
- `src/main/java/com/randomstuff/feature/BrushPainting.java`
- `src/main/java/com/randomstuff/feature/BucketCapture.java`
- `src/main/java/com/randomstuff/feature/MobHeads.java`
- `src/client/java/com/randomstuff/client/RandomStuffClient.java`

## 5. Verificações estáticas executadas nesta rodada

| Verificação | Resultado |
|---|---|
| `scripts/validar_projeto.py` | **0 erros, 1 aviso** |
| JSON | 670 arquivos lidos sem erro de sintaxe |
| PNGs de recursos | 150 válidos |
| Manifesto de assets originais | 181/181 presentes, hashes/dimensões conferidos após recuperação |
| `scripts/validar_assets.py` | 181 PNGs, 0 erros |
| Classes Java | 25 encontradas |
| Aviso | Não existe suíte automatizada em `src/test` |
| Comparação do template 26.3 | versões declaradas de Minecraft/Fabric/Java correspondentes |

Essas verificações não validam assinaturas de métodos Java, Mixins em runtime, inicialização do jogo, renderização, sincronização ou mecânicas.

## 6. Dúvidas e decisões que precisam de confirmação

1. **Cubo de Enxofre:** confirmado nas notas do projeto como entidade vanilla desde 26.2. As absorções TNT e bloco de magma já são vanilla; não duplicar. As novas absorções mel, fornalha, bancada, glowstone, redstone, esponja e bloco de ossos exigem extensão específica.
2. **Mapeamento de variantes de vacas:** o plano anterior propõe associar flores a corpos por cor, mas essa associação ainda precisa de aprovação antes de implementar as variantes.
3. **Mercador Ambulante:** o briefing diz “folhas” e “flores” sem especificar todos os tipos; o código existente escolheu alguns itens. Confirmar se essas escolhas são aceitas.
4. **Chance da cenoura dourada:** o código usa 3% por random tick; o briefing diz apenas “pequena chance”. Confirmar se 3% é aprovado.
5. **Probabilidades de loot e molde:** os valores numéricos atuais foram escolhidos pelo implementador, não fixados no briefing.
6. **Ouro Rosa:** alguns atributos/defesas de armadura foram escolhas de implementação e não decisões explícitas do briefing.
7. **Saturação visual:** padrão 50 está definido, mas é necessário confirmar a interpretação da escala (por exemplo, 0–100) antes de implementar a opção de configuração.

## 7. Limitações e próximos passos

- Confirmar APIs e assinaturas 26.3 com documentação/artefatos exatos antes de implementar entidades, renderers, worldgen, encantamentos, inventários, telas e mixins.
- Implementar por etapas pequenas e atualizar esta matriz após cada etapa.
- Resolver as dúvidas acima antes de codificar as mecânicas afetadas.
- Quando houver autorização explícita, fazer compilação de diagnóstico e testes reais em cliente e servidor. **Até essa autorização, não executar Gradle nem gerar JAR.**

## 8. Arquivos alterados nesta rodada

- Recuperados 8 PNGs originais nos caminhos corretos em `assets_originais/random stuff sprites/`.
- Removidos os 8 caminhos duplicados com caracteres corrompidos.
- Adicionado este relatório.
- Atualizados `docs/PROGRESSO.md`, `docs/AUDITORIA_PRE-COMPILACAO.md` e `LEIA_PRIMEIRO.txt`.
- Nenhum Java, JSON de runtime, modelo, blockstate, receita ou loot table foi alterado.
