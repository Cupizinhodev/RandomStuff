# Relatório da rodada — Moobloom, Moonlip e pincel

## Alterações efetivas

1. Removido o recurso `BrushRefill` que usava o corante na mão secundária durante clique em bigorna. Não existe mais inicialização nem classe para essa interação.
2. Criado `registry/ModEntities.java` com os tipos `randomstuff:moobloom` e `randomstuff:moonlip`, registrados como criaturas e com atributos de vaca.
3. Adicionados ovos de invocação, modelos, itens de cliente e traduções em português/inglês.
4. Registrados renderizadores baseados no modelo vanilla de vaca e texturas originais para adultos e bebês.
5. Adicionada geração natural inicial na Floresta (Moobloom) e Cherry Grove (Moonlip).
6. Adicionadas loot tables básicas.

## Ainda não concluído

- As 9 variantes do Moobloom e as 7 variantes do Moonlip ainda não são selecionáveis/renderizadas individualmente.
- As flores não podem ser removidas com tesoura nem regeneram.
- O ovo ainda invoca a variante base fixa, não uma variante aleatória.
- Não há reprodução/filhotes com herança de variante.
- Eucalyptus e Speckled Forest ainda não existem; portanto, os spawns não refletem integralmente o briefing.
- Água colorida/cal­deirão colorido não foi implementado nesta rodada.
- O comportamento do pincel com corante na mão secundária foi removido; a recarga por bigorna/bancada não está implementada.

## Verificações

- Somente validação estática de JSON/PNG e integridade do ZIP.
- Nenhuma tarefa Gradle, compilação, JAR ou execução do Minecraft foi realizada.
