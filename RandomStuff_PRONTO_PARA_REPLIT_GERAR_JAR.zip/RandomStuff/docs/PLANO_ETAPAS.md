# Matriz de recursos e plano em etapas

Cada etapa só termina quando o Replit compila SEM erro. Cada etapa traz testes manuais.
Lado: S = servidor (lógica, dados), C = cliente (render, filtros), A = ambos (sincronização).

| Etapa | Conteúdo | Lado | Dependências / observações |
|---|---|---|---|
| 0 | Projeto base, assets mapeados, scripts | A | Feito |
| 1 (ESCRITA, nao compilada) | Ouro Rosa (bruto/lingote/blocos), Osso de Wither, Abóbora Branca, lajes/escadas/muros | S+C | JSON gerados por scripts/gerar_dados.py |
| 1b | Ouro Rosa: ferramentas, armadura, lança, cavalo, molde de ferraria, espada = dano Netherite | S+C | API de ToolMaterial/ArmorMaterial é a mais incerta no 26.3 |
| 2 | Funil de Cobre (oxidação/cera), Painel de Exposição, Molduras coloridas e Invisível, Pincéis/Água colorida | S+C | Block entities + renderizadores |
| 3 | Encantamentos (Lava Walker, Resist. Lava, Queda de Penas), itens/ajustes de Tridente, Beacon, Villager/Golem | S | Muita mudança em mecânica vanilla (mixins) |
| 4 | Moobloom/Moonlip, Raposa Negra, Slime/Magma no balde e comportamentos | S+C | Entidades, renderers com camada de flor |
| 5 | Biomas (Jardim Pálido, Floresta Salpicada, Cerejeira Bambuzal), atmosfera, spawns, loot, Mercador | S+C | Worldgen em JSON de dados |
| 6 | Cabeças e filtros visuais | C | Formato de post effect do 26.3 precisa ser validado |
| 7 | Correntes e carrinhos (até 8, aceleração progressiva), lajes-suporte | S+C | Mais arriscada; implementar do zero (Slabbed GPL / Improvement Minecarts ARR) |
| 8 | Configuração (saturação, padrão 50), polimento, testes de servidor | A | |

Fora de escopo (descartado no briefing): trilhos de cobre/slime, bússola/relógio/luneta, melhoria de carrinho, potes coloridos.

## Estado atualizado da Etapa 3 (08/11/2026)

A base `RandomStuff_Etapa_2_ATUALIZADA_FINAL.zip` já contém o código-fonte dos encantamentos Caminhante da Lava e Resistência à Lava, hooks de Queda de Penas, ajustes do tridente/projéteis, Beacon Brilho/Respiração e reparo de Golems por Villagers. Consulte `docs/RELATORIO_ETAPA_3.md`. Esses sistemas passaram apenas por validação estática; continuam pendentes de compilação e testes no Minecraft 26.3. Portanto, a etapa está consolidada no código, mas ainda não aprovada como funcional.

## Dúvidas técnicas reais (não definidas no briefing)
1. O Cubo de Enxofre existe no 26.3 vanilla? Se sim, quais classes? Se não, preciso da especificação completa.
2. Proposta de corpos de vaca: Moobloom -> amarelo (Buttercup, Dente-de-leão), vermelho (Papoula), azul (Centáurea), azul claro (Orquídea), roxo (Allium), branco (Azure Bluet, Lírio), cinza (Olho-de-Cera). Moonlip -> rosa (Margarida Rosa, Tulipa Rosa), laranja, vermelho (Tulipa Vermelha), branco (Tulipa Branca), margarida, magenta. Confirma?
3. Nomes finais de itens em português (ex.: "Ouro Rosa Bruto") serão feitos via arquivo de idioma pt_br + en_us.

## Estado atualizado da Etapa 4 (09/11/2026)

Auditoria inicial concluída. Moobloom/Moonlip possuem implementação de entidade, variantes, tosquia/regeneração e renderer/camada floral no código, mas ainda precisam de confirmação de API, spawns e testes em jogo. Baldes de Slime/Magma já capturam e restauram dados básicos (tamanho, vida, nome), mas faltam validação de dados completos e comportamentos físicos/interações especiais. Raposa Negra não foi encontrada implementada. Ver `docs/RELATORIO_ETAPA_4.md` e tarefas 20–28 de `TAREFAS_REPLIT.txt`. A etapa não está concluída.


### Recuperação de sprites na Etapa 4 (09/11/2026)

Os sprites de Ouro Rosa não estavam faltando nas texturas ativas do mod: os PNGs correspondentes já existiam em `src/main/resources` e eram idênticos aos originais. O que faltava eram quatro arquivos com nomes UTF-8 corretos em `assets_originais/` (ícone da calça, lança hotbar, lança em mão e pá), além dos quatro estágios da cenoura dourada. Os oito arquivos foram restaurados do ZIP `random stuff sprites.zip`. A validação estática passou sem erros. Isso fecha a pendência de caminhos de sprites, não a Etapa 4: Raposa Negra, persistência ampliada dos baldes, física/interações/tingimento e testes de runtime continuam pendentes.


### Atualização de implementação — Etapa 4 (09/11/2026)

Foi adicionada uma primeira implementação de Raposa Negra baseada na classe vanilla `Fox`, com renderer/ovo e spawn preparado para a chave futura da Floresta Salpicada. O balde de Slime/Magma passou a persistir uma lista limitada de atributos relevantes e vida proporcional. Nenhum desses trechos foi compilado. A regra contextual do ovo, física/combate/tingimento e validação das APIs 26.3 continuam em aberto. A Etapa 4 permanece aberta; não iniciar Etapa 5.

### Etapa 4 — atualização de 09/11/2026

O ovo da Raposa Negra agora possui lógica contextual no código: Floresta Salpicada => Raposa Negra; demais biomas => raposa vanilla. A Floresta Salpicada corresponde ao bioma vanilla `minecraft:dappled_forest` do Minecraft 26.3. Física, combate e tingimento de Slimes/Magma Cubes ainda não foram implementados porque o JAR Minecraft 26.3 não está disponível para inspeção de assinaturas e as regras do projeto proíbem presumir APIs. O script `scripts/extrair_referencias.sh` foi ampliado para gerar as assinaturas necessárias no Replit. A validação de Moobloom/Moonlip e renderizadores permanece pendente. Ver tarefas 32–38 de `TAREFAS_REPLIT.txt`; não avançar para a Etapa 5.


### Adicao transversal — Armor Trim de Ouro Rosa (09/11/2026)

O Lingote de Ouro Rosa tambem funciona como material para Armor Trims na mesa de ferraria. Implementado via `data/randomstuff/trim_material/rose_gold.json`, tag `minecraft:trim_materials` e paleta `textures/trims/color_palettes/rose_gold.png`. Nao exige mixin nem nova dependencia. O molde de melhoria de Ouro Rosa existente nao e substituido; ele continua servindo para as receitas de melhoria do equipamento. Ver `docs/PROGRESSO.md`.

### Atualização final de código — Etapa 4 (09/11/2026)

A implementação da Etapa 4 foi fechada no código-fonte: Moobloom/Moonlip e renderers preservados; Raposa Negra com ovo contextual e placement; baldes de Slime/Magma Cube corrigidos para `AbstractCubeMob`; física/combate/tingimento sincronizado dos Slimes e blocos coloridos implementados; placements terrestres registrados; imports/pacotes alinhados ao Minecraft 26.3. O estado detalhado está em `docs/RELATORIO_ETAPA_4.md`.

A única dependência de conteúdo fora desta etapa é o bioma Floresta Salpicada, que será criado na Etapa 5. O spawn da Raposa Negra já consulta a chave desse bioma, mas não foi criado um substituto nesta etapa. Conforme pedido, não foram executados Java 25, Gradle, compilação, `javap` nem Minecraft; apenas validadores estáticos em Python. A implementação está pronta para o usuário testar no jogo, mas não está certificada em runtime.


## Início da Etapa 5 (09/11/2026)

A Etapa 5 está em andamento. No Minecraft Java 26.3, dois nomes do briefing já correspondem a biomas vanilla existentes: Jardim Pálido = `minecraft:pale_garden` e Floresta Salpicada = `minecraft:dappled_forest`. Não criar cópias desses biomas. O código da Raposa Negra foi alinhado ao identificador vanilla `minecraft:dappled_forest`.

Foi criada a definição de dados `randomstuff:cherry_bamboo_grove`, com aparência/clima de Cerejeira, recurso de bambu em grupos e spawn de Moonlip. Foram adicionados recursos de geração para abóboras brancas no Jardim Pálido e abóboras normais/entalhadas/Jack o’Lantern na Floresta Salpicada. A ligação desses recursos aos biomas usa `BiomeModifications`.

**Limitação importante:** a distribuição de `randomstuff:cherry_bamboo_grove` no gerador padrão do Overworld ainda não foi conectada. `BiomeModifications` altera biomas selecionados, mas não acrescenta pontos ao multi-noise; a lista de parâmetros documentada só referencia presets codificados e não oferece append ao preset. Não foi criado mixin especulativo nem sobrescrito o preset vanilla. A atmosfera de pântanos/manguezais/desertos/badlands foi adicionada via atributos ambientais; sono e mercador foram revisados; loot foi ampliado, mas faltam livros encantados/equipamentos danificados e spawn de mobs com abóboras. A Etapa 5 continua aberta. As etapas 6, 7 e 8 ainda vêm depois dela.


### Etapa 5 — revisão adicional de worldgen (09/11/2026)

A feature de abóbora branca foi ajustada para o solo de pale moss do Jardim Pálido e os filtros de bioma foram reposicionados após os modificadores de coordenadas. A atmosfera dos pântanos, manguezais, desertos e badlands também passou a ajustar a cor da água. A Etapa 5 permanece aberta: a Cerejeira Bambuzal ainda não está na seleção multi-noise padrão, faltam os spawns de mobs com abóboras, parte do loot e testes manuais.


### Fechamento de edição da Etapa 5 (09/11/2026)
Ajustes de atmosfera adicionados para Dappled Forest e Pale Garden. A etapa continua não concluída: distribuição natural do Cherry Bamboo Grove no multi-noise Overworld, spawns com abóboras, loot complementar, ajuste de tamanho/frequência e testes de runtime permanecem pendentes. Ver `docs/RELATORIO_ETAPA_5.md` e `TAREFAS_REPLIT.txt`.


### Etapa 5 — implementação de código consolidada (2026-11-08; testes adiados)

A distribuição multi-noise da Cerejeira Bambuzal foi ligada ao `OverworldBiomeBuilder.addSurfaceBiome` por mixin, sem sobrescrever o preset vanilla; as faixas de Pale Garden e Dappled Forest foram ampliadas modestamente. Foram adicionados spawns naturais raros com abóboras na Dappled Forest e loot de livros encantados/equipamentos de diamante danificados. A etapa não é considerada validada até os testes manuais de mundo novo, spawns, loot, sono, mercador, atmosfera e servidor.
