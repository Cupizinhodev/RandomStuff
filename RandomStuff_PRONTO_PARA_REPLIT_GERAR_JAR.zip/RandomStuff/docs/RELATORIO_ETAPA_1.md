# Relatório — Etapa 1 do Random Stuff

**Projeto:** Random Stuff — Minecraft 26.3 / Fabric  
**Mod ID:** `randomstuff`  
**Pacote Java:** `com.randomstuff`

## Resultado desta entrega

Foram implementadas no projeto existente as três frentes solicitadas: Funil de Cobre e sua variante em carrinho de mina, corrente física entre carrinhos e molduras coloridas/invisível. A implementação foi feita por extensão dos registros e sistemas existentes; não foi criado um projeto Fabric novo.

## 1. Funis de cobre

- Preservadas as oito variantes já registradas: quatro estágios de oxidação, cada um encerado e não encerado.
- Os modelos continuam herdando `minecraft:block/hopper` e `minecraft:block/hopper_side`; a geometria não foi recriada. As texturas de topo, laterais e interior permanecem específicas de cada estágio.
- Preservado o inventário de cinco slots e o filtro por item e componentes.
- Corrigida a remoção parcial para que a última unidade do filtro não possa ser retirada, inclusive por `removeItemNoUpdate`.
- Mantidos os intervalos por oxidação: 6, 8, 10 e 12 ticks.
- Mantidos enceramento com favo de mel, raspagem com machado, sons/eventos de cobre, receitas e troca de variante preservando conteúdo e cooldown.
- Adicionado `CopperHopperMinecart`, uma entidade própria baseada em `MinecartHopper`, com cinco slots, filtro, preservação de uma unidade, transferência a cada seis ticks, ativação por trilho detector/ativador herdada do vanilla e bloco de exibição usando o modelo do Funil de Cobre.
- Adicionados registro da entidade, item, renderizador, modelo, tradução e receita do carrinho-funil.

## 2. Correntes visíveis entre carrinhos

- A conexão existente continua sendo a fonte de verdade para os elos; não foi substituída a lógica de seleção, espaçamento, aceleração ou desconexão.
- Cada elo ativo agora cria três `BlockDisplay` vanilla com `minecraft:chain`, posicionados entre os carrinhos.
- Os segmentos são atualizados no servidor a cada tick, com orientação calculada entre pontos consecutivos e uma pequena curva suspensa. A transformação sincronizada do `BlockDisplay` replica posição, orientação e escala aos clientes.
- Os visuais acompanham subidas, descidas e curvas conforme as posições reais dos carrinhos.
- Os displays recebem uma tag persistente ligada ao UUID do carrinho seguidor; isso permite recuperar os mesmos visuais após recarregar chunks/reiniciar, sem gerar uma segunda corrente para o mesmo elo.
- A limpeza foi integrada ao ciclo de desconexão e descarregamento dos carrinhos. Quando um carrinho é destruído, os elos filhos carregados e seus visuais são removidos.
- Não são usadas partículas como substituto da corrente.

## 3. Molduras coloridas e invisível

- Registradas as 16 variantes de moldura colorida: preto, azul, marrom, ciano, cinza, verde, azul-claro, cinza-claro, verde-limão, magenta, laranja, rosa, roxo, vermelho, branco e amarelo.
- Cada item usa `ItemFrameItem` com um tipo próprio derivado de `ItemFrame`; portanto, colocação em superfícies, direção, inserção/remoção do item e rotação continuam usando o comportamento vanilla.
- Cada variante tem renderer próprio que substitui somente o modelo da moldura colocada, usando as texturas originais do pacote. Os modelos herdam `minecraft:block/template_item_frame` e `minecraft:block/template_item_frame_map`, preservando a geometria vanilla para molduras vazias e molduras com mapas. Não é apenas uma troca do ícone do item.
- Ao quebrar ou usar o pick block, a entidade devolve a variante de moldura correspondente, não uma moldura vanilla comum.
- Implementada a troca de cor ao agachar e interagir com uma moldura colorida segurando o corante correspondente, preservando item inserido, orientação, rotação e nome personalizado.
- A moldura invisível usa uma entidade `ItemFrame` normal para manter interações e rotação, mas seu renderer limpa apenas o modelo da moldura e posiciona o item como moldura invisível vanilla. O item colocado continua visível.
- Criados os modelos, definições de item, blockstates/modelos auxiliares de renderização, receitas e traduções para todas as variantes.

**Conflito documental resolvido:** o briefing original descreve a moldura invisível como uma moldura de aparência normal no mundo. A instrução explícita desta etapa pede que ela permaneça invisível no mundo. Foi seguida a instrução explícita do usuário: moldura invisível, conteúdo visível.

## Arquivos principais alterados/adicionados

### Java
- `src/main/java/com/randomstuff/RandomStuffMod.java`
- `src/main/java/com/randomstuff/registry/ModItems.java`
- `src/main/java/com/randomstuff/registry/ModColoredFrames.java` (novo)
- `src/main/java/com/randomstuff/registry/ModCopperHopperMinecart.java` (novo)
- `src/main/java/com/randomstuff/entity/decoration/ModdedItemFrame.java` (novo)
- `src/main/java/com/randomstuff/entity/vehicle/CopperHopperMinecart.java` (novo)
- `src/main/java/com/randomstuff/feature/MinecartChains.java`
- `src/client/java/com/randomstuff/client/RandomStuffClient.java`
- `src/client/java/com/randomstuff/client/ColoredItemFrameRenderer.java` (novo)
- `src/client/java/com/randomstuff/client/CopperHopperMinecartRenderer.java` (novo)
- `src/main/java/com/randomstuff/block/CopperHopperBlock.java` e `src/main/java/com/randomstuff/block/entity/CopperHopperBlockEntity.java` preservados com as correções já existentes no projeto de trabalho.

### Recursos
- 16 receitas de molduras coloridas e receita de moldura invisível.
- Receita de Funil de Cobre em Carrinho de Mina.
- Definições de item em `assets/randomstuff/items/` para as 18 novas variantes (16 coloridas, invisível e carrinho-funil).
- Modelos de item e de moldura colocada, blockstates auxiliares e traduções `pt_br`/`en_us`.
- As texturas PNG originais do pacote foram reutilizadas sem edição.

## O que já existia e foi preservado

- Projeto principal e estrutura Gradle/Fabric existentes.
- Oito registros/modelos/texturas do Funil de Cobre.
- Sistema original de conexão de carrinhos, dados de ligação, limite de composição e controles de aceleração/desconexão.
- Demais recursos do mod: Moobloom, Moonlip, água colorida, pincéis, encantamentos, biomas e demais conteúdos não relacionados à Etapa 1.

## Validações estáticas realizadas

- 949 arquivos JSON do projeto analisados: todos válidos (941 em recursos do mod).
- 359 PNGs do projeto analisados: integridade de leitura confirmada; nenhum PNG original foi modificado.
- Referências de modelos, pais, blockstates e texturas `randomstuff:` verificadas: nenhuma ausência encontrada.
- Receitas e definições de itens novas verificadas contra os IDs registrados no código.
- Integridade do ZIP final verificada com `unzip -t`.

## APIs consultadas e pontos que ainda exigem validação de integração

Foram consultadas as assinaturas Mojang de Minecraft 26.3 para `MinecartHopper`, `AbstractMinecartContainer`, `MinecartItem`, `ItemFrame`, `ItemFrameItem`, `ItemFrameRenderer`, `BlockModelResolver`, `AbstractMinecartRenderer`, `BlockDisplay` e `EntityType.Builder`.

Ainda exigem validação de integração em ambiente de desenvolvimento/jogo:
- Renderização visual final da corrente (espessura/curvatura) em trens de oito carrinhos e em todas as geometrias de trilho.
- Recarregamento de chunks e sincronização de displays em servidor dedicado com vários clientes.
- Recoloração de molduras com mapas, molduras fixas e itens com componentes especiais.
- Transferência/filtro e preservação da unidade do carrinho-funil sob todas as operações do menu e em trilhos ativadores.
- Aparência final das 16 molduras e da moldura invisível em todas as orientações.

Esses pontos são testes de integração/visuais, não APIs presumidas como confirmadas.

## Compilação e testes

- **Gradle/build:** não executado, conforme instrução.
- **Compilação/JAR:** não realizada.
- **Inicialização do Minecraft:** não realizada.
- **Testes dentro do jogo:** não realizados.

A entrega contém o projeto completo e as implementações de código-fonte/recursos. A ausência de build e teste em jogo está explicitamente registrada porque foi uma restrição obrigatória desta etapa.
