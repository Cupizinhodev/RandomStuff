# Relatório — Etapa 5: biomas, atmosfera, spawns, loot e mercador

**Estado: implementação de código consolidada; testes de runtime deliberadamente não executados.**

## Implementações presentes

1. **Biomas existentes e novo bioma:** Jardim Pálido e Floresta Salpicada reutilizam `minecraft:pale_garden` e `minecraft:dappled_forest`. `randomstuff:cherry_bamboo_grove` tem definição própria, vegetação de cerejeira, bambu e spawn de Moonlip.
2. **Distribuição multi-noise:** `OverworldBiomeBuilderMixin` injeta em `OverworldBiomeBuilder.addSurfaceBiome`, método usado pelo `Preset.provider().apply(...)` na montagem do preset vanilla. Quando a entrada é `minecraft:cherry_grove`, divide a faixa térmica: 90% continua pertencendo a Cherry Grove e 10% passa a `randomstuff:cherry_bamboo_grove`. Para Pale Garden e Dappled Forest, emite a própria região com os intervalos climáticos modestamente ampliados em 4% e 2,5%, respectivamente. O restante das entradas vanilla é preservado; não há substituição do `dimension/overworld`. A frequência real precisa ser medida em mundo novo.
3. **Abóboras:** features/placed features para abóboras brancas no Pale Garden e abóboras normais, entalhadas e Jack o’Lantern na Dappled Forest. Frequências configuradas: 1/1100, 1/220, 1/850 e 1/1700. Abóbora branca exige `minecraft:pale_moss_block`; os filtros de bioma vêm após os modificadores de posição.
4. **Mobs com abóboras:** `MobNaturalPumpkinEquipmentMixin` injeta no final de `Mob.finalizeSpawn`. Exige `EntitySpawnReason.NATURAL`, restringe-se a zumbis (incluindo variantes), esqueletos (incluindo variantes) e creepers na Floresta Salpicada, não substitui equipamento de cabeça existente e não usa abóbora normal. Chance por mob: 2,1% para abóbora entalhada e 0,4% para Jack o’Lantern; chance de drop configurada em 8,5%.
5. **Raposa Negra/Moonlip:** spawn natural da Raposa Negra na Floresta Salpicada e spawn da Moonlip no bioma Cerejeira Bambuzal; ovo contextual da Raposa Negra já implementado.
6. **Atmosfera:** Pântano/Manguezal com tonalidade verde suave; Deserto amarelo-alaranjado; Badlands/Eroded/Wooded Badlands ocre/alaranjado; Dappled Forest com atmosfera quente; Pale Garden com paleta fria/sombria. Inclui fog, sky, water fog e tintas de água/grama/folhagem via Fabric BiomeModifications/Environment Attributes. Valores são uma primeira calibração visual.
7. **Sono:** `SleepAcceleration` acelera random ticks, fornalhas e filhotes em torno de jogadores dormindo; deduplica posições/animais e não carrega chunks descarregados. Taxas são parâmetros iniciais.
8. **Mercador:** 24 ofertas de venda e 7 de compra; não compra escama de tartaruga. “Folhas” foi interpretado como folhas de carvalho e “flores” como dente-de-leão porque o briefing não especificou espécies.
9. **Loot:** pools adicionais preservam o loot vanilla. Livros encantados de baixo nível adicionados a baús de vilas (níveis 2–7, chance 4,5%) e strongholds (níveis 3–9, chance 10%) usando `EnchantWithLevelsFunction` e `ContextIntProviders`. Baús de stronghold também podem gerar nove tipos de equipamento de diamante com 25–80% de dano (20–75% de durabilidade restante), via `SetItemDamageFunction` e `ContextFloatProviders` (2,5% por item). Itens adicionais existentes e moldes de Ouro Rosa permanecem.

## Verificações permitidas e limites

As alterações foram inspecionadas estaticamente e os arquivos de configuração/JSON serão validados por scripts Python. **Não** foram executados Java/JDK 25, Gradle, compilação, `javap`, geração de JAR, cliente Minecraft ou servidor, conforme instrução do usuário. Portanto, não há afirmação de funcionamento em runtime.

## Testes adiados

- Criar mundo novo e confirmar `/locate biome randomstuff:cherry_bamboo_grove`, frequência, tamanho e bordas com Cherry Grove.
- Confirmar expansão de Pale Garden/Dappled Forest e ausência de impactos indesejados nos demais biomas.
- Verificar altura/densidade do bambu e árvores.
- Verificar mobs equipados apenas em spawn natural, probabilidades, equipamento pré-existente e drops.
- Verificar geração das abóboras/solo pale moss, loot de todos os baús de vilas/strongholds, encantamentos e dano de equipamento.
- Testar atmosfera no cliente, incluindo Sodium/outros mods; sono, mercador e servidor dedicado.

**Conclusão:** tarefas de implementação de código da Etapa 5 foram preenchidas nesta revisão. A Etapa 5 permanece aberta apenas para a validação manual/runtime que o usuário pediu para não executar agora.
