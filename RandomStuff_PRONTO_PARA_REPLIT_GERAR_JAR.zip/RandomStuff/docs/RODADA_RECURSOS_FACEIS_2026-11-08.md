# Random Stuff — rodada de recursos mais simples

Data: 08/11/2026  
Alvo: Minecraft Java 26.3 · Fabric · Java 25

## Implementado nesta rodada

- **Cortador de pedras: troncos/madeiras descascados.** Adicionadas 20 receitas de stonecutting: 10 espécies vanilla (carvalho, pinheiro, bétula, selva, acácia, carvalho escuro, mangue, cerejeira, carmesim e distorcido), cada uma aceitando o bloco de tronco e o bloco de madeira e produzindo a variante descascada correspondente.
- As receitas usam o formato de stonecutting já utilizado pelo próprio projeto e não alteram blocos, entidades ou dados de mundo.

## Recursos simples já presentes no projeto (preservados; não são novidades desta rodada)

- Farinha de osso acelera cana-de-açúcar (mix-in dedicado).
- Bigorna danificada pode ser reparada com bloco de ferro, avançando um estágio por bloco.
- Espada de ouro recebe dano de ataque equivalente ao valor-base da espada de Netherite, mantendo a durabilidade original.
- Itens de Netherite flutuam na lava (mix-in de entidade de item).
- Mercador Ambulante recebe as ofertas de compra e venda definidas no briefing.
- Proteção contra mobs da mesma espécie ao usar a cabeça correspondente; Piglin tratado separadamente.
- Água Colorida e recarga de pincel pela interface da bigorna estão no projeto, ainda exigindo compilação e teste em jogo.

## Classificação para a próxima etapa

### Fáceis/concisos já cobertos
- Receitas de cortador de pedras para madeira descascada.
- Farinha de osso na cana.
- Reparação de bigornas.
- Ajuste de dano da espada de ouro.
- Flutuação de itens de Netherite na lava.
- Ofertas do Mercador Ambulante.

### Intermediários (não misturados nesta rodada)
- Folhas secas flutuando sobre água e regra de lajes como suporte: o briefing não identifica precisamente o bloco de folhas secas nem a regra completa de posicionamento; precisa fechar o alvo antes de codificar.
- Configuração de saturação visual (padrão 50): envolve tela de opções, persistência local e pipeline visual do cliente.
- Filtros visuais das cabeças: recursos e seleção de efeitos existem, mas precisam validação do pipeline de pós-processamento 26.3.

### Difíceis — reservar para uma etapa própria
- Funil de Cobre e variantes em carrinho.
- Painel de Exposição e molduras (BlockEntity, menu/renderização).
- Moobloom/Moonlip e Raposa Negra (entidades, IA, render, spawn).
- Cubo de Enxofre e completar física/interações de Slime/Magma.
- Biomas e worldgen.
- Encantamentos e alterações de tridente/projéteis.
- Beacon customizado e IA Villager/Golem.
- Correntes/carrinhos encadeados, HUD e sincronização.
- Aceleração do mundo durante o sono.

## Auditoria e limites

- Foram adicionados 20 JSON de receitas.
- A validação JSON/recursos foi executada. O validador geral reportou 8 referências ausentes no manifesto de assets originais, em caminhos com caracteres acentuados/decodificação de nome; esses caminhos já pertenciam ao pacote e não foram criados pelas receitas. Não corrigi o manifesto automaticamente para não renomear ou substituir assets originais sem confirmação.
- 1 aviso: não existe suíte automatizada em `src/test`.
- Nenhuma compilação Gradle, `javac`, geração de JAR ou teste dentro do Minecraft foi executado.
