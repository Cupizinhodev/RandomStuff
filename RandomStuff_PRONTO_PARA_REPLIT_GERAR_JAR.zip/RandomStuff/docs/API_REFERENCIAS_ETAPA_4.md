# Referências documentais de API — Minecraft 26.3

Data: 09/11/2026

Estas páginas foram usadas para conferir nomes de classes e assinaturas do Minecraft 26.3 sem executar JDK/Java 25, Gradle, compilação ou `javap`. São Javadocs da distribuição NeoForge 26.3 e descrevem classes-base do Minecraft com nomes Mojang; não substituem a conferência final no ambiente Fabric do projeto.

## Entidades e cubemobs

- `AbstractCubeMob`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/monster/cubemob/AbstractCubeMob.html
  - Métodos documentados: `tick`, `push(Entity)`, `canDealDamage`, `dealDamage(LivingEntity)`, `defineSynchedData(SynchedEntityData.Builder)`, `addAdditionalSaveData(ValueOutput)` e `readAdditionalSaveData(ValueInput)`.
- `Slime`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/monster/cubemob/Slime.html
- `MagmaCube`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/monster/cubemob/MagmaCube.html
- `EntityTypes`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/EntityTypes.html
  - Constantes vanilla de entidades, incluindo `SLIME`, `MAGMA_CUBE` e `FOX`, estão na classe `EntityTypes`.
- `EntitySpawnReason`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/EntitySpawnReason.html (`SPAWN_ITEM_USE`, `BUCKET`, `BREEDING`).
- `Fox`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/animal/fox/Fox.html
- `Cow`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/animal/cow/Cow.html
  - `getBreedOffspring(ServerLevel, AgeableMob)` retorna `@Nullable Cow`.
- `Animal`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/animal/Animal.html
  - `checkAnimalSpawnRules(EntityType<? extends Animal>, LevelAccessor, EntitySpawnReason, BlockPos, RandomSource)`.

## Spawn placements

- `SpawnPlacementType`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/SpawnPlacementType.html
- `SpawnPlacementTypes`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/SpawnPlacementTypes.html (`ON_GROUND`)
- `SpawnPlacements`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/SpawnPlacements.html
  - `register(EntityType<T>, SpawnPlacementType, Heightmap.Types, SpawnPredicate<T>)` é privado estático no vanilla 26.3; por isso o projeto usa um Mixin `@Invoker` específico em vez de fingir que o método é público.

## Dano e tingimento

- `LivingEntity`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/entity/LivingEntity.html
  - `causeFallDamage(double, float, DamageSource)` e `hurtServer(ServerLevel, DamageSource, float)`.
- `DamageTypes`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/damagesource/DamageTypes.html
  - `FALL`, `STALAGMITE`, `FALLING_STALACTITE`, `DROWN` e `HOT_FLOOR`.
- `DyeColor`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/item/DyeColor.html
  - `byId(int)`, `getId()` e `getTextureDiffuseColor()`.
- `DyeItem`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/world/item/DyeItem.html
  - A classe 26.3 não expõe `getDyeColor`; `DyeColorItems` resolve a cor a partir do ID registrado `minecraft:<cor>_dye`.

## Renderização do Slime

- `LivingEntityRenderer`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/renderer/entity/LivingEntityRenderer.html
  - `extractRenderState` e `getModelTint`.
- `SlimeRenderState`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/renderer/entity/state/SlimeRenderState.html
- `SlimeRenderer`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/renderer/entity/SlimeRenderer.html
- `FoxRenderer`: https://aldak0.ru/javadoc/26.3.x/net/minecraft/client/renderer/entity/FoxRenderer.html

## Limite da conferência

As assinaturas documentadas ajudam a evitar imports/métodos antigos, mas não provam que cada callback Fabric, descritor Mixin, remapeamento Loom ou integração de renderer funcione em runtime. Não houve compilação nem testes; o usuário pediu expressamente que Java 25 e Minecraft não fossem executados.
