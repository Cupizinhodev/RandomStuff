# Random Stuff — execução do backlog restante

Data: 08/11/2026  
Alvo declarado: Minecraft Java 26.3 · Java 25 · Fabric · modid `randomstuff`

## Resultado honesto desta rodada

O pedido cobre nove subsistemas grandes, alguns envolvendo novas entidades com renderização, block entities com inventário e sincronização, worldgen/biomas, encantamentos e mixins em mecânicas vanilla. O briefing define o comportamento, mas o projeto não contém os tipos/classes base desses sistemas e a tarefa proíbe compilar. Portanto, não é tecnicamente correto preencher os espaços com classes presumidas e declarar tudo implementado sem validar os nomes e descritores reais do Minecraft/Fabric 26.3.

Nesta rodada foi feita uma revisão de escopo contra os briefings originais, corrigida uma nota de código que dizia incorretamente que os filtros visuais ainda não existiam, e preparada uma matriz de execução com critérios de conclusão e bloqueios. Nenhum sistema incompleto foi marcado como concluído. Nenhuma mecânica foi inventada.

## Estado por sistema

| Sistema | Estado real | O que falta para concluir |
|---|---|---|
| Funil de Cobre | Pendente | BlockEntity com 5 slots, filtro que preserva 1 unidade, transferência, velocidade por oxidação, cera, variante em carrinho, receitas/modelos/sons. |
| Água Colorida / caldeirão | Parcial nesta rodada | Caldeirão customizado com 16 cores, 3 níveis, troca de cor por último corante e recarga do pincel da mesma cor. Falta validar renderização no jogo e definir/implementar a pintura direta de itens por imersão. |
| Painel de Exposição / molduras | Pendente | BlockEntity, persistência, geometria/renderização, interação, 16 cores e moldura invisível com render condicional. |
| Moobloom / Moonlip | Assets preparados; entidades pendentes | As texturas de corpo e overlays da pasta `vacas` são camadas visuais das entidades, não flores de mundo. A matriz de variantes está em `docs/MATRIZ_VARIANTES_MOOBLOOM_MOONLIP.json`. Faltam entidades, render layers, tesoura/regrowth, ovos e spawns. |
| Raposa Negra | Pendente | Variante de aparência da Fox, escolha por biome, spawn rules e ovo respeitando o biome. |
| Slime / Magma Cube | Parcial | Captura/soltura existe; faltam preservar todos os dados relevantes, bounce, sem dano de queda com exceção de perigos, empurrões, alvos recíprocos, água/lava e pouso. |
| Absorções do Cubo de Enxofre | Pendente | O briefing reconhece TNT e bloco de magma como vanilla; mel, fornalha, bancada, glowstone, redstone, esponja e bloco de ossos exigem o formato real de arquétipo 26.3, ainda não presente no pacote. |
| Biomas e geração | Pendente | Definições de bioma/placed features/configured features, distribuição, atmosfera, spawn modifiers e loot tables. |
| Encantamentos/equipamentos | Pendente | Registros e hooks para Lava Walker, Resistência à Lava, Queda de Penas, tridente, projéteis rebatíveis, pesca em barco e Lança de Ouro Rosa. |
| Beacon / Villager / Golem | Pendente | Efeitos customizados, ícones, alcance/duração, interação do villager com golem no último estágio de dano. |
| Cabeças | Parcial | Proteção por `setTarget` e tratamento de Brain para Piglin existem; cinco filtros visuais existem como recursos. Falta teste real dos mixins e do pipeline de post effect 26.3, e validar espécies/retaliações restantes. |
| Correntes / carrinhos | Pendente | Rede de composições persistente/sincronizada, máximo 8, interação agachar+corrente, espaçamento, aceleração e HUD. |
| Sono / saturação | Pendente | Hooks de sono e escalonamento de ticks; configuração visual de saturação padrão 50. A taxa de aceleração não está especificada no briefing e não será inventada. |

## Sistemas existentes preservados

- Ouro Rosa: materiais, ferramentas/armadura, receitas de ferraria e recursos.
- Abóbora Branca: blocos, receitas e loot.
- Osso de Wither e blocos de construção aprovados.
- Discos musicais que apontam para sons vanilla já existentes.
- Pincéis coloridos e pintura dos blocos suportados.
- Captura/soltura de Slime e Cubo de Magma (parcial).
- Reparação de bigorna, cana-de-açúcar com farinha de osso, espada de ouro e trades do Mercador Ambulante.
- Cabeças: proteção por espécie e protótipos de filtro visual.

## Sequência técnica obrigatória para continuar

1. **Funil de Cobre**: registrar bloco/item, BlockEntity, menu/handler, filtro, oxidação/enceramento, carrinho, dados, receitas, loot, modelos, idiomas e sons. Só concluir após revisão de transferência e persistência.
2. **Água Colorida e molduras**: definir componente/BlockEntity persistente, consumo e renderização; depois painel.
3. **Criaturas**: entidades e variantes primeiro; depois camada de flores, tesoura/regrowth, ovos e spawn.
4. **Slimes/Magma**: completar captura e física sem cancelar dano de perigos; adicionar interações e sincronização.
5. **Biomas**: definir biomes e features por dados; validar compatibilidade de worldgen 26.3.
6. **Encantamentos**: registrar cada efeito e adicionar hooks específicos; manter incompatibilidade Lava Walker/Frost Walker.
7. **Beacon/Villager/Golem**: efeitos e IA com estado de dano explícito.
8. **Cabeças**: revisar todos os tipos e o pipeline client-side.
9. **Carrinhos**: implementar composição própria, limite 8, sincronização e HUD; não derivar código de mods ARR/GPL.
10. **Sono/configuração**: estabelecer aceleração sem alterar tempo global indevidamente; configuração única de saturação com default 50.

## Critérios de aceite por sistema

- Nenhuma classe ou JSON isolado conta como sistema pronto.
- Registros, receitas, loot, modelos, blockstates, traduções e assets devem apontar para IDs existentes.
- Estado persistente deve sobreviver a salvar/descarregar/recarregar chunks.
- Dados de entidades devem sincronizar servidor/cliente quando afetarem renderização ou interação.
- Recursos client-only não podem carregar em servidor dedicado.
- Não usar métodos, classes ou nomes de registry presumidos. Conferir API 26.3 antes de codificar.
- Testes estáticos não substituem compilação nem teste no jogo.

## Alterações desta rodada (08/11/2026)

- **Correção da interpretação dos assets:** removidos os 13 registros incorretos de flores de mundo que tinham sido criados a partir dos nomes de overlays da pasta `vacas`. Os PNGs originais continuam preservados em `assets_originais` e as texturas de corpo/overlay continuam em `textures/entity/flower_cow`.
- Permanecem como flores de mundo somente as três que realmente estão em `assets_originais/random stuff sprites/flores`: Buttercup, Pink Daisy e Magenta Tulip.
- Removidos blockstates, modelos, item models, loot tables, traduções e texturas de bloco gerados indevidamente para as 13 variantes de vaca.
- Criada `docs/MATRIZ_VARIANTES_MOOBLOOM_MOONLIP.json` com o mapeamento das 9 variantes Moobloom e 7 Moonlip, texturas adultas/bebês e overlays correspondentes. É uma matriz de implementação, não afirma que as entidades já estejam registradas.
- Implementada recarga de pincel colorido em bigorna: segurar o pincel numa mão e o corante da mesma cor na outra, e usar a bigorna. A tinta volta a 64, preservando a durabilidade do pincel; o corante é consumido fora do criativo.
- Removidas receitas de crafting que substituíam o pincel usado por um novo, pois apagavam a durabilidade e não correspondiam ao fluxo especificado de recarga em bigorna/bancada.
- Corrigidos comentários desatualizados sobre a proteção de cabeças/Piglin.

**Limite:** Moobloom/Moonlip continuam sem entidades, render layers, tesoura/regrowth, ovos e spawns. A matriz e os assets estão preparados para a próxima implementação, mas não substituem o código runtime.

## Verificações

- Nenhuma compilação ou tarefa Gradle executada.
- Nenhum `javac` executado.
- Nenhum JAR gerado.
- Nenhum teste de Minecraft executado.
- Os validadores estáticos do projeto devem ser executados separadamente; seus resultados desta rodada serão registrados no relatório de auditoria atualizado.

## Limitação desta entrega

Este ZIP é a versão de projeto atualizada com documentação de execução e uma correção documental. Ele **não** contém a implementação completa dos sistemas pendentes. Não seria honesto afirmar que o pedido inteiro foi concluído nesta rodada.

## Atualização — recarga de pincel pela interface da bigorna (08/11/2026)

- A antiga pendência de recarga `pincel colorido + corante correspondente` foi implementada via slots da interface da bigorna, sem combinação nas mãos.
- A saída copia o pincel de entrada e só altera `Paint` para 64, preservando a durabilidade de escavação e os demais componentes.
- A bigorna consome 1 corante e cobra 1 nível de experiência ao retirar o resultado.
- A bancada não foi implementada porque o briefing permite bigorna **ou** bancada.
- A integração usa `AnvilMenu#createResult` e acesso aos inventários herdados de `ItemCombinerMenu`. É obrigatório confirmar a assinatura/visibilidade desses membros no compilador 26.3 e testar retirada do resultado, custo, consumo, durabilidade e persistência. Portanto, esta pendência está **implementada no código, mas ainda não validada em runtime**.
