# Etapa 4 — auditoria e implementação incremental

Data: 2026-11-09  
Base: `RandomStuff_Etapa_3_CONSOLIDADA.zip`  
Alvo: Minecraft 26.3 + Fabric, Java 25.

## Escopo aprovado

1. Moobloom e Moonlip: vacas florais com 9 e 7 variantes, camada de flor 3D separada, tesoura remove somente a flor, drop correspondente e regeneração após 2 minutos de jogo; Eye-of-Wax abre à noite. Ovos geram variantes aleatórias. Reprodução mantém a espécie e herda variante de um dos pais. Spawns moderados nos biomas especificados.
2. Raposa Negra: variante exclusiva da Floresta Salpicada, com comportamento e atributos vanilla. Ovos invocados dentro desse bioma também geram a variante negra; fora dele geram raposas vanilla.
3. Baldes de Slime e Cubo de Magma: capturar e soltar preservando tamanho, nome e dados relevantes, usando persistência semelhante ao Cubo de Enxofre.
4. Física e interação de Slimes/Magma Cubes: sem dano de queda, quique ao tocar o chão, perigos de impacto/estalactites mantidos, flutuação (Slime na água, Magma Cube na lava), hostilidade recíproca, empurrões sem dano em certos contatos, dano de água ao Magma Cube, quique de entidades ao pousar neles e dano de calor moderado do Magma Cube. Slimes e blocos de slime podem ser tingidos; Magma Cubes não.

## Estado encontrado na base

### Moobloom/Moonlip

- Registros de entidades, ovos, loot e spawn inicial existem.
- `FlowerCowEntity` já armazena/sincroniza variante e estado de flor, permite tosquia, drop e regeneração em 2.400 ticks, salva/carrega dados e define reprodução com herança de variante.
- Renderizador dedicado e camada floral 3D foram adicionados em rodada posterior; texturas adultas/bebês e overlays para as 16 variantes estão presentes. Eye-of-Wax possui versões abertas/fechadas.
- Ainda requer conferência de assinaturas da API 26.3 e teste visual/runtime. Os spawns precisam ser revisados para os biomas exatos do briefing (Floresta de Carvalho, maior frequência em Eucalipto; Moonlip principalmente em Cerejeira). Os biomas customizados ainda não estão presentes.
- A seleção aleatória dos ovos e a herança na reprodução precisam ser confirmadas em jogo; não presumir funcionamento só pela presença de código.

### Raposa Negra

- Não foi encontrada entidade/variante, renderer, regra de spawn, lógica de ovo ou textura dedicada implementada na base.
- Deve reutilizar `EntityType.FOX`/comportamento vanilla sempre que possível, evitando criar IA própria. A aparência precisa ser resolvida por variante/renderização compatível com 26.3.
- A Floresta Salpicada ainda não existe; deixar a integração de spawn preparada e documentada, sem inventar outro bioma substituto.

### Slime/Magma Cube em baldes

- `BucketCapture` captura Slime e Magma Cube com balde vazio.
- `CapturedSlimeBucketItem` salva tamanho, vida e nome customizado em `CUSTOM_DATA` e restaura ao soltar. Não há confirmação de persistência completa de todos os dados relevantes (efeitos, atributos/variantes, tags adicionais, comportamento do Magma Cube), nem teste de inventário cheio/servidor.
- Não foram encontrados hooks de física para quique, ausência de dano de queda, flutuação, hostilidade recíproca, empurrões, dano de água ou pouso sobre Magma Cube.
- Tingimento de Slime/blocos de Slime e bloqueio explícito de tingimento do Magma Cube ainda precisam ser auditados/implementados.

## Plano desta etapa

A prioridade é fechar as vacas florais sem regressões; depois Raposa Negra; por fim baldes e física dos Slimes/Magma Cubes. As alterações devem ser pequenas e separadas, com APIs 26.3 verificadas no jar real via `javap`. Não remover funcionalidades antigas para contornar incompatibilidades.

## Limites de validação

Esta auditoria foi estática. Não foi executado Gradle, compilador, geração de JAR ou Minecraft. Portanto, nada nesta etapa está declarado como funcional em runtime. Consulte `TAREFAS_REPLIT.txt` para os testes obrigatórios antes de marcar qualquer item como concluído.


## Aditivo — conferência de sprites e código (09/11/2026)

### Sprites

Comparados os três pacotes recebidos. O pacote `random stuff sprites.zip` contém o conjunto de Ouro Rosa (incluindo ícone da calça, lança hotbar, lança em mão e pá). As texturas ativas do mod já continham os quatro arquivos e seus bytes coincidem com os originais. A falha era na cópia de preservação `assets_originais/`: quatro caminhos acentuados estavam ausentes por inconsistência de codificação. Os quatro foram restaurados sem alteração. A mesma correção foi aplicada aos quatro estágios da cenoura dourada. Não foi redesenhado nem sobrescrito qualquer sprite existente.

### Auditoria pontual do código

- `FlowerCowEntity` implementa estado sincronizado de variante/flor, tesoura, drop de flor, regeneração em 2.400 ticks, persistência dos campos e reprodução com herança de variante. A assinatura de `getBreedOffspring`, a inicialização do estado de bebê e as APIs de 26.3 ainda precisam ser conferidas no JAR real.
- `ModEntities` registra Moobloom/Moonlip e atributos, e adiciona spawns em `FOREST` e `CHERRY_GROVE`. Não foi localizado registro explícito de `SpawnPlacements`; o spawn atual não comprova restrição terrestre nem o bioma/frequência de Eucalipto. Os biomas customizados não devem ser simulados antes da Etapa 5.
- `FlowerCowRenderer` e `FlowerCowRenderState` estão no source set cliente. A existência dos símbolos `BlockDecorationLayer`, `BlockModelResolver`, `CowRenderState` e assinaturas usadas não foi confirmada por `javap`, pois nenhum JAR de Minecraft 26.3 foi fornecido no diretório `referencia` e a regra do projeto proíbe executar Gradle nesta etapa.
- A textura `assets/randomstuff/textures/entity/fox/black_fox.png` existe, mas não há implementação de Raposa Negra no código Java. A integração correta com a raposa vanilla e a futura Floresta Salpicada seguem pendentes.
- `BucketCapture` usa `UseEntityCallback` e captura Slime/Magma Cube por `instanceof Slime`. `CapturedSlimeBucketItem` armazena apenas tamanho, vida absoluta e nome customizado; ainda não é persistência completa nem cobre dados arbitrários de forma segura. Soltura verifica `addFreshEntity` antes de consumir o balde, mas inventário cheio, sincronização, vida proporcional, dados adicionais e modo criativo exigem revisão/testes.

### Resultado verificável

`python3 scripts/validar_projeto.py`: 0 erros (1 aviso de ausência de suíte automatizada).
`python3 scripts/validar_assets.py`: 0 erros.
Comparação byte a byte dos oito sprites: correspondência confirmada.

**Limite:** nenhuma compilação ou sessão Minecraft foi executada. A Etapa 4 permanece aberta; este aditivo registra somente recuperação de assets e auditoria estática.


## Implementação incremental adicional (09/11/2026)

### Raposa Negra — código adicionado, não validado

- Criada `BlackFoxEntity`, subclasse direta de `Fox`, sem IA paralela.
- Adicionado registro de entidade e atributos vanilla em `ModEntities`.
- Preparado spawn via chave `minecraft:dappled_forest`; o bioma ainda depende da Etapa 5 e nenhum bioma substituto foi criado.
- Adicionado ovo de invocação e renderer dedicado que referencia `textures/entity/fox/black_fox.png`.
- Pendente: conferir assinaturas de `FoxRenderer`/`FoxRenderState`/`Fox.createAttributes()` com `javap`; implementar regra do ovo que cria raposa negra somente dentro da Floresta Salpicada e raposa vanilla fora dela; testar renderização e IA no jogo.

### Baldes — persistência segura ampliada no código, não validada

- A gravação passou a guardar tamanho limitado, fração de vida (em vez de vida absoluta), nome simples com limite de comprimento, NoAI, invulnerabilidade e flag de persistência.
- A soltura restaura somente campos de uma lista permitida; não importa NBT arbitrário do item para a entidade.
- A captura entrega/substitui o balde antes de descartar a criatura, reduzindo a janela de perda/duplicação. A soltura continua consumindo o balde somente após `addFreshEntity` aceitar a entidade.
- Pendente: validar `ItemUtils.createFilledResult`, setters/getters de Entity/Slime e comportamento de inventário cheio/criativo/offhand em 26.3. Nome formatado e dados específicos de outros mods não são preservados por segurança.

### Slime/Magma — ainda pendente

Não foram adicionados mixins de física, dano de água, flutuação, combate recíproco, quique de entidades, dano térmico ou tingimento nesta rodada. A API 26.3 não está disponível no pacote local para inspeção com `javap`; inventar descritores de mixin contrariaria as regras do projeto. Tarefas 25–27 permanecem abertas e especificam a inspeção necessária no Replit.

### Limite de validação

Nenhum Gradle, compilador, `javap`, cliente ou servidor foi executado. As alterações acima são somente alterações de código e assets; não são declaradas funcionais. Executar as validações estáticas do projeto e, depois, compilar/testar no Replit conforme tarefas 20–31.

## Rodada técnica — 09/11/2026 (ovo contextual e preparação de APIs)

### Implementado no código-fonte (não compilado/testado)

- O ovo da Raposa Negra deixou de depender do comportamento automático de `SpawnEggItem`. Agora usa `ContextualBlackFoxSpawnEggItem` e `UseBlockCallback`: dentro da chave `minecraft:dappled_forest` seleciona `ModEntities.BLACK_FOX`; fora dela seleciona `EntityType.FOX`. O item mantém as propriedades visuais de ovo via `Item.Properties.spawnEgg(ModEntities.BLACK_FOX)`. A entidade só é consumida depois que `ServerLevel#addFreshEntity` retorna sucesso. Arquivos: `item/ContextualBlackFoxSpawnEggItem.java` e `registry/ModItems.java`.
- `scripts/extrair_referencias.sh` foi ampliado para tentar extrair assinaturas `javap` de Slime, MagmaCube, Entity, LivingEntity, Mob, SlimeBlock, SlimeRenderer, FoxRenderer/FoxRenderState, CowRenderer/CowRenderState e classes da camada floral. O script continua dependendo de um JAR 26.3 já baixado no ambiente Replit; não executa Gradle.
- Tarefas 32–38 detalham a validação do ovo, a inspeção necessária e os critérios de física, combate, tingimento e renderização.

### Não implementado nesta rodada

- Física especial, ausência de dano de queda, quique e flutuação de Slime/Magma Cube.
- Combate recíproco, knockback, contato e dano térmico de pouso.
- Tingimento de Slimes e blocos de Slime.
- Correções de API/render/spawn de Moobloom/Moonlip e validação de FoxRenderer.

### Limite técnico objetivo

O diretório `referencia/` contém somente o protótipo dos filtros visuais; não há JAR do Minecraft 26.3 nem JAR mapeado disponível localmente. A regra `REGRAS_PARA_QUALQUER_CLAUDE.txt` proíbe executar Gradle, compilar ou abrir o jogo e também proíbe inventar APIs. Por isso, não foram adicionados mixins de física/renderização com métodos ou descritores presumidos. Para prosseguir com esses sistemas, o Replit deve gerar `referencias_minecraft.zip` com `bash scripts/extrair_referencias.sh` e enviar o arquivo de volta.

### Verificações

- Nenhuma compilação, execução Gradle, `javap`, cliente ou servidor foi executado nesta rodada.
- O ovo contextual está implementado no código-fonte, mas sua callback, propriedades de spawn egg, assinatura do `EntityType.create` e comportamento de consumo ainda precisam de compilação e teste.
- A Etapa 4 permanece aberta; não avançar para a Etapa 5.


## Adicao solicitada — Armor Trim de Ouro Rosa (09/11/2026)

Embora seja um recurso transversal da linha de Ouro Rosa (Etapa 1b), foi implementado nesta rodada por solicitacao do usuario. O lingote pode ser usado como material de acabamento na mesa de ferraria com os moldes vanilla de Armor Trim. Foram adicionados:
- `data/randomstuff/trim_material/rose_gold.json` (asset `rose_gold`, ingrediente `randomstuff:rose_gold_ingot`, indice de modelo 1.1 e nome traduzido);
- `data/minecraft/tags/item/trim_materials.json`;
- `assets/randomstuff/textures/trims/color_palettes/rose_gold.png` (paleta 8x1, tons derivados visualmente do sprite ativo do lingote; sprites originais preservados);
- chave `trim_material.randomstuff.rose_gold` em pt_BR e en_US;
- gerador independente de dependencias `scripts/gerar_trim_ouro_rosa.py` e validacoes correspondentes em `scripts/validar_projeto.py`.

Teste manual que o usuario pode fazer: mesa de ferraria -> armadura -> qualquer molde de Armor Trim vanilla -> Lingote de Ouro Rosa. O acabamento deve aparecer em rosa/ouro rosa. Nao confundir com o `rose_gold_upgrade_smithing_template`, que e o molde de melhoria de equipamento ja existente.

Validacao nesta rodada: gerador executado; `scripts/validar_projeto.py` terminou com 0 erros e 1 aviso (ausencia de suite automatizada); `scripts/validar_assets.py` validou 205 PNGs originais sem erros. A paleta ativa 8x1 foi conferida pelo validador do projeto. Sem compilacao ou teste no Minecraft, conforme instrucao do usuario.


## Rodada de fechamento parcial — 09/11/2026

### Ajustes de código desta rodada

- O callback do ovo contextual da Raposa Negra agora é inicializado explicitamente em `RandomStuffMod`, depois do registro de `ModItems`. Antes, a classe tinha o método `init()`, mas não havia chamada visível no inicializador principal.
- O ovo contextual agora registra também uso sobre entidades (`UseEntityCallback`), além do uso em bloco. A criação é centralizada em um método, consulta o bioma no ponto de nascimento, seleciona Raposa Negra apenas na chave `minecraft:dappled_forest` e consome o item somente após a entidade ser aceita pelo servidor.
- Nenhum sprite original foi alterado. Nenhum código de física/combate/tingimento foi inventado sem as assinaturas reais da API 26.3.

### Limites e pendências reais

A Etapa 4 ainda NÃO pode ser declarada concluída: física, combate, água/lava, tingimento dos Slimes e blocos coloridos continuam sem implementação. As assinaturas reais do Minecraft 26.3 não estão no pacote local; criar mixins com alvos presumidos contrariaria as regras do projeto e poderia quebrar o carregamento. A validação de APIs/render/spawn de Moobloom/Moonlip e Raposa Negra também depende da referência real 26.3.

Checagens estáticas Python executadas (não envolvem Java 25 nem Minecraft): `scripts/validar_projeto.py` — 947 JSONs, 173 PNGs de recursos, 181 assets no manifesto, 72 classes Java, 0 erros e 1 aviso informativo de ausência de `src/test`; `scripts/validar_assets.py` — 205 PNGs, 0 erros. Por solicitação do usuário, não foram executados Gradle, JDK/Java 25, `javap`, compilação, geração de JAR ou Minecraft. O usuário fará os testes no jogo.

## Rodada adicional de implementação — 09/11/2026

- Adicionados 16 blocos de Slime coloridos como subclasses de `SlimeBlock`, com assets próprios, loot, itens, modelos e traduções. O pincel colorido agora pode repintar esses blocos.
- Adicionado `SlimeFallDamageMixin` para impedir dano de queda somente em Slimes e Magma Cubes.
- Permanecem sem implementação: quique de pouso customizado, flutuação em água/lava, dano de água, combate recíproco, knockback/empurrões e tingimento/renderização sincronizada das entidades Slime.
- Permanecem sem validação: assinaturas 26.3 de entidades/renderers/callbacks/mixins e restrições de spawn terrestre.
- Validação estática Python: 1.027 JSON, 189 PNG de recursos, 73 classes Java; 0 erros e 1 aviso informativo. Assets originais: 205 PNG, 0 erros.
- Não executados Java 25, Gradle, compilação, `javap`, JAR ou Minecraft.

A Etapa 4 continua aberta. Ver também `docs/FECHAMENTO_ETAPA_4_RODADA_FINAL.md` e o fim de `TAREFAS_REPLIT.txt`.

---

## Atualização de implementação — fechamento de código (09/11/2026)

Esta seção é a referência mais recente e substitui as listas de pendências técnicas das rodadas anteriores. O código foi ampliado sem executar Java 25, Gradle, compilação, `javap` ou Minecraft.

### Moobloom e Moonlip

- Entidades, atributos, variantes, reprodução, tosquia, regeneração de flores e renderer/camada floral permanecem na base.
- `ModEntities` agora registra placement terrestre para as duas entidades antes de adicionar as regras de spawn por bioma. Isso evita depender somente de `BiomeModifications.addSpawn` sem um placement vanilla.
- Moobloom usa o bioma Forest da base; Moonlip usa Cherry Grove. O spawn em Eucalyptus/bioma especial depende da Etapa 5.

### Raposa Negra

- `BlackFoxEntity` usa a classe Fox do pacote 26.3 (`net.minecraft.world.entity.animal.fox.Fox`), com renderer próprio e textura dedicada.
- O ovo contextual funciona em clique em bloco e em entidade; escolhe Raposa Negra somente na chave `minecraft:dappled_forest` e raposa vanilla fora dela.
- O placement terrestre está registrado. A geração natural na Floresta Salpicada só passa a ocorrer quando a Etapa 5 registrar esse bioma e adicionar a entidade às suas listas de spawn. Não foi criado bioma nesta etapa.

### Slime e Magma Cube

- Os baldes agora aceitam ambos os tipos por meio de `AbstractCubeMob`, preservando tamanho, vida proporcional, nome e flags suportadas. A cor do Slime também é armazenada no balde e restaurada ao soltar; Magma Cube não recebe cor.
- O pacote de classes foi atualizado para o namespace 26.3 `net.minecraft.world.entity.monster.cubemob`.
- `AbstractCubeMobMixin` implementa: busca recíproca de alvo Slime/Magma Cube, ataque de 1 ponto entre espécies, empurrão proporcional ao tamanho, quique de entidades que pousam no topo e dano térmico leve no pouso sobre Magma Cube.
- Slimes recebem impulso vertical na água; Magma Cubes recebem impulso vertical na lava e sofrem 1 ponto de dano de afogamento a cada 20 ticks enquanto submersos.
- A imunidade de queda cancela somente `DamageTypes.FALL`; `STALAGMITE`, `FALLING_STALACTITE` e outras fontes continuam perigosas. O salto próprio dos cubemobs continua usando os goals vanilla.
- Slimes aceitam os 16 corantes: a cor é resolvida pelo ID vanilla `minecraft:*_dye` (o `DyeItem` 26.3 não expõe mais `getDyeColor`), sincronizada por `SynchedEntityData`, salva no NBT, herdada pelos Slimes que nascem da divisão e aplicada no renderer por `SlimeRenderState`. Magma Cube rejeita corante sem consumir o item.
- Os 16 blocos coloridos de Slime usam `SlimeBlock` vanilla, com blockstates/modelos/itens/loot/traduções já presentes. Agora podem ser tingidos diretamente com corante e repintados com os pincéis coloridos; o Slime Block vanilla também é reconhecido como origem.

### Compatibilidade de nomes e APIs 26.3

- Corrigidos os pacotes de `Slime`, `MagmaCube` e `Fox` para as classes documentadas em 26.3.
- Referências de entidades vanilla migradas para `EntityTypes` onde o projeto usava campos estáticos antigos de `EntityType`.
- `FlowerCowEntity` usa `spawnAtLocation(ServerLevel, ItemStack)` e mantém a assinatura `getBreedOffspring(ServerLevel, AgeableMob)` da Cow 26.3.
- `scripts/extrair_referencias.sh` foi atualizado com os pacotes 26.3. `scripts/validar_projeto.py` agora confere os mixins comuns e de cliente.

### Dependência que permanece fora da Etapa 4

A chave `minecraft:dappled_forest` está preparada no ovo e no spawn da Raposa Negra, mas a Floresta Salpicada já existe como `minecraft:dappled_forest` no Minecraft 26.3. Não criar esse bioma nesta entrega para não avançar a Etapa 5.

### Validações permitidas executadas

- `python3 scripts/validar_projeto.py`: 1.028 JSON, 189 PNG de recursos, 83 classes Java; 0 erros e 1 aviso informativo por ausência de `src/test`.
- `python3 scripts/validar_assets.py`: 205 PNG verificados; 0 erros.
- Auditoria adicional: ambos os JSON de mixins parseiam e as 16 variantes de bloco possuem blockstate, modelo de bloco, modelo de item e loot table.

**Não executado conforme pedido:** JDK/Java 25, Gradle, compilação, `javap`, geração de JAR, testes de Minecraft, servidor dedicado ou multiplayer. Portanto, esta é uma entrega de código e validação estática, não uma aprovação de runtime.
