# Painéis de vidro: conexão com Shift

## Comportamento implementado

- Colocar sem agachar: mantém a conexão vanilla entre painéis.
- Colocar agachado (Shift): marca o painel com o estado persistente `separated=true`.
- Painéis separados mantêm a borda nos encontros com outros painéis; painéis normais também respeitam a separação do vizinho, evitando conexão unilateral.
- Aplicado ao vidro transparente e aos painéis de vidro colorido vanilla.
- Barras de ferro e barras de cobre não recebem a lógica de separação.
- A propriedade é parte do BlockState, portanto acompanha o bloco em salvamentos e atualizações normais do mundo.

## Arquivos

- `src/main/java/com/randomstuff/feature/PaneSeparation.java`
- `src/main/java/com/randomstuff/mixin/GlassPaneSeparationMixin.java`
- `src/main/resources/randomstuff.mixins.json`

## Limite desta entrega

A alteração foi revisada estaticamente. Não foram executados Java 25, Gradle, compilação, `javap`, cliente Minecraft ou servidor. Testar colocação com/sem Shift, mistura dos dois modos, todas as cores, remoção, água, persistência e compatibilidade com Sodium/outros mods antes de considerar validada em runtime.
