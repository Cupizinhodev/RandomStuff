# Sons e mineração das variantes de blocos — 2026-11-08

## Regras aplicadas
- `rose_gold_block`: copia som, tempo de quebra, resistência e requisito de ferramenta de `minecraft:gold_block`.
- `raw_rose_gold_block`: copia as mesmas propriedades de `minecraft:raw_gold_block`.
- Todas as 51 entradas de `VariantList` (lajes, escadas e paredes) copiam essas propriedades do respectivo bloco-base.
- Variantes de osso de Wither e abóbora branca também usam a mesma rotina de cópia integral.

## Implementação
`ModBlocks.copyBlockProperties(Block base)` usa `BlockBehaviour.Properties.ofFullCopy(base)` para preservar as propriedades físicas e de mineração e define explicitamente o som por `base.defaultBlockState().getSoundType()`.

## Validação
- Conferência estática do código e da lista de variantes.
- Não foi executado Gradle, compilação, geração de JAR ou teste dentro do Minecraft.
