# Fechamento visual das vacas florais — 2026-11-08

## Implementado nesta rodada

- Renderer dedicado para Moobloom e Moonlip, mantendo o modelo-base de vaca.
- Seleção de textura corporal por variante e por idade (adulto/filhote), usando os PNGs originais `body_*`.
- Flor 3D no dorso, construída com o modelo do bloco correspondente à variante; o estado visual acompanha `hasFlowers`, portanto desaparece quando a vaca é tosquiada.
- Eye-of-Wax: corpo e flor usam a versão fechada durante o dia e aberta à noite, conforme o relógio do mundo.
- A seleção das variantes continua sincronizada pela entidade e a regeneração permanece em 2 minutos de jogo.
- As imagens da pasta `overlay` continuam tratadas como recursos visuais das vacas, nunca como flores naturais adicionais no mundo.

## Mapeamento visual

- Moobloom: 9 variantes — Buttercup, Poppy, Dandelion, Blue Orchid, Allium, Azure Bluet, Lily of the Valley, Cornflower e Eye-of-Wax.
- Moonlip: 7 variantes — Pink Daisy, Orange Tulip, Red Tulip, Pink Tulip, White Tulip, Daisy e Magenta Tulip.
- Cada variante escolhe a textura adulta ou bebê correspondente; Eye-of-Wax também alterna os arquivos `*_open` à noite.

## Limites da verificação

- Não executei Gradle, compilação, geração de JAR nem teste dentro do Minecraft, conforme a instrução do projeto.
- A integração do renderer usa as APIs de renderização do Minecraft 26.3 (`CowRenderState`, `BlockModelResolver` e `BlockDecorationLayer`), mas a assinatura final precisa ser confirmada pela compilação autorizada e pelo teste visual no jogo.
- Por isso, esta rodada fecha a implementação em código e recursos, mas não declara validação runtime.
