# Ajuste de regeneração — 2026-11-08

- Alterado `FlowerCowEntity.REGROW_TICKS` de 24.000 para 2.400 ticks.
- As flores voltam após 2 minutos de jogo (20 ticks por segundo).
- A tesoura continua removendo a flor e soltando o item correspondente.
- O contador continua salvo junto à entidade.
- Não houve compilação, execução de Gradle ou geração de JAR.

## Limitações ainda abertas

- O renderizador ainda não desenha os overlays 3D das flores sobre o modelo da vaca.
- O renderizador ainda usa textura genérica em vez de selecionar o corpo pela variante.
- A alternância dia/noite do Olho-de-Cera ainda não está conectada ao renderizador.
- Portanto, este ZIP não deve ser considerado a implementação visual final das vacas florais.
