# Progresso — Random Stuff / Etapa 2

## Estado desta atualização (2026-11-08)

A base utilizada continua sendo o projeto `RandomStuff_Etapa_2.zip` recebido nesta conversa. As mudanças foram feitas na mesma árvore de projeto; os arquivos, recursos, modelos, texturas, receitas e registros anteriores foram preservados.

### Funcionalidades da Etapa 2

| # | Funcionalidade | Estado no código-fonte | Implementação / observação |
|---|---|---|---|
| 1 | Tridente e ejetores | **Implementado no código-fonte; sem teste de runtime** | Ejetor dispara o tridente como projétil com velocidade e dano-base do arremesso do jogador. Aumenta levemente o raio de colisão. Com Lealdade, o tridente volta à posição do ejetor e é reinserido no inventário; a posição de origem e o estado de retorno são salvos. |
| 2 | Rebater ovos, bolas de neve e cargas de vento | **Implementado no código-fonte; sem teste de runtime** | `ProjectileReboundMixin`: ataque com espada, machado ou pá rebate esses três tipos de projétil e atribui o jogador como dono. |
| 3 | Pesca de criaturas em barcos | **Implementado no código-fonte; sem teste de runtime** | `FishingHookBoatMixin`: ao atingir um passageiro de barco, desmonta somente a criatura, preservando o barco. |
| 4 | Beacon — Brilho | **Implementado no código-fonte; sem teste de runtime** | Efeito próprio selecionável no Beacon. Enquanto ativo, aplica o efeito Glowing vanilla às criaturas vivas dentro do alcance do Beacon, incluindo mobs. |
| 5 | Beacon — Respiração (dobro de ar, não infinito) | **Implementado no código-fonte; sem teste de runtime** | Efeito próprio selecionável no Beacon. Duplica a capacidade de ar e preenche a reserva dobrada uma vez ao receber o efeito; não renova o ar a cada pulso do Beacon. Ao perder o efeito, limita a reserva ao máximo normal. |
| 6 | Villagers reparando Golems | **Implementado no código-fonte; sem teste de runtime** | Villagers podem recolher lingotes de ferro, carregam um lingote e procuram Golems de Ferro com até 25% de vida. Ao alcançar o Golem, consomem o lingote e restauram 25% da vida máxima (um estágio de dano). |
| 7 | Natação na lava | **Implementado no código-fonte; sem teste de runtime** | `LavaSwimMixin` redireciona a física de deslocamento na lava para a física de natação em água quando `LavaResistance.protects(entity)` é verdadeiro; mantém a física normal para as demais entidades. |
| 8 | Queda de Penas e gelo frágil | **Proteção de pisada implementada no código-fonte; sem teste de runtime** | `FrostedIceFeatherMixin` suspende o envelhecimento do gelo frágil enquanto uma entidade com Queda de Penas está apoiada nele. O tick é reagendado para o gelo voltar a envelhecer normalmente depois que a entidade sair. A mineração manual continua possível. |

## Arquivos adicionados ou alterados nesta atualização

- `src/main/java/com/randomstuff/effect/BeaconMarkerEffect.java` — classe-base dos efeitos próprios do Beacon.
- `src/main/java/com/randomstuff/feature/BeaconEffects.java` — registro dos efeitos Brilho e Respiração.
- `src/main/java/com/randomstuff/feature/TridentDispenser.java` — comportamento de disparo do tridente por ejetor.
- `src/main/java/com/randomstuff/mixin/BeaconBlockEntityAccessor.java` e `BeaconBlockEntityMixin.java` — integração dos efeitos ao Beacon e aplicação de Brilho aos mobs.
- `src/main/java/com/randomstuff/mixin/EntityBeaconBreathingMixin.java` e `LivingEntityBeaconBreathingMixin.java` — reserva de ar dobrada sem respiração infinita.
- `src/main/java/com/randomstuff/mixin/DispenserTridentAccess.java`, `AbstractArrowAccess.java` e `ThrownTridentDispenserMixin.java` — origem, retorno por Lealdade e persistência do tridente.
- `src/main/java/com/randomstuff/mixin/TridentCollisionMixin.java` — ajuste do raio de colisão do tridente.
- `src/main/java/com/randomstuff/mixin/VillagerGolemRepairMixin.java` e `VillagerIronIngotPickupMixin.java` — coleta de lingotes e reparo de Golems.
- `src/main/java/com/randomstuff/mixin/FrostedIceFeatherMixin.java` — proteção do gelo enquanto a entidade está apoiada nele e reagendamento do tick.
- `src/main/resources/randomstuff.mixins.json` — novas entradas adicionadas sem remover as anteriores.
- `src/main/resources/assets/randomstuff/lang/pt_br.json` e `en_us.json` — nomes dos dois efeitos do Beacon.

## Verificações feitas

- JSON de `randomstuff.mixins.json`, `fabric.mod.json` e idiomas analisado sintaticamente.
- Verificada a ausência de nomes duplicados na configuração de mixins.
- Verificada a existência de todos os arquivos Java referenciados como mixins e a presença de `@Mixin` nas classes listadas.
- Verificados os ícones `beacon_glowing.png` e `beacon_breathing.png` já existentes.
- Verificados os registros de inicialização de Beacon e tridente no ponto de entrada do mod.
- Verificadas chaves e delimitadores básicos dos novos arquivos Java.
- Executada `scripts/validar_projeto.py`: JSONs e PNGs passaram, mas o script encontrou 8 assets listados no manifesto e ausentes da pasta de assets originais. Os mesmos 8 caminhos também estão ausentes do ZIP-base recebido, portanto são pendências anteriores a esta atualização e não foram removidos por ela.

**Limite importante:** essas são verificações estáticas. Não foi feita compilação, execução do Gradle, geração de JAR nem inicialização/teste dentro do Minecraft, conforme a restrição do projeto. Portanto, não afirmo que o código foi validado em runtime ou que o ZIP já é um JAR funcional.

## Etapa 3 — auditoria e consolidação (2026-11-08)

A base recebida já continha implementações de código para os encantamentos Caminhante da Lava e Resistência à Lava, os hooks do encantamento vanilla Queda de Penas, ajustes do tridente/projéteis, efeitos Brilho/Respiração do Beacon e reparo de Golems por Villagers. Esses sistemas foram organizados no relatório `docs/RELATORIO_ETAPA_3.md`; não foram duplicados.

Também foram corrigidos os caminhos UTF-8 de oito assets originais que estavam presentes com nomes corrompidos. Os PNGs foram copiados sem alteração de pixels. A validação estática passou: `validar_projeto.py` com 0 erros e 1 aviso (sem suíte `src/test`); `validar_assets.py` com 0 erros.

**Estado honesto:** Etapa 3 escrita/consolidada e validada estaticamente, ainda NÃO compilada nem testada em runtime. Não foi executado Gradle, não foi gerado JAR e não foi aberto o Minecraft. O Replit deve seguir os testes específicos da Etapa 3 em `TAREFAS_REPLIT.txt`.

## Etapa 4 — auditoria inicial (2026-11-09)

A base consolidada contém implementação parcial/avançada das vacas florais e captura/soltura de Slime/Magma Cube. A auditoria identificou ausência da Raposa Negra e ausência dos comportamentos físicos e de interação especiais de Slime/Magma Cube. Os detalhes e testes obrigatórios estão em `docs/RELATORIO_ETAPA_4.md` e nas tarefas 20–28 de `TAREFAS_REPLIT.txt`.

**Estado honesto:** etapa iniciada, ainda não concluída. O código das vacas florais e baldes requer compilação e testes reais; Raposa Negra e vários comportamentos de Slime/Magma Cube ainda precisam ser implementados. Nenhuma compilação/JAR/Minecraft foi executada nesta atualização.


## Etapa 4 — auditoria de entrada e recuperação de sprites (2026-11-09)

A primeira ação desta rodada foi comparar `RandomStuff_Etapa_4_INICIADA.zip`, `RandomStuff_Pacote_Claude_Replit.zip` e `random stuff sprites.zip`. O conjunto de sprites de Ouro Rosa está completo no pacote de sprites e as respectivas texturas de jogo já estavam em `src/main/resources/assets/randomstuff/textures/`. O problema encontrado eram quatro nomes UTF-8 ausentes em `assets_originais/`: ícone da calça, ícone da lança na hotbar, textura da lança em mão e pá. Também faltavam nessa pasta os quatro nomes UTF-8 dos estágios da cenoura dourada. Os oito PNGs foram recuperados do ZIP original de sprites, sem alterar pixels; as oito texturas do mod foram comparadas byte a byte com as fontes e coincidem.

### Estado de implementação da Etapa 4 (auditoria estática)

- **Moobloom/Moonlip:** entidade, variantes, sincronização, tosquia, drops, regeneração, salvamento e reprodução estão presentes no código. Registros e spawns por bioma também existem, mas o registro de spawn terrestre e os biomas/frequências exatos ainda precisam de validação. Renderer/camada floral estão presentes no lado cliente. Nenhuma dessas funções foi testada em runtime.
- **Raposa Negra:** a textura `black_fox.png` está presente, mas não há entidade/variante, integração com a IA vanilla, renderização ou spawn implementados. A Floresta Salpicada depende da Etapa 5.
- **Baldes de Slime/Magma:** captura e soltura básicas estão presentes; o código atual grava tamanho, vida e nome customizado. Ainda não preserva uma serialização segura e completa de dados relevantes, e não há evidência de teste de inventário cheio, modo criativo ou multiplayer.
- **Física/interações/tingimento:** os hooks especificados nas tarefas 25–27 não foram encontrados nesta auditoria; permanecem pendentes.

### Verificações desta rodada

- `python3 scripts/validar_projeto.py`: 943 JSONs, 172 PNGs de recursos, 181 assets do manifesto, 69 classes Java; **0 erros**, 1 aviso pela ausência de suíte `src/test`.
- `python3 scripts/validar_assets.py`: **197 PNGs, 0 erros**.
- Verificação byte a byte: os oito sprites recuperados coincidem com as texturas do mod; dimensões conferidas (16x16, exceto lança em mão 32x32).
- Não foram executados Gradle, `javap`, compilação, `runClient`, servidor dedicado ou testes no Minecraft. Nenhuma funcionalidade da Etapa 4 está declarada como concluída em runtime.


## Etapa 4 — implementação incremental adicional (2026-11-09)

- **Raposa Negra:** código inicial adicionado: entidade baseada em `Fox`, registro/atributos, renderer dedicado, ovo e spawn preparado para a chave futura `minecraft:dappled_forest`. A Floresta Salpicada ainda não existe (Etapa 5); regra contextual do ovo fora do bioma ainda pendente. Assinaturas de renderer/atributos precisam de `javap` e compilação no Replit.
- **Baldes:** persistência ampliada para tamanho, vida proporcional, nome limitado, NoAI, invulnerabilidade e persistência. Captura agora entrega o balde antes de remover o mob; soltura consome somente após inserção aceita. Não copia NBT arbitrário. APIs e cenários de inventário/criativo ainda não testados.
- **Moobloom/Moonlip:** código preexistente preservado; sem correção de API/spawn nesta rodada por falta dos JARs 26.3 para `javap`.
- **Física, combate e tingimento Slime/Magma:** continuam pendentes; não foram adicionados mixins especulativos.
- **Validação:** nenhuma compilação, `javap`, sessão de Minecraft ou servidor executado. Ver `docs/RELATORIO_ETAPA_4.md` e tarefas 20–31 em `TAREFAS_REPLIT.txt`.

## Etapa 4 — rodada técnica de ovo contextual e inspeção de APIs (09/11/2026)

- **Ovo da Raposa Negra:** implementado no código-fonte com item próprio e callback de uso em bloco. Na chave `minecraft:dappled_forest`, invoca Raposa Negra; fora dela, raposa vanilla. Mantém as propriedades visuais de spawn egg e só consome o item após a inserção da entidade ser aceita. Não compilado nem testado.
- **Inspeção de APIs:** `scripts/extrair_referencias.sh` agora tenta extrair as assinaturas relevantes de Slime/MagmaCube/Entity/LivingEntity/Mob/SlimeBlock, renderizadores de Slime/Fox/Cow e classes de camada floral. O JAR Minecraft 26.3 não existe no ambiente local; o Replit precisa gerar e enviar `referencias_minecraft.zip`.
- **Física, combate e tingimento:** permanecem não implementados. Não foram criados mixins especulativos porque os métodos/descriptors 26.3 ainda não foram inspecionados.
- **Moobloom/Moonlip:** implementação existente preservada; APIs, SpawnPlacements, renderer e camada floral continuam sem validação real.
- **Próximos passos obrigatórios:** tarefas 32–38 de `TAREFAS_REPLIT.txt`. A Etapa 4 continua aberta; nenhuma validação runtime foi feita e a Etapa 5 não foi iniciada.


## Atualizacao — material de Armor Trim Ouro Rosa (09/11/2026)

Foi adicionado o lingote `randomstuff:rose_gold_ingot` como material utilizavel nos moldes de acabamento de armadura (Armor Trims) da mesa de ferraria. A implementacao e baseada em dados do resource pack/datapack, sem mixin ou registro Java adicional:
- `data/randomstuff/trim_material/rose_gold.json`: define o material, nome visual, lingote ingrediente e indice de modelo.
- `data/minecraft/tags/item/trim_materials.json`: inclui o lingote na tag de ingredientes de Armor Trim.
- `assets/randomstuff/textures/trims/color_palettes/rose_gold.png`: paleta RGB 8x1 em tons do sprite original do lingote; nenhum sprite original foi modificado.
- `lang/pt_br.json` e `lang/en_us.json`: nome localizado do material.
- `scripts/gerar_trim_ouro_rosa.py`: gera/recria os arquivos de dados, paleta e traducoes sem dependencias Python externas.
- `scripts/validar_projeto.py`: agora verifica material, ingrediente/tag, dimensao da paleta e traducoes.

Uso esperado: na mesa de ferraria, colocar uma peca de armadura compativel, qualquer molde de Armor Trim vanilla e um Lingote de Ouro Rosa no slot de material. Isso adiciona o acabamento no tom rosa/dourado da paleta. O molde de melhoria de Ouro Rosa existente continua sendo outra funcionalidade, separada dos Armor Trims.

Validacao executada nesta rodada: gerador executado, JSONs analisados, dimensao PNG 8x1 e integridade do arquivo conferidas; validadores estaticos do projeto e assets executados. Nenhum teste de jogo nem compilacao foi realizado, conforme solicitado pelo usuario.


### Rodada de edição — 09/11/2026 (sem testes)

- Corrigida a ausência de chamada de inicialização do ovo contextual da Raposa Negra: `ContextualBlackFoxSpawnEggItem.init()` agora é chamado após `ModItems.init()`.
- Adicionado callback de uso do ovo sobre entidades, além do callback sobre blocos; a escolha de Raposa Negra/raposa vanilla continua contextual à Floresta Salpicada.
- Atualizados `TAREFAS_REPLIT.txt` e `docs/RELATORIO_ETAPA_4.md` com o ajuste e as pendências bloqueadas pela falta das assinaturas reais do Minecraft 26.3.
- **Etapa 4 permanece aberta.** Física, combate e tingimento de Slime/Magma Cube não foram implementados porque os métodos/descritores 26.3 não estão disponíveis localmente; não foram criados mixins especulativos. A API/render/spawn das entidades ainda requer conferência.
- Checagens estáticas Python: `validar_projeto.py` — 947 JSONs, 173 PNGs de recursos, 181 assets de manifesto, 72 classes Java, 0 erros e 1 aviso informativo; `validar_assets.py` — 205 PNGs, 0 erros.
- Conforme pedido, não foram executados testes de Java 25, Gradle, compilação, `javap`, geração de JAR nem testes no Minecraft.

## Etapa 4 — rodada adicional de implementação (2026-11-09)

- Acrescentados 16 blocos de Slime coloridos (`SlimeBlock`), com assets, loot tables, item definitions, traduções e suporte à repintura com os pincéis.
- Acrescentado mixin que cancela somente o dano de queda de Slimes e Magma Cubes.
- Ainda faltam física de quique/flutuação, dano de água, combate/empurrões, tingimento sincronizado/renderização dos Slimes, e conferência de API/spawn no Minecraft 26.3. A Etapa 4 permanece aberta.
- Validação estática Python: 1.027 JSON, 189 PNG de recursos, 73 classes Java; 0 erros/1 aviso. Assets originais: 205 PNG, 0 erros.
- Nenhum Java 25, Gradle, compilação, `javap`, JAR ou Minecraft foi executado. Consulte `docs/FECHAMENTO_ETAPA_4_RODADA_FINAL.md`.

---

## Fechamento de código — Etapa 4 (09/11/2026)

A implementação de código da Etapa 4 foi ampliada e consolidada nesta versão: Moobloom/Moonlip, Raposa Negra, baldes de Slime/Magma Cube, comportamento recíproco dos cubemobs, tingimento sincronizado/persistente dos Slimes, 16 blocos de Slime coloridos, interação com corantes/pincéis e mixins de cliente/servidor. Veja `docs/RELATORIO_ETAPA_4.md`.

A Floresta Salpicada permanece uma dependência da Etapa 5; não foi criada nesta entrega. Validadores estáticos: 0 erros. Nenhuma execução de Java 25, Gradle, compilação, `javap` ou Minecraft foi feita, conforme solicitação. Portanto, o código está preparado para teste manual pelo usuário, sem alegar compilação ou aprovação de runtime.


## Início da Etapa 5 — biomas, atmosfera, spawns e loot (09/11/2026)

**Estado: em andamento; não compilado nem testado.**

- Reaproveitados os biomas já existentes no Minecraft 26.3: `minecraft:pale_garden` (Jardim Pálido) e `minecraft:dappled_forest` (Floresta Salpicada). Isso evita duplicar biomas vanilla.
- Raposa Negra: chave de spawn natural e ovo contextual corrigidos para `minecraft:dappled_forest`.
- Novo biome data `randomstuff:cherry_bamboo_grove`: base visual/climática de Cherry Grove, bambu esparso em grupos e spawn de Moonlip. Traduções pt_BR/en_US adicionadas.
- Worldgen: adicionados recursos/placed features para abóbora branca no Pale Garden e abóbora normal, entalhada e Jack o’Lantern na Dappled Forest.
- Atmosfera complementar implementada via `BiomeModification`/environment attributes: Pântano e Manguezal levemente verdes; Deserto e Badlands amarelo-alaranjados. Valores ainda precisam de avaliação visual e podem conflitar com overrides de outros mods.
- Sono revisado para evitar ticks duplicados em áreas sobrepostas de jogadores dormindo; chunks descarregados não são processados. Taxas ainda precisam de balanceamento manual.
- Mercador conferido estaticamente: 24 vendas e 7 compras com preços/quantidades do briefing; não compra escama de tartaruga. “Folhas” e “flores” foram interpretadas como folhas de carvalho e dente-de-leão.
- Loot de vilas/strongholds ampliado, mas livros encantados e equipamentos danificados ainda faltam; chances escolhidas são aproximações, pois não estão especificadas.
- Pendente: inserir Cerejeira Bambuzal na distribuição multi-noise vanilla sem substituir o preset; implementar spawn raro de mobs usando abóbora entalhada/Jack o’Lantern; avaliar frequência/tamanho dos biomas e concluir loot/testes manuais.

Nenhum Java 25, Gradle, compilação, `javap` ou Minecraft foi executado.


## Etapa 5 — revisão adicional de worldgen (09/11/2026)

- Corrigido o solo da feature de abóbora branca: o filtro agora exige `minecraft:pale_moss_block`, compatível com o piso do Jardim Pálido, em vez de `minecraft:grass_block`.
- Reordenados os modifiers das quatro placed features para executar o filtro de bioma depois das operações que alteram a posição.
- Atmosfera ampliada para aplicar também `setWaterColor`, além de atributos de névoa/céu/névoa subaquática e overrides de grama/folhagem. A API Fabric 26.1 documenta este método.
- A Etapa 5 continua aberta: falta a injeção multi-noise da Cerejeira Bambuzal, os mobs com abóboras, parte do loot e testes manuais. Não foi executado Java 25, Gradle, compilação, `javap` ou Minecraft.


## Atualização final da Etapa 5 — 09/11/2026

Ajustes de atmosfera adicionados também à Floresta Salpicada (`minecraft:dappled_forest`) e ao Jardim Pálido (`minecraft:pale_garden`), além dos ajustes já presentes para Pântano, Manguezal, Deserto e Badlands. Paletas são preliminares e precisam de avaliação visual. A Etapa 5 permanece ABERTA: Cerejeira Bambuzal ainda não participa da seleção multi-noise vanilla; faltam mobs com abóboras, parte do loot de stronghold, balanceamento de frequência/tamanho e testes de jogo/servidor. Nenhuma compilação ou execução de Minecraft foi feita. Ver `docs/RELATORIO_ETAPA_5.md`.


## Consolidação solicitada — Etapa 5 sem testes (09/11/2026)

Nova revisão estática das pendências de multi-noise, equipamentos de spawn e funções de loot 26.3. Não foi encontrada uma API pública confirmada que acrescente um bioma à lista multi-noise vanilla sem reconstruir/substituir o preset; tampouco foi confirmada callback Fabric que forneça razão de spawn segura para capacetes naturais. As funções de loot 26.3 usam context providers atualizados e os builders exatos não foram confirmados para o mapeamento do projeto. Para evitar alteração especulativa, não foram adicionados mixins, overrides do dimension/overworld, callbacks inadequados ou funções de loot com assinaturas incertas. Frequência/tamanho de Pale Garden/Dappled Forest e integração de Cerejeira Bambuzal seguem pendentes. As implementações existentes de atmosfera (incluindo Pale Garden/Dappled Forest), abóboras, spawns atuais, sono, mercador e pools extras foram preservadas. Nenhum teste foi executado. Consulte `docs/RELATORIO_ETAPA_5.md`.


## Etapa 5 — consolidação de implementação (2026-11-08; sem testes)

- `OverworldBiomeBuilderMixin` divide cada faixa térmica de Cherry Grove em 90% Cherry Grove e 10% Cerejeira Bambuzal; amplia Pale Garden em 4% e Dappled Forest em 2,5%, sem substituir o preset Overworld.
- `MobNaturalPumpkinEquipmentMixin` aplica abóbora entalhada/Jack o’Lantern apenas a zumbis, esqueletos e creepers em spawn natural na Dappled Forest, preservando capacetes existentes.
- `ModLootTables` adiciona livros encantados de baixo nível a vilas/strongholds e equipamentos de diamante danificados a strongholds com funções/providers confirmados na fonte 26.3.
- Atmosferas, worldgen de abóboras, spawns já existentes, aceleração durante sono e mercador permanecem incluídos.
- **Sem testes:** nenhuma execução Java 25, Gradle, compilação, `javap`, Minecraft ou servidor. A etapa fica aberta para teste manual da geração/frequência dos biomas, spawns, loot, sono, mercador e atmosferas.

## Painéis de vidro — mecânica de conexão por agachamento (09/11/2026)

Implementado estaticamente: painéis de vidro vanilla transparentes e coloridos preservam conexão vanilla quando colocados normalmente. Se o jogador coloca o painel agachado (Shift), ele recebe o estado persistente `separated`, e não cria conexão visual com painéis vizinhos; a regra também impede que o painel vizinho normal conecte unilateralmente a um painel separado. O sistema atua no `IronBarsBlock` para acrescentar a propriedade, mas restringe a lógica ao `Blocks.GLASS_PANE` e `StainedGlassPaneBlock`.

Não foram executados compilação ou testes de jogo. A confirmação visual dos padrões mistos, remoção, persistência e compatibilidade permanece para teste manual.

## Preparação da entrega ao Replit — 2026-11-09

O usuário autorizou o Replit a realizar a configuração técnica, corrigir erros reais de build e produzir o JAR. O projeto recebeu um fluxo único em `scripts/compilar_replit.sh`, instruções detalhadas em `REPLIT_INSTRUCOES.md`, prompt atualizado em `PROMPT_PARA_REPLIT.txt`, configuração `.replit` e pipeline alternativo no GitHub Actions. O script valida fontes/assets, executa `clean build`, verifica o JAR remapeado (metadados, mixins, classes e integridade), copia para `entrega/` e grava SHA-256 e log.

A configuração Loom foi fixada em 1.18.4 estável; Minecraft 26.3, Loader 0.19.5, Fabric API 0.163.0+26.3 e Java 25 foram mantidos. As dependências Fabric Loader/API foram ajustadas para `modImplementation`. O Gradle Wrapper existente foi preservado.

Validação estática local nesta preparação: `validar_projeto.py` — 0 erros e 1 aviso informativo; `validar_assets.py` — 213 PNGs, 0 erros. Nenhum Java 25, Gradle, compilação, javap ou Minecraft foi executado aqui. Portanto, ainda não existe JAR gerado/validado nesta rodada. O Replit deve entregar `entrega/*.jar`, `entrega/SHA256SUMS.txt` e `logs/build-replit.log`. Testes in-game/servidor continuam reservados ao usuário.
