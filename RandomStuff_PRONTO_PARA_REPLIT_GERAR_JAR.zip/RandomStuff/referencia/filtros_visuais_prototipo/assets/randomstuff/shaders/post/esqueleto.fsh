#version 150
// Filtro monocromático para visão de esqueleto.
// PROTOTIPO: validar uniforms/nomes de sampler no pipeline da versão 26.3.
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 source = texture(InSampler, texCoord);
    vec3 c = source.rgb;
    vec3 filtered = vec3(dot(c, vec3(0.299, 0.587, 0.114)) );
    fragColor = vec4(clamp(filtered, 0.0, 1.0), source.a);
}
