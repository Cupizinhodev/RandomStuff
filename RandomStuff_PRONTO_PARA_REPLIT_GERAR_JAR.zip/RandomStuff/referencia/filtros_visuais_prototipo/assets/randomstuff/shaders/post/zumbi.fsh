#version 150
// Filtro verde-acinzentado desbotado para visão de zumbi.
// PROTOTIPO: validar uniforms/nomes de sampler no pipeline da versão 26.3.
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 source = texture(InSampler, texCoord);
    vec3 c = source.rgb;
    vec3 filtered = vec3(c.r * 0.72, c.g * 0.88, c.b * 0.72);
    fragColor = vec4(clamp(filtered, 0.0, 1.0), source.a);
}
