#version 150
// Filtro roxo escuro para visão do Dragão do End.
// PROTOTIPO: validar uniforms/nomes de sampler no pipeline da versão 26.3.
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 source = texture(InSampler, texCoord);
    vec3 c = source.rgb;
    vec3 filtered = vec3(c.r * 0.58, c.g * 0.48, c.b * 0.88);
    fragColor = vec4(clamp(filtered, 0.0, 1.0), source.a);
}
