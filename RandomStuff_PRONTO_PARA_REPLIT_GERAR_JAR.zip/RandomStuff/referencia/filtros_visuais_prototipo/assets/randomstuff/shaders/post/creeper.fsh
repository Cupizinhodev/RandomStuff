#version 150
// Filtro verde para visão de Creeper.
// PROTOTIPO: validar uniforms/nomes de sampler no pipeline da versão 26.3.
uniform sampler2D InSampler;
in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 source = texture(InSampler, texCoord);
    vec3 c = source.rgb;
    vec3 filtered = vec3(c.r * 0.55, c.g * 1.12, c.b * 0.55);
    fragColor = vec4(clamp(filtered, 0.0, 1.0), source.a);
}
